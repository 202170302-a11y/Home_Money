import { CategoryItem } from '../types';

export const EXPENSE_CATEGORIES: CategoryItem[] = [
  {
    id: 'groceries',
    name: 'تموينات وبقالة',
    icon: 'ShoppingCart',
    color: '#059669', // Emerald
    bgColor: '#ecfdf5',
    type: 'expense',
    defaultLimit: 1500,
  },
  {
    id: 'utilities',
    name: 'فواتير وخدمات (كهرباء، ماء، نت)',
    icon: 'Zap',
    color: '#0284c7', // Sky
    bgColor: '#f0f9ff',
    type: 'expense',
    defaultLimit: 600,
  },
  {
    id: 'meat_produce',
    name: 'لحوم وخضار وفواكه',
    icon: 'Apple',
    color: '#16a34a', // Green
    bgColor: '#f0fdf4',
    type: 'expense',
    defaultLimit: 800,
  },
  {
    id: 'housing',
    name: 'إيجار المنزل والصيانة',
    icon: 'Home',
    color: '#d97706', // Amber
    bgColor: '#fffbeb',
    type: 'expense',
    defaultLimit: 2000,
  },
  {
    id: 'health',
    name: 'صيدلية وعلاج وطبابة',
    icon: 'HeartPulse',
    color: '#dc2626', // Red
    bgColor: '#fef2f2',
    type: 'expense',
    defaultLimit: 400,
  },
  {
    id: 'education',
    name: 'تعليم ومدارس ومستلزمات',
    icon: 'GraduationCap',
    color: '#7c3aed', // Purple
    bgColor: '#f5f3ff',
    type: 'expense',
    defaultLimit: 1000,
  },
  {
    id: 'transport',
    name: 'وقود ومواصلات وصيانة سيارة',
    icon: 'Car',
    color: '#ea580c', // Orange
    bgColor: '#fff7ed',
    type: 'expense',
    defaultLimit: 500,
  },
  {
    id: 'dining',
    name: 'مطاعم ووجبات سريعة',
    icon: 'Utensils',
    color: '#db2777', // Pink
    bgColor: '#fdf2f8',
    type: 'expense',
    defaultLimit: 450,
  },
  {
    id: 'clothing',
    name: 'ملابس ومستلزمات شخصية',
    icon: 'Shirt',
    color: '#4f46e5', // Indigo
    bgColor: '#eef2ff',
    type: 'expense',
    defaultLimit: 400,
  },
  {
    id: 'charity_gifts',
    name: 'صدقات وهدايا وتكافل',
    icon: 'Gift',
    color: '#0891b2', // Cyan
    bgColor: '#ecfeff',
    type: 'expense',
    defaultLimit: 300,
  },
  {
    id: 'installments',
    name: 'أقساط والتزامات شهرية',
    icon: 'CreditCard',
    color: '#475569', // Slate
    bgColor: '#f8fafc',
    type: 'expense',
    defaultLimit: 800,
  },
  {
    id: 'misc',
    name: 'نثريات ومصاريف أخرى',
    icon: 'Package',
    color: '#64748b', // Slate
    bgColor: '#f1f5f9',
    type: 'expense',
    defaultLimit: 300,
  },
];

export const INCOME_CATEGORIES: CategoryItem[] = [
  {
    id: 'salary',
    name: 'الراتب الشهري الأساسي',
    icon: 'Briefcase',
    color: '#059669',
    bgColor: '#ecfdf5',
    type: 'income',
  },
  {
    id: 'sudden_income',
    name: 'دخل مفاجئ / طارئ ⚡',
    icon: 'Sparkles',
    color: '#f59e0b', // Amber / Gold
    bgColor: '#fffbeb',
    type: 'income',
  },
  {
    id: 'freelance',
    name: 'دخل إضافي / عمل حر',
    icon: 'TrendingUp',
    color: '#2563eb',
    bgColor: '#eff6ff',
    type: 'income',
  },
  {
    id: 'bonus',
    name: 'مكافأة أو إكرامية',
    icon: 'Award',
    color: '#db2777',
    bgColor: '#fdf2f8',
    type: 'income',
  },
  {
    id: 'investment',
    name: 'عوائد استثمار / تجارة',
    icon: 'Building',
    color: '#d97706',
    bgColor: '#fffbeb',
    type: 'income',
  },
  {
    id: 'family_share',
    name: 'مساهمة أفراد الأسرة',
    icon: 'Users',
    color: '#7c3aed',
    bgColor: '#f5f3ff',
    type: 'income',
  },
  {
    id: 'other_income',
    name: 'إيراد آخر',
    icon: 'Coins',
    color: '#0891b2',
    bgColor: '#ecfeff',
    type: 'income',
  },
];

export const ALL_CATEGORIES: CategoryItem[] = [
  ...EXPENSE_CATEGORIES,
  ...INCOME_CATEGORIES,
];

export function getCategoryById(id: string): CategoryItem {
  return (
    ALL_CATEGORIES.find((c) => c.id === id) || {
      id,
      name: id,
      icon: 'Tag',
      color: '#64748b',
      bgColor: '#f1f5f9',
      type: 'expense',
    }
  );
}

// Preset Savings Goals for Families
export const SAVINGS_GOAL_PRESETS = [
  {
    title: 'صندوق طوارئ المنزل',
    category: 'emergency' as const,
    defaultTarget: 5000,
    color: '#059669',
    icon: 'Shield',
  },
  {
    title: 'شراء سيارة عائلية',
    category: 'car' as const,
    defaultTarget: 25000,
    color: '#2563eb',
    icon: 'Car',
  },
  {
    title: 'مصاريف وكسوة العيد',
    category: 'eid' as const,
    defaultTarget: 3000,
    color: '#db2777',
    icon: 'Gift',
  },
  {
    title: 'سفر وإجازة العائلة',
    category: 'travel' as const,
    defaultTarget: 8000,
    color: '#d97706',
    icon: 'Palmtree',
  },
  {
    title: 'أجهزة وتجديد أثاث البيت',
    category: 'house' as const,
    defaultTarget: 4500,
    color: '#7c3aed',
    icon: 'Home',
  },
  {
    title: 'ادخار ذهب ومجوهرات',
    category: 'gold' as const,
    defaultTarget: 10000,
    color: '#eab308',
    icon: 'Coins',
  },
];
