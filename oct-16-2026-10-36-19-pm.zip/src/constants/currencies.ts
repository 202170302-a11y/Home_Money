import { CurrencyConfig } from '../types';

export const SUPPORTED_CURRENCIES: CurrencyConfig[] = [
  { code: 'SAR', symbol: 'ر.س', name: 'ريال سعودي' },
  { code: 'YER', symbol: 'ر.ي', name: 'ريال يمني' },
  { code: 'AED', symbol: 'د.إ', name: 'درهم إماراتي' },
  { code: 'EGP', symbol: 'ج.م', name: 'جنيه مصري' },
  { code: 'KWD', symbol: 'د.ك', name: 'دينار كويتي' },
  { code: 'QAR', symbol: 'ر.ق', name: 'ريال قطري' },
  { code: 'OMR', symbol: 'ر.ع', name: 'ريال عماني' },
  { code: 'BHD', symbol: 'د.ب', name: 'دينار بحريني' },
  { code: 'JOD', symbol: 'د.أ', name: 'دينار أردني' },
  { code: 'IQD', symbol: 'د.ع', name: 'دينار عراقي' },
  { code: 'MAD', symbol: 'د.م', name: 'درهم مغربي' },
  { code: 'DZD', symbol: 'د.ج', name: 'دينار جزائري' },
  { code: 'TND', symbol: 'د.ت', name: 'دينار تونسي' },
  { code: 'USD', symbol: '$', name: 'دولار أمريكي' },
  { code: 'EUR', symbol: '€', name: 'يورو' },
];

export const DEFAULT_CURRENCY = SUPPORTED_CURRENCIES[0]; // SAR by default, or easily switched

export function formatCurrency(amount: number, symbol: string = 'ر.س'): string {
  const formattedNumber = Math.abs(amount).toLocaleString('ar-EG', {
    maximumFractionDigits: 2,
    minimumFractionDigits: 0,
  });
  return `${formattedNumber} ${symbol}`;
}
