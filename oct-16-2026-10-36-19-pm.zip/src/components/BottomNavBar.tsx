import React from 'react';
import { Home, ReceiptText, PiggyBank, PieChart, Sparkles, Plus } from 'lucide-react';
import { ThemeAccent } from '../types';

export type TabType = 'home' | 'transactions' | 'savings' | 'budgets' | 'advisor';

interface BottomNavBarProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
  onOpenQuickAdd: () => void;
  themeAccent?: ThemeAccent;
}

export const BottomNavBar: React.FC<BottomNavBarProps> = ({
  activeTab,
  onTabChange,
  onOpenQuickAdd,
  themeAccent = 'emerald',
}) => {
  const tabs = [
    { id: 'home' as TabType, label: 'الرئيسية', icon: Home },
    { id: 'transactions' as TabType, label: 'العمليات', icon: ReceiptText },
    { id: 'savings' as TabType, label: 'الادخار والصناديق', icon: PiggyBank },
    { id: 'budgets' as TabType, label: 'الميزانية والفواتير', icon: PieChart },
    { id: 'advisor' as TabType, label: 'المستشار الذكي', icon: Sparkles },
  ];

  const getFabClass = () => {
    switch (themeAccent) {
      case 'sapphire':
        return 'bg-gradient-to-tr from-blue-600 to-cyan-600 shadow-blue-600/30 hover:from-blue-500 hover:to-cyan-500';
      case 'amber':
        return 'bg-gradient-to-tr from-amber-600 to-orange-600 shadow-amber-600/30 hover:from-amber-500 hover:to-orange-500';
      case 'amethyst':
        return 'bg-gradient-to-tr from-purple-600 to-fuchsia-600 shadow-purple-600/30 hover:from-purple-500 hover:to-fuchsia-500';
      case 'emerald':
      default:
        return 'bg-gradient-to-tr from-emerald-600 to-teal-600 shadow-emerald-600/30 hover:from-emerald-500 hover:to-teal-500';
    }
  };

  const getActiveTabStyle = (isActive: boolean) => {
    if (!isActive) {
      return {
        text: 'text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200',
        pill: '',
      };
    }

    switch (themeAccent) {
      case 'sapphire':
        return {
          text: 'text-blue-600 dark:text-blue-400 font-bold',
          pill: 'bg-blue-100 dark:bg-blue-950/70 text-blue-700 dark:text-blue-400',
        };
      case 'amber':
        return {
          text: 'text-amber-600 dark:text-amber-400 font-bold',
          pill: 'bg-amber-100 dark:bg-amber-950/70 text-amber-700 dark:text-amber-400',
        };
      case 'amethyst':
        return {
          text: 'text-purple-600 dark:text-purple-400 font-bold',
          pill: 'bg-purple-100 dark:bg-purple-950/70 text-purple-700 dark:text-purple-400',
        };
      case 'emerald':
      default:
        return {
          text: 'text-emerald-700 dark:text-emerald-400 font-bold',
          pill: 'bg-emerald-100 dark:bg-emerald-950/70 text-emerald-700 dark:text-emerald-400',
        };
    }
  };

  return (
    <>
      {/* Floating Action Button (FAB) for fast adding */}
      <button
        onClick={onOpenQuickAdd}
        className={`fixed bottom-20 left-4 sm:left-6 z-40 w-14 h-14 rounded-2xl ${getFabClass()} text-white shadow-xl flex items-center justify-center active:scale-90 transition-all cursor-pointer ring-4 ring-white/90 dark:ring-slate-900/90 backdrop-blur-md`}
        aria-label="إضافة عملية جديدة"
        title="إضافة عملية جديدة (مصروف أو دخل)"
      >
        <Plus className="w-7 h-7 stroke-[2.6]" />
      </button>

      {/* Android Fixed Bottom Navigation Bar */}
      <nav className="sticky bottom-0 left-0 right-0 z-30 bg-white/90 dark:bg-slate-900/90 backdrop-blur-xl border-t border-slate-200/70 dark:border-slate-800/80 px-2 py-1.5 shadow-lg transition-colors duration-200">
        <div className="grid grid-cols-5 items-center max-w-lg mx-auto">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            const style = getActiveTabStyle(isActive);

            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`flex flex-col items-center justify-center min-h-[48px] py-1 rounded-xl transition-all cursor-pointer select-none ${style.text}`}
              >
                <div
                  className={`w-10 h-7 rounded-full flex items-center justify-center transition-all duration-200 ${style.pill}`}
                >
                  <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.4]' : 'stroke-[1.8]'}`} />
                </div>
                <span className="text-[10px] sm:text-[11px] leading-tight mt-0.5 truncate max-w-[68px]">
                  {tab.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
};
