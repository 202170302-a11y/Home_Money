import React, { useState } from 'react';
import {
  Sparkles,
  TrendingDown,
  Users,
  PieChart,
  CheckCircle,
  HelpCircle,
  Send,
  Loader2,
  RefreshCw,
  Lightbulb,
  ShieldCheck,
  Award,
} from 'lucide-react';
import {
  Transaction,
  CategoryBudget,
  FamilyMember,
  BillItem,
  DebtItem,
  CurrencyConfig,
  AdvisorResult,
} from '../../types';
import { EXPENSE_CATEGORIES, getCategoryById } from '../../constants/categories';
import { formatCurrency } from '../../constants/currencies';

interface AdvisorTabProps {
  transactions: Transaction[];
  budgets: CategoryBudget[];
  familyMembers: FamilyMember[];
  bills: BillItem[];
  debts: DebtItem[];
  currency: CurrencyConfig;
}

export const AdvisorTab: React.FC<AdvisorTabProps> = ({
  transactions,
  budgets,
  familyMembers,
  bills,
  debts,
  currency,
}) => {
  const [loading, setLoading] = useState(false);
  const [advisorData, setAdvisorData] = useState<AdvisorResult | null>(null);
  const [questionPrompt, setQuestionPrompt] = useState('');
  const [advisorSource, setAdvisorSource] = useState<'gemini_ai' | 'local_engine' | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Current month stats
  const now = new Date();
  const currentMonthStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  
  const currentMonthTx = transactions.filter((t) => t.date.startsWith(currentMonthStr));
  const currentMonthExpenses = currentMonthTx.filter((t) => t.type === 'expense');
  const currentMonthIncomes = currentMonthTx.filter((t) => t.type === 'income');

  const totalExpense = currentMonthExpenses.reduce((sum, t) => sum + t.amount, 0);
  const totalIncome = currentMonthIncomes.reduce((sum, t) => sum + t.amount, 0);

  // Group by category
  const categorySpendingMap: Record<string, number> = {};
  currentMonthExpenses.forEach((t) => {
    categorySpendingMap[t.category] = (categorySpendingMap[t.category] || 0) + t.amount;
  });

  const sortedCategories = Object.entries(categorySpendingMap)
    .sort((a, b) => b[1] - a[1])
    .map(([catId, amount]) => {
      const cat = getCategoryById(catId);
      const percent = totalExpense > 0 ? Math.round((amount / totalExpense) * 100) : 0;
      return { ...cat, amount, percent };
    });

  // Group by family member
  const memberSpendingMap: Record<string, number> = {};
  currentMonthExpenses.forEach((t) => {
    const memId = t.familyMemberId || 'other';
    memberSpendingMap[memId] = (memberSpendingMap[memId] || 0) + t.amount;
  });

  // Debts summary
  const debtsOwedByUs = debts.filter((d) => d.type === 'owed_by_us' && !d.isPaid).reduce((s, d) => s + d.amount, 0);
  const debtsOwedToUs = debts.filter((d) => d.type === 'owed_to_us' && !d.isPaid).reduce((s, d) => s + d.amount, 0);

  // Call backend AI Advisor
  const fetchAdvice = async (customPrompt?: string) => {
    setLoading(true);
    setErrorMsg(null);

    const generateLocalAdvice = () => {
      const remaining = totalIncome - totalExpense;
      const expenseRatio = totalIncome > 0 ? (totalExpense / totalIncome) * 100 : 100;
      const tips: string[] = [];

      if (expenseRatio > 90) {
        tips.push('⚠️ نسبة الإنفاق تجاوزت 90% من الدخل. يُنصح بمراجعة بنود الوجبات الخارجية والمشتريات غير الضرورية فوراً.');
      } else if (expenseRatio > 75) {
        tips.push('⚡ أنت في النطاق الحذر (أكثر من 75% من الميزانية). حاول تأجيل المشتريات الكمالية حتى بداية الشهر القادم.');
      } else {
        tips.push('🌟 أداء مالي ممتاز! تم استهلاك نسبة متوازنة، وهناك فائض يمكن توجيهه للادخار أو صندوق طوارئ البيت.');
      }

      tips.push('🛒 التموينات والبقالة: كتابة قائمة مشتريات أسبوعية قبل الذهاب للمتجر توفر عادة ما بين 15% إلى 25% من فاتورة السوبرماركت.');
      tips.push('💡 فواتير الخدمات: ضبط مكيفات الهواء على 24 درجة وإيقاف سخانات المياه عند عدم الحاجة يقلص فاتورة الكهرباء بنسبة ملحوظة.');
      if (debtsOwedByUs > 0) {
        tips.push(`📦 لديك التزامات أو ديون مستحقة بقيمة ${debtsOwedByUs} ${currency.symbol}. يُفضل تخصيص نسبة ثابتة لسدادها شهرياً.`);
      }

      return {
        healthScore: Math.max(10, Math.min(100, Math.round(100 - (expenseRatio * 0.7)))),
        summaryText: remaining >= 0 
          ? `ميزانية البيت في وضع مستقر مع فائض متبقٍ قدره ${remaining.toLocaleString('ar-EG')} ${currency.symbol}.`
          : `تنبيه: المصاريف تفوق الدخل بعجز قدره ${Math.abs(remaining).toLocaleString('ar-EG')} ${currency.symbol}.`,
        keyInsights: tips,
        actionPlan: [
          'حدد سقفاً أسبوعياً لمصروفات البقالة ولا تتجاوزه.',
          'خصص ما لا يقل عن 10% من الدخل الشهري لصندوق طوارئ الأسرة.',
          'راجع فواتير الاشتراكات والإنترنت وتأكد من ملائمة الباقات لاستهلاك البيت الفعلي.'
        ]
      };
    };

    try {
      const payload = {
        monthlyIncome: totalIncome,
        monthlyExpense: totalExpense,
        currency: currency.name,
        categoriesSummary: sortedCategories.map((c) => ({
          name: c.name,
          spent: c.amount,
          limit: budgets.find((b) => b.categoryId === c.id)?.monthlyLimit || 500,
        })),
        topExpenses: currentMonthExpenses
          .sort((a, b) => b.amount - a.amount)
          .slice(0, 5)
          .map((t) => ({ title: t.title, amount: t.amount, category: getCategoryById(t.category).name })),
        debtSummary: {
          owedByUs: debtsOwedByUs,
          owedToUs: debtsOwedToUs,
        },
        questionPrompt: customPrompt || questionPrompt || undefined,
      };

      const response = await fetch('/api/advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (response.ok) {
        const resData = await response.json();
        if (resData.success && resData.data) {
          setAdvisorData(resData.data);
          setAdvisorSource(resData.source);
          return;
        }
      }

      // Fallback locally if response was not ok or failed
      setAdvisorData(generateLocalAdvice());
      setAdvisorSource('local_engine');
    } catch {
      // Offline or network error: use local engine smoothly
      setAdvisorData(generateLocalAdvice());
      setAdvisorSource('local_engine');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4 pb-24 text-slate-800 dark:text-slate-100">
      
      {/* Visual Category Breakdown Card */}
      <div className="p-4 rounded-3xl bg-white/85 dark:bg-slate-850/85 backdrop-blur-md border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-purple-50 dark:bg-purple-950 text-purple-600 flex items-center justify-center">
              <PieChart className="w-4 h-4" />
            </div>
            <h3 className="font-bold text-xs text-slate-900 dark:text-white">
              أين ذهبت أموال البيت هذا الشهر؟
            </h3>
          </div>
          <span className="text-[11px] text-slate-500 tabular-nums">
            إجمالي: {formatCurrency(totalExpense, currency.symbol)}
          </span>
        </div>

        {/* Multi-color segment bar */}
        {sortedCategories.length > 0 ? (
          <div className="space-y-3">
            <div className="w-full h-3 rounded-full flex overflow-hidden bg-slate-100 dark:bg-slate-700">
              {sortedCategories.map((cat) => (
                <div
                  key={cat.id}
                  style={{
                    width: `${cat.percent}%`,
                    backgroundColor: cat.color,
                  }}
                  title={`${cat.name}: ${cat.percent}%`}
                  className="h-full transition-all"
                />
              ))}
            </div>

            {/* Top 4 spending items list */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              {sortedCategories.slice(0, 4).map((cat) => (
                <div
                  key={cat.id}
                  className="p-2.5 rounded-xl bg-slate-50/80 dark:bg-slate-800/80 border border-slate-100 dark:border-slate-750 flex items-center justify-between"
                >
                  <div className="flex items-center gap-1.5 overflow-hidden">
                    <span
                      className="w-2.5 h-2.5 rounded-full shrink-0"
                      style={{ backgroundColor: cat.color }}
                    />
                    <span className="text-[11px] text-slate-700 dark:text-slate-300 truncate">
                      {cat.name}
                    </span>
                  </div>
                  <span className="font-bold tabular-nums text-[11px]">
                    {cat.percent}%
                  </span>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <p className="text-xs text-slate-500 text-center py-3">
            لم يتم تسجيل مصاريف لهذا الشهر بعد
          </p>
        )}
      </div>

      {/* Family Members Spending Distribution */}
      <div className="p-4 rounded-3xl bg-white/85 dark:bg-slate-850/85 backdrop-blur-md border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-blue-50 dark:bg-blue-950 text-blue-600 flex items-center justify-center">
            <Users className="w-4 h-4" />
          </div>
          <h3 className="font-bold text-xs text-slate-900 dark:text-white">
            توزيع المصاريف حسب أفراد الأسرة
          </h3>
        </div>

        <div className="grid grid-cols-2 gap-2">
          {familyMembers.map((member) => {
            const spent = memberSpendingMap[member.id] || 0;
            const pct = totalExpense > 0 ? Math.round((spent / totalExpense) * 100) : 0;

            return (
              <div
                key={member.id}
                className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-750 flex items-center gap-2.5"
              >
                <span className="text-2xl">{member.avatar}</span>
                <div className="overflow-hidden flex-1">
                  <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                    {member.name}
                  </p>
                  <p className="text-[11px] text-slate-500 tabular-nums">
                    {spent.toLocaleString('ar-EG')} {currency.symbol} ({pct}%)
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* AI SMART HOUSEHOLD ADVISOR CARD */}
      <div className="p-5 rounded-3xl bg-gradient-to-br from-emerald-900 via-teal-900 to-slate-900 text-white shadow-xl space-y-4 relative overflow-hidden">
        {/* Glow backdrop */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex items-center justify-between relative z-10">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-400 to-yellow-500 text-slate-950 flex items-center justify-center shadow-md">
              <Sparkles className="w-5 h-5 fill-slate-950" />
            </div>
            <div>
              <h3 className="text-sm font-bold flex items-center gap-1.5">
                <span>المستشار المالي الذكي للمنزل</span>
                <span className="text-[10px] bg-emerald-500/30 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-400/30 font-medium">
                  {advisorSource === 'gemini_ai' ? 'Gemini AI' : 'مستشار مالي ذكي'}
                </span>
              </h3>
              <p className="text-emerald-200/80 text-[11px]">
                تحليل تلقائي لنفقاتك وتقديم حلول موجهة لتوفير مصاريف البيت
              </p>
            </div>
          </div>
        </div>

        {/* Generate / Refresh Advice CTA */}
        <div className="relative z-10">
          {!advisorData ? (
            <button
              onClick={() => fetchAdvice()}
              disabled={loading}
              className="w-full py-3 bg-gradient-to-l from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-extrabold rounded-2xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 active:scale-95 transition-all cursor-pointer"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>جاري تحليل ميزانية وفواتير المنزل بدقة...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>بدء تحليل الميزانية واستخراج خطة التوفير</span>
                </>
              )}
            </button>
          ) : (
            <button
              onClick={() => fetchAdvice()}
              disabled={loading}
              className="text-xs text-emerald-300 hover:text-white flex items-center gap-1 font-semibold cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span>تحديث تحليل الميزانية بناءً على أحدث العمليات</span>
            </button>
          )}
        </div>

        {errorMsg && (
          <p className="text-xs text-rose-300 bg-rose-950/60 p-2.5 rounded-xl border border-rose-800">
            {errorMsg}
          </p>
        )}

        {/* Advisor Results Display */}
        {advisorData && (
          <div className="space-y-4 pt-2 relative z-10 animate-in fade-in duration-300 text-xs">
            
            {/* Health Score & Summary Dial */}
            <div className="p-3.5 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 flex items-center gap-3.5">
              <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 border border-emerald-400/40 flex flex-col items-center justify-center text-center shrink-0">
                <span className="text-lg font-black text-emerald-300 tabular-nums">
                  {advisorData.healthScore}
                </span>
                <span className="text-[9px] text-emerald-200">صحة الميزانية</span>
              </div>
              <div>
                <h4 className="font-bold text-white text-xs mb-0.5">
                  تشخيص الوضع المالي للأسرة
                </h4>
                <p className="text-emerald-100/90 text-[11px] leading-relaxed">
                  {advisorData.summaryText}
                </p>
              </div>
            </div>

            {/* Key Insights & Savings Opportunities */}
            <div className="space-y-2">
              <h4 className="font-bold text-amber-300 text-xs flex items-center gap-1.5">
                <Lightbulb className="w-4 h-4" />
                <span>أبرز فرص التوفير المتاحة لمنزلك:</span>
              </h4>
              <div className="space-y-1.5">
                {advisorData.keyInsights.map((insight, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 rounded-xl bg-white/5 border border-white/10 flex items-start gap-2 text-[11px] text-slate-100 leading-relaxed"
                  >
                    <span className="text-emerald-400 font-bold shrink-0">·</span>
                    <span>{insight}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Action Plan */}
            <div className="space-y-2">
              <h4 className="font-bold text-emerald-300 text-xs flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4" />
                <span>خطة العمل المقترحة للأسبوع الحالي:</span>
              </h4>
              <div className="space-y-1.5">
                {advisorData.actionPlan.map((action, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 rounded-xl bg-emerald-950/60 border border-emerald-500/20 flex items-center gap-2 text-[11px] text-emerald-100"
                  >
                    <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>{action}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Custom Question input to AI */}
            <div className="pt-2 border-t border-white/15 space-y-2">
              <label className="text-slate-200 text-[11px] font-semibold block">
                هل لديك استفسار محدد حول مصاريف منزلك؟
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={questionPrompt}
                  onChange={(e) => setQuestionPrompt(e.target.value)}
                  placeholder="مثال: كيف أقلل فاتورة الكهرباء في الصيف؟"
                  className="flex-1 p-2.5 rounded-xl bg-white/10 border border-white/20 text-white placeholder-slate-400 text-xs focus:outline-hidden focus:border-emerald-400"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') fetchAdvice(questionPrompt);
                  }}
                />
                <button
                  onClick={() => fetchAdvice(questionPrompt)}
                  disabled={loading || !questionPrompt.trim()}
                  className="p-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl transition-all disabled:opacity-50 cursor-pointer shrink-0"
                  title="إرسال السؤال للمستشار"
                >
                  <Send className="w-4 h-4 rotate-180" />
                </button>
              </div>
            </div>

          </div>
        )}
      </div>

    </div>
  );
};
