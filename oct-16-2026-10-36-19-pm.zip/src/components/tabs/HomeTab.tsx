import React from 'react';
import {
  TrendingDown,
  TrendingUp,
  Wallet,
  Calendar,
  AlertTriangle,
  CheckCircle2,
  ArrowRight,
  PlusCircle,
  FileSpreadsheet,
  Zap,
  Lightbulb,
  PiggyBank,
  Sparkles,
  Users,
} from 'lucide-react';
import {
  Transaction,
  BillItem,
  FamilyMember,
  SavingsGoal,
  CurrencyConfig,
} from '../../types';
import { getCategoryById } from '../../constants/categories';
import { CategoryIcon } from '../CategoryIcon';
import { formatCurrency } from '../../constants/currencies';
import { TabType } from '../BottomNavBar';

interface HomeTabProps {
  transactions: Transaction[];
  bills: BillItem[];
  familyMembers: FamilyMember[];
  savingsGoals: SavingsGoal[];
  currency: CurrencyConfig;
  monthlyTotalBudget: number;
  themeAccent?: string;
  onOpenQuickAdd: () => void;
  onNavigateTab: (tab: TabType) => void;
  onPayBillQuick: (billId: string) => void;
  onExportReport: () => void;
}

export const HomeTab: React.FC<HomeTabProps> = ({
  transactions,
  bills,
  familyMembers,
  savingsGoals,
  currency,
  monthlyTotalBudget,
  themeAccent = 'emerald',
  onOpenQuickAdd,
  onNavigateTab,
  onPayBillQuick,
  onExportReport,
}) => {
  // Calculations for current month
  const now = new Date();
  const currentMonthStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;

  const currentMonthTx = transactions.filter((t) =>
    t.date.startsWith(currentMonthStr)
  );

  const totalIncome = currentMonthTx
    .filter((t) => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);

  // Separate Sudden Income vs Regular Salary/Income
  const suddenIncomeTotal = currentMonthTx
    .filter((t) => t.type === 'income' && t.isSuddenIncome)
    .reduce((sum, t) => sum + t.amount, 0);

  const regularIncomeTotal = totalIncome - suddenIncomeTotal;

  const totalExpense = currentMonthTx
    .filter((t) => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);

  const remaining = totalIncome - totalExpense;
  const effectiveBudget = monthlyTotalBudget > 0 ? monthlyTotalBudget : (totalIncome > 0 ? totalIncome : 5000);
  const budgetSpentPercent = Math.min(
    100,
    Math.round((totalExpense / (effectiveBudget || 1)) * 100)
  );

  // Unpaid bills for current month
  const unpaidBills = bills.filter((b) => !b.isPaid);

  // Total in family wallets & savings goals
  const totalInFamilyWallets = familyMembers.reduce((sum, m) => sum + m.walletBalance, 0);
  const totalSavedInGoals = savingsGoals.reduce((sum, g) => sum + g.currentAmount, 0);

  // Recent 5 transactions
  const recentTransactions = [...transactions]
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 5);

  const getPayerName = (memberId?: string) => {
    if (!memberId) return 'الأسرة';
    const member = familyMembers.find((m) => m.id === memberId);
    return member ? `${member.avatar} ${member.name.split(' ')[0]}` : 'الأسرة';
  };

  const getHeroGradient = () => {
    switch (themeAccent) {
      case 'sapphire':
        return 'from-slate-950 via-blue-950 to-indigo-950 border-blue-500/30 shadow-blue-950/40';
      case 'amber':
        return 'from-stone-950 via-amber-950 to-slate-950 border-amber-500/30 shadow-amber-950/40';
      case 'amethyst':
        return 'from-slate-950 via-purple-950 to-fuchsia-950 border-purple-500/30 shadow-purple-950/40';
      case 'emerald':
      default:
        return 'from-emerald-950 via-teal-900 to-slate-950 border-emerald-500/30 shadow-emerald-950/40';
    }
  };

  return (
    <div className="space-y-4 pb-24 text-slate-800 dark:text-slate-100 animate-in fade-in duration-200">
      
      {/* Hero Financial Health Card with dynamic theme gradient */}
      <div className={`relative overflow-hidden rounded-3xl bg-gradient-to-br ${getHeroGradient()} text-white p-5 shadow-xl border`}>
        
        {/* Background ambient lighting */}
        <div className="absolute -top-12 -left-12 w-48 h-48 bg-white/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-8 -right-8 w-40 h-40 bg-emerald-400/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 space-y-4">
          
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-200 font-medium flex items-center gap-1.5">
              <Wallet className="w-4 h-4 text-emerald-300" />
              <span>الرصيد المالي المتبقي للشهر</span>
            </span>
            <div className="flex items-center gap-1 text-xs font-semibold">
              <span className={remaining >= 0 ? 'text-emerald-300' : 'text-rose-300'}>
                {remaining >= 0 ? '● فائض مالي متاح' : '▲ تجاوز في الميزانية'}
              </span>
            </div>
          </div>

          {/* Big Balance Number */}
          <div className="flex items-baseline gap-2">
            <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight tabular-nums">
              {formatCurrency(remaining, currency.symbol)}
            </h2>
          </div>

          {/* Budget Consumption Bar */}
          <div className="space-y-1.5 pt-1">
            <div className="flex items-center justify-between text-xs text-emerald-100">
              <span>استهلاك ميزانية الشهر ({effectiveBudget.toLocaleString('ar-EG')} {currency.symbol})</span>
              <span className="font-bold tabular-nums">{budgetSpentPercent}%</span>
            </div>
            <div className="w-full h-2.5 bg-emerald-950/50 rounded-full overflow-hidden p-0.5">
              <div
                className={`h-full rounded-full transition-all duration-500 ${
                  budgetSpentPercent > 90
                    ? 'bg-rose-400'
                    : budgetSpentPercent > 75
                    ? 'bg-amber-400'
                    : 'bg-emerald-300'
                }`}
                style={{ width: `${budgetSpentPercent}%` }}
              />
            </div>
          </div>

          {/* Income breakdown: Regular Salary + Sudden Income */}
          <div className="grid grid-cols-2 gap-2 pt-2 border-t border-emerald-600/50 text-xs">
            <div className="bg-emerald-900/40 rounded-2xl p-2.5 space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-emerald-200">إجمالي الدخل</span>
                <TrendingUp className="w-3.5 h-3.5 text-emerald-300" />
              </div>
              <p className="font-bold text-sm truncate tabular-nums">
                {formatCurrency(totalIncome, currency.symbol)}
              </p>
              {suddenIncomeTotal > 0 && (
                <p className="text-[10px] text-amber-300 font-semibold truncate flex items-center gap-0.5">
                  <Sparkles className="w-3 h-3 text-amber-400" />
                  <span>منه {suddenIncomeTotal} {currency.symbol} دخل مفاجئ</span>
                </p>
              )}
            </div>

            <div className="bg-emerald-900/40 rounded-2xl p-2.5 space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-rose-200">إجمالي المصاريف</span>
                <TrendingDown className="w-3.5 h-3.5 text-rose-300" />
              </div>
              <p className="font-bold text-sm truncate tabular-nums text-rose-200">
                {formatCurrency(totalExpense, currency.symbol)}
              </p>
              <p className="text-[10px] text-emerald-200/80 truncate">
                المتبقي للصرف: {Math.max(0, effectiveBudget - totalExpense)} {currency.symbol}
              </p>
            </div>
          </div>

        </div>
      </div>

      {/* Quick Action Buttons Strip */}
      <div className="grid grid-cols-4 gap-2">
        <button
          onClick={onOpenQuickAdd}
          className="p-2.5 rounded-2xl bg-white/85 dark:bg-slate-850/85 backdrop-blur-md border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-col items-center justify-center gap-1.5 hover:bg-white dark:hover:bg-slate-800 transition-all cursor-pointer group active:scale-95"
        >
          <div className="w-10 h-10 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center group-hover:scale-105 transition-transform shadow-2xs">
            <PlusCircle className="w-5 h-5" />
          </div>
          <span className="text-[11px] font-bold text-slate-800 dark:text-slate-200">
            تسجيل مصروف
          </span>
        </button>

        <button
          onClick={() => onNavigateTab('savings')}
          className="p-2.5 rounded-2xl bg-white/85 dark:bg-slate-850/85 backdrop-blur-md border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-col items-center justify-center gap-1.5 hover:bg-white dark:hover:bg-slate-800 transition-all cursor-pointer group active:scale-95"
        >
          <div className="w-10 h-10 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 flex items-center justify-center group-hover:scale-105 transition-transform shadow-2xs">
            <PiggyBank className="w-5 h-5" />
          </div>
          <span className="text-[11px] font-bold text-slate-800 dark:text-slate-200">
            الادخار والصناديق
          </span>
        </button>

        <button
          onClick={() => onNavigateTab('budgets')}
          className="p-2.5 rounded-2xl bg-white/85 dark:bg-slate-850/85 backdrop-blur-md border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-col items-center justify-center gap-1.5 hover:bg-white dark:hover:bg-slate-800 transition-all cursor-pointer group active:scale-95"
        >
          <div className="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center group-hover:scale-105 transition-transform shadow-2xs">
            <Zap className="w-5 h-5" />
          </div>
          <span className="text-[11px] font-bold text-slate-800 dark:text-slate-200">
            الميزانيات
          </span>
        </button>

        <button
          onClick={onExportReport}
          className="p-2.5 rounded-2xl bg-white/85 dark:bg-slate-850/85 backdrop-blur-md border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-col items-center justify-center gap-1.5 hover:bg-white dark:hover:bg-slate-800 transition-all cursor-pointer group active:scale-95"
        >
          <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center group-hover:scale-105 transition-transform shadow-2xs">
            <FileSpreadsheet className="w-5 h-5" />
          </div>
          <span className="text-[11px] font-bold text-slate-800 dark:text-slate-200">
            تصدير تقرير
          </span>
        </button>
      </div>

      {/* QUICK GLANCE: FAMILY WALLETS & SAVINGS GOALS */}
      <div className="grid grid-cols-2 gap-2.5">
        {/* Family funds card */}
        <div
          onClick={() => onNavigateTab('savings')}
          className="p-4 rounded-3xl bg-white/85 dark:bg-slate-850/85 backdrop-blur-md border border-slate-200/80 dark:border-slate-800 shadow-xs cursor-pointer hover:bg-white dark:hover:bg-slate-800 transition-all space-y-1.5 active:scale-98"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>صناديق الأسرة</span>
            </span>
            <ArrowRight className="w-3 h-3 text-slate-400 rotate-180" />
          </div>
          <p className="text-base font-extrabold text-emerald-600 dark:text-emerald-400 tabular-nums">
            {formatCurrency(totalInFamilyWallets, currency.symbol)}
          </p>
          <p className="text-[10px] text-slate-500 dark:text-slate-400">
            موزعة بين {familyMembers.length} أفراد بالأسرة
          </p>
        </div>

        {/* Savings Goals card */}
        <div
          onClick={() => onNavigateTab('savings')}
          className="p-4 rounded-3xl bg-white/85 dark:bg-slate-850/85 backdrop-blur-md border border-slate-200/80 dark:border-slate-800 shadow-xs cursor-pointer hover:bg-white dark:hover:bg-slate-800 transition-all space-y-1.5 active:scale-98"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
              <PiggyBank className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
              <span>أهداف الادخار</span>
            </span>
            <ArrowRight className="w-3 h-3 text-slate-400 rotate-180" />
          </div>
          <p className="text-base font-extrabold text-teal-600 dark:text-teal-400 tabular-nums">
            {formatCurrency(totalSavedInGoals, currency.symbol)}
          </p>
          <p className="text-[10px] text-slate-500 dark:text-slate-400">
            {savingsGoals.length} أهداف ادخار متجددة
          </p>
        </div>
      </div>

      {/* Household Money Tip */}
      <div className="p-3.5 rounded-2xl bg-amber-50/90 dark:bg-amber-950/40 border border-amber-200/70 dark:border-amber-800/40 flex items-start gap-3 text-xs">
        <div className="w-8 h-8 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-xs">
          <Lightbulb className="w-4 h-4" />
        </div>
        <div>
          <h3 className="font-bold text-amber-950 dark:text-amber-200 mb-0.5">
            فكرة تدبير منزلية ذكية
          </h3>
          <p className="text-amber-800 dark:text-amber-300/90 text-[11px] leading-relaxed">
            تخصيص أي <strong>دخل مفاجئ أو إضافي</strong> بنسبة 50% لأهداف الادخار وصندوق الطوارئ و50% لمستلزمات الأسرة يمنع ذوبان المبالغ غير المتوقعة في النثريات اليومية!
          </p>
        </div>
      </div>

      {/* Upcoming Unpaid Bills Section */}
      {unpaidBills.length > 0 && (
        <div className="space-y-2">
          <div className="flex items-center justify-between px-1">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800 dark:text-slate-200">
              <Zap className="w-4 h-4 text-amber-500" />
              <span>فواتير تنتظر السداد ({unpaidBills.length})</span>
            </div>
            <button
              onClick={() => onNavigateTab('budgets')}
              className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-0.5 hover:underline"
            >
              <span>إدارة الفواتير</span>
              <ArrowRight className="w-3 h-3 rotate-180" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {unpaidBills.slice(0, 2).map((bill) => (
              <div
                key={bill.id}
                className="p-3 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-xs flex items-center justify-between"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-amber-50 dark:bg-amber-950 text-amber-600 flex items-center justify-center shrink-0">
                    <Calendar className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-bold text-xs text-slate-900 dark:text-white line-clamp-1">
                      {bill.title}
                    </h4>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      يستحق يوم {bill.dueDay} من الشهر ·{' '}
                      <span className="font-bold text-amber-600 dark:text-amber-400 tabular-nums">
                        {bill.amount} {currency.symbol}
                      </span>
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => onPayBillQuick(bill.id)}
                  className="px-2.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:hover:bg-emerald-900 dark:text-emerald-300 font-bold rounded-xl text-[11px] transition-all cursor-pointer shrink-0 flex items-center gap-1"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>تم السداد</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Recent Transactions List */}
      <div className="space-y-2">
        <div className="flex items-center justify-between px-1">
          <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
            أحدث عمليات المنزل
          </span>
          <button
            onClick={() => onNavigateTab('transactions')}
            className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-0.5 hover:underline"
          >
            <span>عرض كل العمليات ({transactions.length})</span>
            <ArrowRight className="w-3 h-3 rotate-180" />
          </button>
        </div>

        {recentTransactions.length === 0 ? (
          <div className="p-6 text-center rounded-3xl bg-white/80 dark:bg-slate-850/80 backdrop-blur-md border border-dashed border-slate-200 dark:border-slate-800">
            <p className="text-xs text-slate-500 mb-2">لا توجد عمليات مسجلة بعد</p>
            <button
              onClick={onOpenQuickAdd}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs cursor-pointer active:scale-95 transition-all"
            >
              + إضافة أول مصروف الآن
            </button>
          </div>
        ) : (
          <div className="bg-white/85 dark:bg-slate-850/85 backdrop-blur-md rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-xs divide-y divide-slate-100 dark:divide-slate-800 overflow-hidden">
            {recentTransactions.map((tx) => {
              const cat = getCategoryById(tx.category);
              const isExpense = tx.type === 'expense';

              return (
                <div
                  key={tx.id}
                  className="p-3.5 flex items-center justify-between hover:bg-slate-50/80 dark:hover:bg-slate-800/60 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className="w-10 h-10 rounded-2xl flex items-center justify-center text-white shrink-0 shadow-2xs"
                      style={{ backgroundColor: cat.color }}
                    >
                      <CategoryIcon name={cat.icon} className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-xs text-slate-900 dark:text-white line-clamp-1">
                          {tx.title}
                        </h4>
                        {tx.isSuddenIncome && (
                          <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400">
                            ⚡ دخل مفاجئ
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                        <span>{cat.name}</span>
                        <span aria-hidden="true">·</span>
                        <span>{getPayerName(tx.familyMemberId)}</span>
                        <span aria-hidden="true">·</span>
                        <span>{tx.date}</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-left shrink-0">
                    <span
                      className={`text-sm font-extrabold tabular-nums ${
                        isExpense
                          ? 'text-rose-600 dark:text-rose-400'
                          : 'text-emerald-600 dark:text-emerald-400'
                      }`}
                    >
                      {isExpense ? '-' : '+'}
                      {tx.amount.toLocaleString('ar-EG')} {currency.symbol}
                    </span>
                    <p className="text-[10px] text-slate-400">
                      {tx.paymentMethod === 'cash'
                        ? 'نقداً'
                        : tx.paymentMethod === 'card'
                        ? 'بطاقة'
                        : 'تحويل'}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

    </div>
  );
};
