import React, { useState } from 'react';
import {
  PieChart,
  Edit2,
  AlertCircle,
  CheckCircle,
  Plus,
  Sliders,
  DollarSign,
  Check,
  X,
  Zap,
  HandCoins,
  Calendar,
  CheckCircle2,
  Trash2,
} from 'lucide-react';
import {
  Transaction,
  CategoryBudget,
  BillItem,
  DebtItem,
  CurrencyConfig,
} from '../../types';
import { EXPENSE_CATEGORIES } from '../../constants/categories';
import { CategoryIcon } from '../CategoryIcon';
import { formatCurrency } from '../../constants/currencies';

interface BudgetsTabProps {
  transactions: Transaction[];
  budgets: CategoryBudget[];
  bills: BillItem[];
  debts: DebtItem[];
  currency: CurrencyConfig;
  monthlyTotalBudget: number;
  onUpdateTotalBudget: (amount: number) => void;
  onUpdateCategoryBudget: (categoryId: string, limit: number) => void;
  onToggleBillPaid: (billId: string) => void;
  onAddBill: (bill: Omit<BillItem, 'id'>) => void;
  onDeleteBill: (billId: string) => void;
  onToggleDebtPaid: (debtId: string) => void;
  onAddDebt: (debt: Omit<DebtItem, 'id' | 'createdAt'>) => void;
  onDeleteDebt: (debtId: string) => void;
}

export const BudgetsTab: React.FC<BudgetsTabProps> = ({
  transactions,
  budgets,
  bills,
  debts,
  currency,
  monthlyTotalBudget,
  onUpdateTotalBudget,
  onUpdateCategoryBudget,
  onToggleBillPaid,
  onAddBill,
  onDeleteBill,
  onToggleDebtPaid,
  onAddDebt,
  onDeleteDebt,
}) => {
  const [subSection, setSubSection] = useState<'categories' | 'bills' | 'debts'>('categories');
  const [isEditingTotal, setIsEditingTotal] = useState(false);
  const [totalInput, setTotalInput] = useState(String(monthlyTotalBudget));
  const [editingCategoryId, setEditingCategoryId] = useState<string | null>(null);
  const [categoryInput, setCategoryInput] = useState<string>('');

  // Modals for adding bill & debt
  const [showAddBillModal, setShowAddBillModal] = useState(false);
  const [newBillTitle, setNewBillTitle] = useState('');
  const [newBillAmount, setNewBillAmount] = useState('');
  const [newBillDueDay, setNewBillDueDay] = useState('25');
  const [newBillNotes, setNewBillNotes] = useState('');

  const [showAddDebtModal, setShowAddDebtModal] = useState(false);
  const [newDebtType, setNewDebtType] = useState<'owed_by_us' | 'owed_to_us'>('owed_by_us');
  const [newDebtPerson, setNewDebtPerson] = useState('');
  const [newDebtAmount, setNewDebtAmount] = useState('');
  const [newDebtDueDate, setNewDebtDueDate] = useState('');
  const [newDebtNotes, setNewDebtNotes] = useState('');

  // Calculate current month spending per category
  const now = new Date();
  const currentMonthStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  
  const currentMonthExpenses = transactions.filter(
    (t) => t.type === 'expense' && t.date.startsWith(currentMonthStr)
  );

  const spendingByCategory: Record<string, number> = {};
  currentMonthExpenses.forEach((t) => {
    spendingByCategory[t.category] = (spendingByCategory[t.category] || 0) + t.amount;
  });

  const totalSpent = Object.values(spendingByCategory).reduce((a, b) => a + b, 0);

  const handleSaveTotal = () => {
    const val = parseFloat(totalInput);
    if (!isNaN(val) && val > 0) {
      onUpdateTotalBudget(val);
      setIsEditingTotal(false);
    }
  };

  const handleSaveCategory = (catId: string) => {
    const val = parseFloat(categoryInput);
    if (!isNaN(val) && val >= 0) {
      onUpdateCategoryBudget(catId, val);
      setEditingCategoryId(null);
    }
  };

  const handleCreateBill = (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(newBillAmount);
    if (!newBillTitle.trim() || isNaN(amountNum) || amountNum <= 0) return;

    onAddBill({
      title: newBillTitle.trim(),
      amount: amountNum,
      dueDay: parseInt(newBillDueDay) || 1,
      category: 'utilities',
      isPaid: false,
      notes: newBillNotes.trim() || undefined,
    });

    setNewBillTitle('');
    setNewBillAmount('');
    setNewBillNotes('');
    setShowAddBillModal(false);
  };

  const handleCreateDebt = (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(newDebtAmount);
    if (!newDebtPerson.trim() || isNaN(amountNum) || amountNum <= 0) return;

    onAddDebt({
      type: newDebtType,
      personName: newDebtPerson.trim(),
      amount: amountNum,
      dueDate: newDebtDueDate || undefined,
      isPaid: false,
      notes: newDebtNotes.trim() || undefined,
    });

    setNewDebtPerson('');
    setNewDebtAmount('');
    setNewDebtDueDate('');
    setNewDebtNotes('');
    setShowAddDebtModal(false);
  };

  // Debts and Bills stats
  const totalBills = bills.reduce((sum, b) => sum + b.amount, 0);
  const unpaidBillsCount = bills.filter((b) => !b.isPaid).length;

  const totalOwedByUs = debts.filter((d) => d.type === 'owed_by_us' && !d.isPaid).reduce((s, d) => s + d.amount, 0);
  const totalOwedToUs = debts.filter((d) => d.type === 'owed_to_us' && !d.isPaid).reduce((s, d) => s + d.amount, 0);

  return (
    <div className="space-y-4 pb-24 text-slate-800 dark:text-slate-100">
      
      {/* 3-Way Sub-Section Switcher */}
      <div className="grid grid-cols-3 p-1 bg-slate-200/70 dark:bg-slate-800 rounded-2xl text-xs font-semibold gap-1">
        <button
          onClick={() => setSubSection('categories')}
          className={`py-2 rounded-xl transition-all cursor-pointer text-center ${
            subSection === 'categories'
              ? 'bg-white dark:bg-slate-750 text-slate-900 dark:text-white shadow-xs font-bold'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          سقوف الفئات
        </button>
        <button
          onClick={() => setSubSection('bills')}
          className={`py-2 rounded-xl transition-all cursor-pointer text-center ${
            subSection === 'bills'
              ? 'bg-white dark:bg-slate-750 text-slate-900 dark:text-white shadow-xs font-bold'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          الفواتير ({unpaidBillsCount > 0 ? `${unpaidBillsCount} مستحقة` : bills.length})
        </button>
        <button
          onClick={() => setSubSection('debts')}
          className={`py-2 rounded-xl transition-all cursor-pointer text-center ${
            subSection === 'debts'
              ? 'bg-white dark:bg-slate-750 text-slate-900 dark:text-white shadow-xs font-bold'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          الديون ({debts.filter((d) => !d.isPaid).length})
        </button>
      </div>

      {/* SUB-SECTION 1: CATEGORY BUDGETS */}
      {subSection === 'categories' && (
        <div className="space-y-4">
          {/* Total Budget Card */}
          <div className="p-5 rounded-3xl bg-white/85 dark:bg-slate-850/85 backdrop-blur-md border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                  <Sliders className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                    سقف ميزانية المنزل العامة
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    المبلغ الأقصى المخصص لكافة المصاريف هذا الشهر
                  </p>
                </div>
              </div>

              {!isEditingTotal ? (
                <button
                  onClick={() => {
                    setTotalInput(String(monthlyTotalBudget));
                    setIsEditingTotal(true);
                  }}
                  className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-750 text-slate-700 dark:text-slate-300 text-xs font-semibold flex items-center gap-1 cursor-pointer"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                  <span>تعديل السقف</span>
                </button>
              ) : (
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    value={totalInput}
                    onChange={(e) => setTotalInput(e.target.value)}
                    className="w-24 p-1.5 rounded-lg border border-emerald-500 bg-white dark:bg-slate-900 text-xs font-bold tabular-nums"
                    autoFocus
                  />
                  <button
                    onClick={handleSaveTotal}
                    className="p-1.5 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700"
                  >
                    <Check className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setIsEditingTotal(false)}
                    className="p-1.5 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-lg"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>

            {/* Big numbers row */}
            <div className="grid grid-cols-2 gap-3 pt-1">
              <div className="bg-slate-50 dark:bg-slate-750/50 p-3 rounded-2xl">
                <span className="text-[11px] text-slate-500 block">السقف الشهري المحدد</span>
                <span className="text-xl font-bold text-slate-900 dark:text-white tabular-nums">
                  {formatCurrency(monthlyTotalBudget, currency.symbol)}
                </span>
              </div>

              <div className="bg-slate-50 dark:bg-slate-750/50 p-3 rounded-2xl">
                <span className="text-[11px] text-slate-500 block">إجمالي ما تم صرفه</span>
                <span
                  className={`text-xl font-bold tabular-nums ${
                    totalSpent > monthlyTotalBudget
                      ? 'text-rose-600 dark:text-rose-400'
                      : 'text-emerald-600 dark:text-emerald-400'
                  }`}
                >
                  {formatCurrency(totalSpent, currency.symbol)}
                </span>
              </div>
            </div>

            {/* Global Progress bar */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs text-slate-500">
                <span>نسبة الاستهلاك الكلية</span>
                <span className="font-bold tabular-nums">
                  {Math.round((totalSpent / (monthlyTotalBudget || 1)) * 100)}%
                </span>
              </div>
              <div className="w-full h-3 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden p-0.5">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    totalSpent > monthlyTotalBudget
                      ? 'bg-rose-500'
                      : totalSpent > monthlyTotalBudget * 0.8
                      ? 'bg-amber-500'
                      : 'bg-emerald-500'
                  }`}
                  style={{
                    width: `${Math.min(100, (totalSpent / (monthlyTotalBudget || 1)) * 100)}%`,
                  }}
                />
              </div>
            </div>
          </div>

          {/* Category Budgets Grid */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 px-1">
              سقوف الفئات بالتفصيل ({EXPENSE_CATEGORIES.length} فئات)
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {EXPENSE_CATEGORIES.map((cat) => {
                const budgetLimit =
                  budgets.find((b) => b.categoryId === cat.id)?.monthlyLimit ||
                  cat.defaultLimit ||
                  500;
                const spent = spendingByCategory[cat.id] || 0;
                const remainingCat = budgetLimit - spent;
                const percent = Math.min(100, Math.round((spent / (budgetLimit || 1)) * 100));
                const isExceeded = spent > budgetLimit;
                const isNear = percent >= 80 && !isExceeded;
                const isEditing = editingCategoryId === cat.id;

                return (
                  <div
                    key={cat.id}
                    className="p-3.5 rounded-2xl bg-white/85 dark:bg-slate-850/85 backdrop-blur-md border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-2.5"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div
                          className="w-9 h-9 rounded-xl flex items-center justify-center text-white shrink-0 shadow-xs"
                          style={{ backgroundColor: cat.color }}
                        >
                          <CategoryIcon name={cat.icon} className="w-4 h-4" />
                        </div>
                        <div>
                          <h5 className="font-bold text-xs text-slate-900 dark:text-white">
                            {cat.name}
                          </h5>
                          <span className="text-[11px] text-slate-500">
                            متبقي:{' '}
                            <strong
                              className={`tabular-nums ${
                                remainingCat < 0
                                  ? 'text-rose-600 dark:text-rose-400'
                                  : 'text-slate-700 dark:text-slate-300'
                              }`}
                            >
                              {remainingCat.toLocaleString('ar-EG')} {currency.symbol}
                            </strong>
                          </span>
                        </div>
                      </div>

                      {!isEditing ? (
                        <button
                          onClick={() => {
                            setCategoryInput(String(budgetLimit));
                            setEditingCategoryId(cat.id);
                          }}
                          className="text-[11px] text-slate-400 hover:text-emerald-600 flex items-center gap-0.5 p-1 rounded-lg"
                        >
                          <span className="font-bold tabular-nums">{budgetLimit} {currency.symbol}</span>
                          <Edit2 className="w-3 h-3" />
                        </button>
                      ) : (
                        <div className="flex items-center gap-1">
                          <input
                            type="number"
                            value={categoryInput}
                            onChange={(e) => setCategoryInput(e.target.value)}
                            className="w-16 p-1 rounded border border-emerald-500 text-xs font-bold tabular-nums"
                            autoFocus
                          />
                          <button
                            onClick={() => handleSaveCategory(cat.id)}
                            className="p-1 bg-emerald-600 text-white rounded"
                          >
                            <Check className="w-3 h-3" />
                          </button>
                          <button
                            onClick={() => setEditingCategoryId(null)}
                            className="p-1 bg-slate-200 text-slate-700 rounded"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      )}
                    </div>

                    <div className="space-y-1">
                      <div className="flex justify-between text-[11px]">
                        <span className="text-slate-500 tabular-nums">
                          تم صرف: {spent.toLocaleString('ar-EG')} من {budgetLimit.toLocaleString('ar-EG')} {currency.symbol}
                        </span>
                        <span
                          className={`font-bold tabular-nums ${
                            isExceeded
                              ? 'text-rose-600 dark:text-rose-400'
                              : isNear
                              ? 'text-amber-600 dark:text-amber-400'
                              : 'text-emerald-600 dark:text-emerald-400'
                          }`}
                        >
                          {percent}%
                        </span>
                      </div>
                      <div className="w-full h-2 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-300 ${
                            isExceeded
                              ? 'bg-rose-500'
                              : isNear
                              ? 'bg-amber-500'
                              : 'bg-emerald-500'
                          }`}
                          style={{ width: `${percent}%` }}
                        />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* SUB-SECTION 2: BILLS */}
      {subSection === 'bills' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between px-1">
            <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200">
              فواتير الخدمات المنزلية المتكررة
            </h4>
            <button
              onClick={() => setShowAddBillModal(true)}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center gap-1 shadow-sm cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>إضافة فاتورة</span>
            </button>
          </div>

          <div className="space-y-2">
            {bills.map((bill) => (
              <div
                key={bill.id}
                className={`p-3.5 rounded-2xl bg-white/85 dark:bg-slate-850/85 backdrop-blur-md border transition-all shadow-xs flex items-center justify-between ${
                  bill.isPaid
                    ? 'border-emerald-300 dark:border-emerald-800/80 bg-emerald-50/20'
                    : 'border-slate-200/80 dark:border-slate-800'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 shadow-2xs ${
                      bill.isPaid
                        ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-600'
                        : 'bg-amber-100 dark:bg-amber-950 text-amber-600'
                    }`}
                  >
                    <Zap className="w-5 h-5" />
                  </div>
                  <div>
                    <h5 className="font-bold text-xs text-slate-900 dark:text-white flex items-center gap-2">
                      <span>{bill.title}</span>
                      {bill.isPaid && (
                        <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold">
                          ✓ تم السداد
                        </span>
                      )}
                    </h5>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      تستحق يوم {bill.dueDay} من كل شهر ·{' '}
                      <strong className="text-slate-800 dark:text-slate-200 tabular-nums">
                        {bill.amount.toLocaleString('ar-EG')} {currency.symbol}
                      </strong>
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => onToggleBillPaid(bill.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                      bill.isPaid
                        ? 'bg-slate-100 dark:bg-slate-750 text-slate-600 dark:text-slate-300'
                        : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm'
                    }`}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{bill.isPaid ? 'إلغاء' : 'تم السداد'}</span>
                  </button>

                  <button
                    onClick={() => onDeleteBill(bill.id)}
                    className="p-1.5 text-slate-300 hover:text-rose-500 rounded-lg"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUB-SECTION 3: DEBTS */}
      {subSection === 'debts' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between px-1">
            <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200">
              سجل الديون والالتزامات
            </h4>
            <button
              onClick={() => setShowAddDebtModal(true)}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center gap-1 shadow-sm cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>إضافة دين</span>
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="p-2.5 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/40 text-rose-800 dark:text-rose-300">
              <span className="text-[10px] block">علينا للغير</span>
              <span className="font-extrabold text-sm tabular-nums">
                {formatCurrency(totalOwedByUs, currency.symbol)}
              </span>
            </div>
            <div className="p-2.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/40 text-emerald-800 dark:text-emerald-300">
              <span className="text-[10px] block">لنا على الغير</span>
              <span className="font-extrabold text-sm tabular-nums">
                {formatCurrency(totalOwedToUs, currency.symbol)}
              </span>
            </div>
          </div>

          <div className="space-y-2">
            {debts.map((debt) => (
              <div
                key={debt.id}
                className="p-3.5 rounded-2xl bg-white/85 dark:bg-slate-850/85 backdrop-blur-md border border-slate-200/80 dark:border-slate-800 shadow-xs flex items-center justify-between"
              >
                <div>
                  <div className="flex items-center gap-1.5">
                    <span
                      className={`text-xs font-bold ${
                        debt.type === 'owed_by_us'
                          ? 'text-rose-600 dark:text-rose-400'
                          : 'text-emerald-600 dark:text-emerald-400'
                      }`}
                    >
                      {debt.type === 'owed_by_us' ? '● علينا للغير' : '● لنا على الغير'}
                    </span>
                    <span className="text-slate-300 dark:text-slate-600">·</span>
                    <h5 className="font-bold text-xs text-slate-900 dark:text-white">
                      {debt.personName}
                    </h5>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    المبلغ: <strong>{debt.amount.toLocaleString('ar-EG')} {currency.symbol}</strong>
                    {debt.dueDate && ` · موعد: ${debt.dueDate}`}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onToggleDebtPaid(debt.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer ${
                      debt.isPaid
                        ? 'bg-slate-100 text-slate-600'
                        : 'bg-emerald-600 text-white'
                    }`}
                  >
                    {debt.isPaid ? 'تمت التسوية' : 'تسوية'}
                  </button>
                  <button
                    onClick={() => onDeleteDebt(debt.id)}
                    className="p-1.5 text-slate-300 hover:text-rose-500"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Add Bill Modal */}
      {showAddBillModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-5 shadow-2xl space-y-4 text-xs">
            <div className="flex justify-between items-center border-b pb-2">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">إضافة فاتورة جديدة</h3>
              <button onClick={() => setShowAddBillModal(false)} className="text-slate-400">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleCreateBill} className="space-y-3">
              <input
                type="text"
                required
                placeholder="اسم الفاتورة (مثال: صيانة المصعد، الغاز)"
                value={newBillTitle}
                onChange={(e) => setNewBillTitle(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
              />
              <input
                type="number"
                required
                step="any"
                placeholder={`المبلغ (${currency.symbol})`}
                value={newBillAmount}
                onChange={(e) => setNewBillAmount(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-bold tabular-nums"
              />
              <input
                type="number"
                min="1"
                max="31"
                placeholder="يوم الاستحقاق (1-31)"
                value={newBillDueDay}
                onChange={(e) => setNewBillDueDay(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs tabular-nums"
              />
              <button
                type="submit"
                className="w-full py-2.5 bg-emerald-600 text-white font-bold rounded-xl text-xs"
              >
                حفظ الفاتورة
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Add Debt Modal */}
      {showAddDebtModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-5 shadow-2xl space-y-4 text-xs">
            <div className="flex justify-between items-center border-b pb-2">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">إضافة التزام / دين</h3>
              <button onClick={() => setShowAddDebtModal(false)} className="text-slate-400">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleCreateDebt} className="space-y-3">
              <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
                <button
                  type="button"
                  onClick={() => setNewDebtType('owed_by_us')}
                  className={`py-1.5 rounded-lg font-bold text-center ${
                    newDebtType === 'owed_by_us' ? 'bg-rose-600 text-white' : 'text-slate-600'
                  }`}
                >
                  علينا للغير
                </button>
                <button
                  type="button"
                  onClick={() => setNewDebtType('owed_to_us')}
                  className={`py-1.5 rounded-lg font-bold text-center ${
                    newDebtType === 'owed_to_us' ? 'bg-emerald-600 text-white' : 'text-slate-600'
                  }`}
                >
                  لنا على الغير
                </button>
              </div>
              <input
                type="text"
                required
                placeholder="اسم الشخص أو الجهة"
                value={newDebtPerson}
                onChange={(e) => setNewDebtPerson(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
              />
              <input
                type="number"
                required
                step="any"
                placeholder={`المبلغ (${currency.symbol})`}
                value={newDebtAmount}
                onChange={(e) => setNewDebtAmount(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-bold tabular-nums"
              />
              <button
                type="submit"
                className="w-full py-2.5 bg-emerald-600 text-white font-bold rounded-xl text-xs"
              >
                حفظ الالتزام
              </button>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
