import React, { useState } from 'react';
import {
  PiggyBank,
  Users,
  Plus,
  ArrowDownCircle,
  ArrowUpCircle,
  CheckCircle2,
  Calendar,
  Sparkles,
  Trophy,
  Trash2,
  Edit2,
  X,
  Check,
  Wallet,
} from 'lucide-react';
import {
  SavingsGoal,
  FamilyMember,
  Transaction,
  CurrencyConfig,
} from '../../types';
import { SAVINGS_GOAL_PRESETS } from '../../constants/categories';
import { CategoryIcon } from '../CategoryIcon';
import { formatCurrency } from '../../constants/currencies';

interface SavingsAndFundsTabProps {
  savingsGoals: SavingsGoal[];
  familyMembers: FamilyMember[];
  transactions: Transaction[];
  currency: CurrencyConfig;
  onDepositToGoal: (goalId: string, amount: number, note?: string) => void;
  onWithdrawFromGoal: (goalId: string, amount: number, note?: string) => void;
  onAddSavingsGoal: (goal: Omit<SavingsGoal, 'id' | 'createdAt'>) => void;
  onDeleteSavingsGoal: (goalId: string) => void;
  onDepositToFund: (memberId: string, amount: number, note?: string) => void;
  onWithdrawFromFund: (memberId: string, amount: number, note?: string) => void;
  onUpdateMemberAllowance: (memberId: string, allowance: number) => void;
}

export const SavingsAndFundsTab: React.FC<SavingsAndFundsTabProps> = ({
  savingsGoals,
  familyMembers,
  transactions,
  currency,
  onDepositToGoal,
  onWithdrawFromGoal,
  onAddSavingsGoal,
  onDeleteSavingsGoal,
  onDepositToFund,
  onWithdrawFromFund,
  onUpdateMemberAllowance,
}) => {
  const [activeSubView, setActiveSubView] = useState<'funds' | 'savings'>('funds');

  // Modal states for Goal Deposit/Withdraw
  const [targetGoal, setTargetGoal] = useState<SavingsGoal | null>(null);
  const [goalActionType, setGoalActionType] = useState<'deposit' | 'withdraw'>('deposit');
  const [goalAmountInput, setGoalAmountInput] = useState('');
  const [goalNoteInput, setGoalNoteInput] = useState('');

  // Modal states for Member Fund Deposit/Withdraw
  const [targetMember, setTargetMember] = useState<FamilyMember | null>(null);
  const [fundActionType, setFundActionType] = useState<'deposit' | 'withdraw'>('deposit');
  const [fundAmountInput, setFundAmountInput] = useState('');
  const [fundNoteInput, setFundNoteInput] = useState('');

  // Add new Goal Modal
  const [showAddGoalModal, setShowAddGoalModal] = useState(false);
  const [newGoalTitle, setNewGoalTitle] = useState('');
  const [newGoalTarget, setNewGoalTarget] = useState('');
  const [newGoalCurrent, setNewGoalCurrent] = useState('0');
  const [newGoalDate, setNewGoalDate] = useState('');
  const [newGoalCategory, setNewGoalCategory] = useState<SavingsGoal['category']>('emergency');
  const [newGoalNotes, setNewGoalNotes] = useState('');

  // Calculate total saved across goals
  const totalSavedInGoals = savingsGoals.reduce((sum, g) => sum + g.currentAmount, 0);
  const totalTargetInGoals = savingsGoals.reduce((sum, g) => sum + g.targetAmount, 0);

  // Calculate total in family wallets
  const totalInFamilyWallets = familyMembers.reduce((sum, m) => sum + m.walletBalance, 0);

  // Calculate expenses paid from each member's fund this month
  const now = new Date();
  const currentMonthStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  
  const memberSpendingMap: Record<string, number> = {};
  transactions
    .filter((t) => t.type === 'expense' && t.date.startsWith(currentMonthStr))
    .forEach((t) => {
      const fundId = t.fundId || t.familyMemberId || 'other';
      memberSpendingMap[fundId] = (memberSpendingMap[fundId] || 0) + t.amount;
    });

  const handleGoalActionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetGoal) return;
    const amt = parseFloat(goalAmountInput);
    if (isNaN(amt) || amt <= 0) return;

    if (goalActionType === 'deposit') {
      onDepositToGoal(targetGoal.id, amt, goalNoteInput);
    } else {
      onWithdrawFromGoal(targetGoal.id, amt, goalNoteInput);
    }

    setTargetGoal(null);
    setGoalAmountInput('');
    setGoalNoteInput('');
  };

  const handleFundActionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetMember) return;
    const amt = parseFloat(fundAmountInput);
    if (isNaN(amt) || amt <= 0) return;

    if (fundActionType === 'deposit') {
      onDepositToFund(targetMember.id, amt, fundNoteInput);
    } else {
      onWithdrawFromFund(targetMember.id, amt, fundNoteInput);
    }

    setTargetMember(null);
    setFundAmountInput('');
    setFundNoteInput('');
  };

  const handleCreateGoal = (e: React.FormEvent) => {
    e.preventDefault();
    const targetNum = parseFloat(newGoalTarget);
    const currentNum = parseFloat(newGoalCurrent) || 0;
    if (!newGoalTitle.trim() || isNaN(targetNum) || targetNum <= 0) return;

    let icon = 'PiggyBank';
    let color = '#059669';
    if (newGoalCategory === 'car') { icon = 'Car'; color = '#2563eb'; }
    else if (newGoalCategory === 'eid') { icon = 'Gift'; color = '#db2777'; }
    else if (newGoalCategory === 'house') { icon = 'Home'; color = '#7c3aed'; }
    else if (newGoalCategory === 'emergency') { icon = 'Shield'; color = '#059669'; }
    else if (newGoalCategory === 'travel') { icon = 'Palmtree'; color = '#d97706'; }
    else if (newGoalCategory === 'gold') { icon = 'Coins'; color = '#eab308'; }

    onAddSavingsGoal({
      title: newGoalTitle.trim(),
      targetAmount: targetNum,
      currentAmount: currentNum,
      targetDate: newGoalDate || undefined,
      category: newGoalCategory,
      color,
      icon,
      isCompleted: currentNum >= targetNum,
      notes: newGoalNotes.trim() || undefined,
    });

    setNewGoalTitle('');
    setNewGoalTarget('');
    setNewGoalCurrent('0');
    setNewGoalDate('');
    setNewGoalNotes('');
    setShowAddGoalModal(false);
  };

  return (
    <div className="space-y-4 pb-24 text-slate-800 dark:text-slate-100">
      
      {/* Top Segmented Sub-view: Family Funds vs Multi-Goal Savings */}
      <div className="flex items-center gap-1 p-1 bg-slate-200/70 dark:bg-slate-800 rounded-2xl text-xs font-semibold">
        <button
          onClick={() => setActiveSubView('funds')}
          className={`flex-1 py-2 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
            activeSubView === 'funds'
              ? 'bg-white dark:bg-slate-750 text-slate-900 dark:text-white shadow-xs font-bold'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Users className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          <span>صناديق ومحافظ الأسرة ({familyMembers.length})</span>
        </button>

        <button
          onClick={() => setActiveSubView('savings')}
          className={`flex-1 py-2 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
            activeSubView === 'savings'
              ? 'bg-white dark:bg-slate-750 text-slate-900 dark:text-white shadow-xs font-bold'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <PiggyBank className="w-4 h-4 text-teal-600 dark:text-teal-400" />
          <span>أهداف الادخار المتعددة ({savingsGoals.length})</span>
        </button>
      </div>

      {/* VIEW 1: FAMILY MEMBER FUNDS & WALLETS */}
      {activeSubView === 'funds' && (
        <div className="space-y-4">
          
          {/* Family Funds Summary Card */}
          <div className="p-4 rounded-3xl bg-white/85 dark:bg-slate-850/85 backdrop-blur-md border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-500 dark:text-slate-400">إجمالي أرصدة محافظ أفراد الأسرة</span>
                <h3 className="text-2xl font-black text-emerald-600 dark:text-emerald-400 tabular-nums">
                  {formatCurrency(totalInFamilyWallets, currency.symbol)}
                </h3>
              </div>
              <div className="w-10 h-10 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 flex items-center justify-center">
                <Wallet className="w-5 h-5" />
              </div>
            </div>

            <p className="text-[11px] text-slate-500 dark:text-slate-400 pt-1 border-t border-slate-100 dark:border-slate-800 leading-relaxed">
              💡 يتيح لك هذا القسم تخصيص صندوق مالي مستقل لكل فرد (الأب، الأم، الأبناء) مع إمكانية تحويل المصروف الشهري له، وإجراء الإيداع والسحب وتحديد المصاريف المخصومة من كل محفظة.
            </p>
          </div>

          {/* Members List Cards */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 px-1">
              صناديق ومحافظ الأفراد
            </h4>

            {familyMembers.map((member) => {
              const spentThisMonth = memberSpendingMap[member.id] || 0;

              return (
                <div
                  key={member.id}
                  className="p-4 rounded-3xl bg-white/85 dark:bg-slate-850/85 backdrop-blur-md border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3 hover:border-slate-300 dark:hover:border-slate-700 transition-all"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-3xl p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl">
                        {member.avatar}
                      </span>
                      <div>
                        <h5 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                          <span>{member.name}</span>
                          <span className="text-[11px] text-slate-500 dark:text-slate-400 font-normal">
                            · {member.relation}
                          </span>
                        </h5>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400">
                          المصروف الشهري المخصص: {member.monthlyAllowance || 0} {currency.symbol}
                        </p>
                      </div>
                    </div>

                    {/* Big Wallet Balance */}
                    <div className="text-left">
                      <span className="text-[10px] text-slate-400 block">الرصيد المتاح</span>
                      <span className="text-lg font-black text-emerald-600 dark:text-emerald-400 tabular-nums">
                        {formatCurrency(member.walletBalance, currency.symbol)}
                      </span>
                    </div>
                  </div>

                  {/* Fund Actions: Deposit (+), Withdraw (-), and Spent Indicator */}
                  <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-100 dark:border-slate-700/60 text-xs">
                    {/* Deposit button */}
                    <button
                      onClick={() => {
                        setTargetMember(member);
                        setFundActionType('deposit');
                      }}
                      className="py-2 px-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/60 dark:hover:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 font-bold flex items-center justify-center gap-1 transition-all cursor-pointer"
                    >
                      <ArrowDownCircle className="w-4 h-4 text-emerald-600" />
                      <span>إيداع / تحويل</span>
                    </button>

                    {/* Withdraw button */}
                    <button
                      onClick={() => {
                        setTargetMember(member);
                        setFundActionType('withdraw');
                      }}
                      className="py-2 px-2 rounded-xl bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/60 dark:hover:bg-rose-900/60 text-rose-700 dark:text-rose-300 font-bold flex items-center justify-center gap-1 transition-all cursor-pointer"
                    >
                      <ArrowUpCircle className="w-4 h-4 text-rose-600" />
                      <span>سحب نقدي</span>
                    </button>

                    {/* Total spent from this fund */}
                    <div className="p-1.5 rounded-xl bg-slate-50 dark:bg-slate-750 text-center flex flex-col justify-center">
                      <span className="text-[9px] text-slate-400">مصاريف الصندوق</span>
                      <span className="font-bold text-slate-800 dark:text-slate-200 tabular-nums text-[11px]">
                        {spentThisMonth.toLocaleString('ar-EG')} {currency.symbol}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* VIEW 2: MULTI-GOAL SAVINGS */}
      {activeSubView === 'savings' && (
        <div className="space-y-4">
          
          {/* Savings Overall Summary Card */}
          <div className="p-4 rounded-3xl bg-white/85 dark:bg-slate-850/85 backdrop-blur-md border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-500 dark:text-slate-400">إجمالي المدخرات في كافة الأهداف</span>
                <h3 className="text-2xl font-black text-emerald-600 dark:text-emerald-400 tabular-nums">
                  {formatCurrency(totalSavedInGoals, currency.symbol)}
                </h3>
              </div>
              <button
                onClick={() => setShowAddGoalModal(true)}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-xs cursor-pointer active:scale-95 transition-all"
              >
                <Plus className="w-4 h-4" />
                <span>هدف ادخار جديد</span>
              </button>
            </div>

            {/* Overall progress */}
            <div className="space-y-1 pt-1 border-t border-slate-100 dark:border-slate-800">
              <div className="flex justify-between text-xs text-slate-500 dark:text-slate-400">
                <span>المستهدف الكلي: {totalTargetInGoals.toLocaleString('ar-EG')} {currency.symbol}</span>
                <span className="font-bold tabular-nums">
                  {totalTargetInGoals > 0 ? Math.round((totalSavedInGoals / totalTargetInGoals) * 100) : 0}%
                </span>
              </div>
              <div className="w-full h-2.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden p-0.5">
                <div
                  className="h-full rounded-full bg-gradient-to-l from-emerald-500 to-teal-400 transition-all duration-500"
                  style={{
                    width: `${Math.min(100, totalTargetInGoals > 0 ? (totalSavedInGoals / totalTargetInGoals) * 100 : 0)}%`,
                  }}
                />
              </div>
            </div>
          </div>

          {/* Goals List */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 px-1">
              أهداف وصناديق الادخار المخصصة ({savingsGoals.length})
            </h4>

            {savingsGoals.length === 0 ? (
              <div className="p-8 text-center bg-white/80 dark:bg-slate-850/80 backdrop-blur-md rounded-3xl border border-dashed border-slate-200 dark:border-slate-800 text-xs text-slate-500 space-y-2">
                <p>لا توجد أهداف ادخار حالياً</p>
                <button
                  onClick={() => setShowAddGoalModal(true)}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold cursor-pointer active:scale-95 transition-all shadow-xs"
                >
                  + إنشاء أول هدف ادخاري للأسرة
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {savingsGoals.map((goal) => {
                  const percent = Math.min(
                    100,
                    Math.round((goal.currentAmount / (goal.targetAmount || 1)) * 100)
                  );
                  const isFinished = goal.currentAmount >= goal.targetAmount;
                  const remainingGoal = Math.max(0, goal.targetAmount - goal.currentAmount);

                  return (
                    <div
                      key={goal.id}
                      className={`p-4 rounded-3xl bg-white/85 dark:bg-slate-850/85 backdrop-blur-md border transition-all shadow-xs space-y-3 ${
                        isFinished
                          ? 'border-emerald-300 dark:border-emerald-700/80 bg-emerald-50/20'
                          : 'border-slate-200/80 dark:border-slate-800'
                      }`}
                    >
                      {/* Top Header of Goal */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2.5">
                          <div
                            className="w-10 h-10 rounded-2xl flex items-center justify-center text-white shrink-0 shadow-xs"
                            style={{ backgroundColor: goal.color }}
                          >
                            <CategoryIcon name={goal.icon} className="w-5 h-5" />
                          </div>
                          <div>
                            <h5 className="font-bold text-xs text-slate-900 dark:text-white flex items-center gap-1.5">
                              <span>{goal.title}</span>
                              {isFinished && (
                                <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-0.5">
                                  <Trophy className="w-3 h-3 text-amber-500" />
                                  <span>مكتمل 🏆</span>
                                </span>
                              )}
                            </h5>
                            <span className="text-[11px] text-slate-500 flex items-center gap-1">
                              {goal.targetDate && (
                                <>
                                  <Calendar className="w-3 h-3 text-emerald-600" />
                                  <span>الموعد: {goal.targetDate} · </span>
                                </>
                              )}
                              <span>متبقي: {remainingGoal.toLocaleString('ar-EG')} {currency.symbol}</span>
                            </span>
                          </div>
                        </div>

                        {/* Current vs Target */}
                        <div className="text-left shrink-0">
                          <span className="text-sm font-black text-slate-900 dark:text-white tabular-nums block">
                            {goal.currentAmount.toLocaleString('ar-EG')}{' '}
                            <span className="text-xs font-normal text-slate-500">
                              / {goal.targetAmount.toLocaleString('ar-EG')} {currency.symbol}
                            </span>
                          </span>
                          <span className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">
                            {percent}% مكتمل
                          </span>
                        </div>
                      </div>

                      {/* Progress Bar */}
                      <div className="space-y-1">
                        <div className="w-full h-2.5 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
                          <div
                            className="h-full rounded-full transition-all duration-500"
                            style={{
                              width: `${percent}%`,
                              backgroundColor: goal.color,
                            }}
                          />
                        </div>
                      </div>

                      {/* Notes if available */}
                      {goal.notes && (
                        <p className="text-[11px] text-slate-500 italic">
                          "{goal.notes}"
                        </p>
                      )}

                      {/* Action buttons: Deposit (+), Withdraw (-), Delete */}
                      <div className="flex items-center justify-between pt-1 border-t border-slate-100 dark:border-slate-700/60 text-xs">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => {
                              setTargetGoal(goal);
                              setGoalActionType('deposit');
                            }}
                            className="px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950 dark:hover:bg-emerald-900 text-emerald-700 dark:text-emerald-300 font-bold flex items-center gap-1 transition-all cursor-pointer"
                          >
                            <ArrowDownCircle className="w-3.5 h-3.5" />
                            <span>إيداع في الهدف</span>
                          </button>

                          <button
                            onClick={() => {
                              setTargetGoal(goal);
                              setGoalActionType('withdraw');
                            }}
                            className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-750 text-slate-700 dark:text-slate-300 font-semibold flex items-center gap-1 transition-all cursor-pointer"
                          >
                            <ArrowUpCircle className="w-3.5 h-3.5" />
                            <span>سحب</span>
                          </button>
                        </div>

                        <button
                          onClick={() => {
                            if (confirm(`حذف هدف ادخار "${goal.title}"؟`)) {
                              onDeleteSavingsGoal(goal.id);
                            }
                          }}
                          className="p-1.5 text-slate-300 hover:text-rose-600 rounded-lg cursor-pointer"
                          title="حذف هذا الهدف"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* MODAL 1: Deposit/Withdraw to Goal */}
      {targetGoal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-5 shadow-2xl space-y-4 text-xs">
            <div className="flex justify-between items-center border-b pb-2">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                <PiggyBank className="w-4 h-4 text-emerald-600" />
                <span>
                  {goalActionType === 'deposit' ? 'إيداع مدخرات جديدة في:' : 'سحب من مدخرات:'}{' '}
                  {targetGoal.title}
                </span>
              </h3>
              <button onClick={() => setTargetGoal(null)} className="text-slate-400">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleGoalActionSubmit} className="space-y-3">
              <div>
                <label className="block text-slate-600 mb-1">المبلغ المراد {goalActionType === 'deposit' ? 'إيداعه' : 'سحبه'} ({currency.symbol})</label>
                <input
                  type="number"
                  required
                  step="any"
                  autoFocus
                  placeholder="0.00"
                  value={goalAmountInput}
                  onChange={(e) => setGoalAmountInput(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm font-bold tabular-nums"
                />
              </div>

              <div>
                <label className="block text-slate-600 mb-1">ملاحظة (اختياري)</label>
                <input
                  type="text"
                  placeholder="مثال: من فائض راتب الشهر، من دخل إضافي..."
                  value={goalNoteInput}
                  onChange={(e) => setGoalNoteInput(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
                />
              </div>

              <button
                type="submit"
                className={`w-full py-2.5 text-white font-bold rounded-xl text-xs shadow-md mt-2 ${
                  goalActionType === 'deposit'
                    ? 'bg-emerald-600 hover:bg-emerald-700'
                    : 'bg-rose-600 hover:bg-rose-700'
                }`}
              >
                تأكيد الـ{goalActionType === 'deposit' ? 'إيداع' : 'سحب'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: Deposit/Withdraw to Family Member Fund */}
      {targetMember && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-5 shadow-2xl space-y-4 text-xs">
            <div className="flex justify-between items-center border-b pb-2">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                <Wallet className="w-4 h-4 text-emerald-600" />
                <span>
                  {fundActionType === 'deposit' ? 'إيداع في محفظة' : 'سحب من محفظة'}:{' '}
                  {targetMember.name}
                </span>
              </h3>
              <button onClick={() => setTargetMember(null)} className="text-slate-400">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleFundActionSubmit} className="space-y-3">
              <div>
                <label className="block text-slate-600 mb-1">
                  المبلغ المراد {fundActionType === 'deposit' ? 'إيداعه في صندوقه' : 'سحبه'} ({currency.symbol})
                </label>
                <input
                  type="number"
                  required
                  step="any"
                  autoFocus
                  placeholder="0.00"
                  value={fundAmountInput}
                  onChange={(e) => setFundAmountInput(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm font-bold tabular-nums"
                />
              </div>

              <div>
                <label className="block text-slate-600 mb-1">ملاحظة / سبب العملية</label>
                <input
                  type="text"
                  placeholder="مثال: تحويل المصروف الأسبوعي، مكافأة نجاح..."
                  value={fundNoteInput}
                  onChange={(e) => setFundNoteInput(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
                />
              </div>

              <button
                type="submit"
                className={`w-full py-2.5 text-white font-bold rounded-xl text-xs shadow-md mt-2 ${
                  fundActionType === 'deposit'
                    ? 'bg-emerald-600 hover:bg-emerald-700'
                    : 'bg-rose-600 hover:bg-rose-700'
                }`}
              >
                تأكيد {fundActionType === 'deposit' ? 'الإيداع والتحويل' : 'السحب'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: Add new Savings Goal */}
      {showAddGoalModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-5 shadow-2xl space-y-4 text-xs">
            <div className="flex justify-between items-center border-b pb-2">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                <PiggyBank className="w-4 h-4 text-emerald-600" />
                <span>إنشاء هدف ادخاري عائلي جديد</span>
              </h3>
              <button onClick={() => setShowAddGoalModal(false)} className="text-slate-400">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateGoal} className="space-y-3">
              {/* Presets */}
              <div>
                <label className="block text-slate-500 text-[11px] mb-1">نماذج ادخار جاهزة وسريعة:</label>
                <div className="flex flex-wrap gap-1">
                  {SAVINGS_GOAL_PRESETS.map((p) => (
                    <button
                      key={p.title}
                      type="button"
                      onClick={() => {
                        setNewGoalTitle(p.title);
                        setNewGoalTarget(String(p.defaultTarget));
                        setNewGoalCategory(p.category);
                      }}
                      className="px-2 py-0.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-[10px] text-slate-700 dark:text-slate-300"
                    >
                      {p.title}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-slate-600 mb-1">اسم الهدف الادخاري</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: شراء سيارة، طوارئ، كسوة العيد..."
                  value={newGoalTitle}
                  onChange={(e) => setNewGoalTitle(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-600 mb-1">المبلغ المستهدف ({currency.symbol})</label>
                  <input
                    type="number"
                    required
                    step="any"
                    placeholder="0.00"
                    value={newGoalTarget}
                    onChange={(e) => setNewGoalTarget(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-bold tabular-nums"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 mb-1">المدخر حالياً ({currency.symbol})</label>
                  <input
                    type="number"
                    step="any"
                    placeholder="0.00"
                    value={newGoalCurrent}
                    onChange={(e) => setNewGoalCurrent(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs tabular-nums"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-600 mb-1">تاريخ التحقيق المستهدف (اختياري)</label>
                <input
                  type="date"
                  value={newGoalDate}
                  onChange={(e) => setNewGoalDate(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
                />
              </div>

              <div>
                <label className="block text-slate-600 mb-1">ملاحظات حول الهدف</label>
                <input
                  type="text"
                  placeholder="ملاحظات تفصيلية أو خطة الإيداع..."
                  value={newGoalNotes}
                  onChange={(e) => setNewGoalNotes(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-md mt-2"
              >
                إنشاء الهدف الادخاري
              </button>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
