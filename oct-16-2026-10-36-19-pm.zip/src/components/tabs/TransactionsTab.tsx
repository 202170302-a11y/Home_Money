import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  Trash2,
  Calendar,
  Share2,
  Download,
  Plus,
  ArrowUpDown,
  User,
  Sparkles,
  Wallet,
} from 'lucide-react';
import { Transaction, FamilyMember, CurrencyConfig } from '../../types';
import { ALL_CATEGORIES, getCategoryById } from '../../constants/categories';
import { CategoryIcon } from '../CategoryIcon';
import { formatCurrency } from '../../constants/currencies';

interface TransactionsTabProps {
  transactions: Transaction[];
  familyMembers: FamilyMember[];
  currency: CurrencyConfig;
  onDeleteTransaction: (id: string) => void;
  onOpenQuickAdd: () => void;
  onExportCSV: () => void;
}

export const TransactionsTab: React.FC<TransactionsTabProps> = ({
  transactions,
  familyMembers,
  currency,
  onDeleteTransaction,
  onOpenQuickAdd,
  onExportCSV,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'expense' | 'income' | 'sudden'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedMember, setSelectedMember] = useState<string>('all');
  const [selectedFund, setSelectedFund] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'date_desc' | 'date_asc' | 'amount_desc'>('date_desc');
  const [copiedWhatsApp, setCopiedWhatsApp] = useState(false);

  // Filtered & Sorted Transactions
  const filteredTransactions = useMemo(() => {
    return transactions.filter((tx) => {
      // Type match
      if (filterType === 'expense' && tx.type !== 'expense') return false;
      if (filterType === 'income' && tx.type !== 'income') return false;
      if (filterType === 'sudden' && (!tx.isSuddenIncome || tx.type !== 'income')) return false;

      // Category match
      if (selectedCategory !== 'all' && tx.category !== selectedCategory) return false;
      
      // Member match
      if (selectedMember !== 'all' && tx.familyMemberId !== selectedMember) return false;

      // Fund match
      if (selectedFund !== 'all' && tx.fundId !== selectedFund) return false;

      // Search match
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesTitle = tx.title.toLowerCase().includes(query);
        const matchesNotes = (tx.notes || '').toLowerCase().includes(query);
        const cat = getCategoryById(tx.category);
        const matchesCategory = cat.name.toLowerCase().includes(query);
        if (!matchesTitle && !matchesNotes && !matchesCategory) return false;
      }
      return true;
    }).sort((a, b) => {
      if (sortBy === 'date_desc') return new Date(b.date).getTime() - new Date(a.date).getTime();
      if (sortBy === 'date_asc') return new Date(a.date).getTime() - new Date(b.date).getTime();
      if (sortBy === 'amount_desc') return b.amount - a.amount;
      return 0;
    });
  }, [transactions, filterType, selectedCategory, selectedMember, selectedFund, searchQuery, sortBy]);

  // Aggregate stats for filtered results
  const totalFilteredExpense = filteredTransactions
    .filter((t) => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalFilteredIncome = filteredTransactions
    .filter((t) => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);

  const getPayer = (memberId?: string) => {
    return familyMembers.find((m) => m.id === memberId);
  };

  const getFundName = (fundId?: string) => {
    if (!fundId) return null;
    const member = familyMembers.find((m) => m.id === fundId);
    return member ? `صندوق ${member.name.split(' ')[0]}` : null;
  };

  const handleShareWhatsApp = () => {
    const summary = `📊 تقرير مصاريف المنزل:
- عدد العمليات: ${filteredTransactions.length}
- إجمالي المصاريف: ${formatCurrency(totalFilteredExpense, currency.symbol)}
- إجمالي الدخل: ${formatCurrency(totalFilteredIncome, currency.symbol)}
- الرصيد الصافي: ${formatCurrency(totalFilteredIncome - totalFilteredExpense, currency.symbol)}

تم التصدير من تطبيق مصاريف البيت 🏡`;

    navigator.clipboard.writeText(summary);
    setCopiedWhatsApp(true);
    setTimeout(() => setCopiedWhatsApp(false), 2500);
  };

  return (
    <div className="space-y-4 pb-24 text-slate-800 dark:text-slate-100">
      
      {/* Search and Top Controls */}
      <div className="space-y-2">
        {/* Search input */}
        <div className="relative flex items-center">
          <Search className="w-4 h-4 text-slate-400 absolute right-3 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="بحث في العمليات أو الملاحظات..."
            className="w-full pr-9 pl-3 py-2.5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 text-xs focus:border-emerald-500 focus:outline-hidden text-slate-900 dark:text-white"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute left-3 text-xs text-slate-400 hover:text-slate-600"
            >
              مسح
            </button>
          )}
        </div>

        {/* Type Segmented Control with Sudden Income Tab */}
        <div className="flex items-center gap-1 p-1 bg-slate-200/70 dark:bg-slate-800 rounded-xl text-xs font-semibold overflow-x-auto">
          <button
            onClick={() => setFilterType('all')}
            className={`flex-1 py-1.5 px-2 rounded-lg transition-all cursor-pointer text-center shrink-0 ${
              filterType === 'all'
                ? 'bg-white dark:bg-slate-750 text-slate-900 dark:text-white shadow-xs font-bold'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            الكل ({transactions.length})
          </button>
          <button
            onClick={() => setFilterType('expense')}
            className={`flex-1 py-1.5 px-2 rounded-lg transition-all cursor-pointer text-center shrink-0 ${
              filterType === 'expense'
                ? 'bg-white dark:bg-slate-750 text-rose-600 dark:text-rose-400 shadow-xs font-bold'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            المصاريف
          </button>
          <button
            onClick={() => setFilterType('income')}
            className={`flex-1 py-1.5 px-2 rounded-lg transition-all cursor-pointer text-center shrink-0 ${
              filterType === 'income'
                ? 'bg-white dark:bg-slate-750 text-emerald-600 dark:text-emerald-400 shadow-xs font-bold'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            الدخل العام
          </button>
          <button
            onClick={() => setFilterType('sudden')}
            className={`flex-1 py-1.5 px-2 rounded-lg transition-all cursor-pointer text-center shrink-0 flex items-center justify-center gap-1 ${
              filterType === 'sudden'
                ? 'bg-amber-100 dark:bg-amber-950 text-amber-950 dark:text-amber-200 shadow-xs font-bold ring-1 ring-amber-400'
                : 'text-amber-700 dark:text-amber-400 hover:text-amber-900'
            }`}
          >
            <Sparkles className="w-3 h-3 text-amber-500" />
            <span>دخل مفاجئ ⚡</span>
          </button>
        </div>

        {/* Secondary Filter Dropdowns & Sorter */}
        <div className="grid grid-cols-3 gap-1.5 text-xs">
          {/* Category Dropdown */}
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="p-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 text-[11px] focus:outline-hidden"
          >
            <option value="all">كل الفئات</option>
            {ALL_CATEGORIES.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>

          {/* Family Fund Dropdown */}
          <select
            value={selectedFund}
            onChange={(e) => setSelectedFund(e.target.value)}
            className="p-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 text-[11px] focus:outline-hidden"
          >
            <option value="all">كل الصناديق</option>
            {familyMembers.map((m) => (
              <option key={m.id} value={m.id}>
                صندوق {m.name}
              </option>
            ))}
          </select>

          {/* Sorter */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="p-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 text-[11px] focus:outline-hidden"
          >
            <option value="date_desc">الأحدث أولاً</option>
            <option value="date_asc">الأقدم أولاً</option>
            <option value="amount_desc">الأعلى مبلغاً</option>
          </select>
        </div>
      </div>

      {/* Filter Stats Strip & Actions */}
      <div className="p-3 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 shadow-xs flex items-center justify-between text-xs">
        <div>
          <span className="text-[11px] text-slate-500">
            العمليات: <strong className="text-slate-900 dark:text-white tabular-nums">{filteredTransactions.length}</strong>
          </span>
          <div className="flex items-center gap-2 mt-0.5 font-bold tabular-nums">
            {filterType !== 'income' && filterType !== 'sudden' && (
              <span className="text-rose-600 dark:text-rose-400">
                صرف: {formatCurrency(totalFilteredExpense, currency.symbol)}
              </span>
            )}
            {filterType !== 'expense' && (
              <span className="text-emerald-600 dark:text-emerald-400">
                دخل: {formatCurrency(totalFilteredIncome, currency.symbol)}
              </span>
            )}
          </div>
        </div>

        {/* Share & Export buttons */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={handleShareWhatsApp}
            className="p-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 transition-colors cursor-pointer"
            title="نسخ تقرير للواتساب"
          >
            <Share2 className="w-4 h-4" />
          </button>
          <button
            onClick={onExportCSV}
            className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-750 text-slate-700 dark:text-slate-300 transition-colors cursor-pointer"
            title="تحميل كملف Excel / CSV"
          >
            <Download className="w-4 h-4" />
          </button>
        </div>
      </div>

      {copiedWhatsApp && (
        <div className="p-2.5 rounded-xl bg-emerald-600 text-white text-xs font-semibold text-center shadow-md animate-in fade-in">
          ✅ تم نسخ ملخص التقرير المالي إلى الحافظة!
        </div>
      )}

      {/* Transactions List */}
      {filteredTransactions.length === 0 ? (
        <div className="p-8 text-center bg-white/80 dark:bg-slate-850/80 backdrop-blur-md rounded-3xl border border-dashed border-slate-200 dark:border-slate-800 space-y-2">
          <p className="text-slate-500 text-xs">لا توجد عمليات تطابق البحث</p>
          <button
            onClick={onOpenQuickAdd}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs cursor-pointer active:scale-95 transition-all"
          >
            + إضافة عملية جديدة
          </button>
        </div>
      ) : (
        <div className="bg-white/85 dark:bg-slate-850/85 backdrop-blur-md rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-xs divide-y divide-slate-100 dark:divide-slate-800 overflow-hidden">
          {filteredTransactions.map((tx) => {
            const cat = getCategoryById(tx.category);
            const payer = getPayer(tx.familyMemberId);
            const fundName = getFundName(tx.fundId);
            const isExpense = tx.type === 'expense';

            return (
              <div
                key={tx.id}
                className="p-3.5 flex items-center justify-between hover:bg-slate-50/80 dark:hover:bg-slate-800/60 transition-colors group"
              >
                <div className="flex items-center gap-3 overflow-hidden">
                  <div
                    className="w-10 h-10 rounded-2xl flex items-center justify-center text-white shrink-0 shadow-2xs"
                    style={{ backgroundColor: cat.color }}
                  >
                    <CategoryIcon name={cat.icon} className="w-5 h-5" />
                  </div>

                  <div className="overflow-hidden">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h4 className="font-bold text-xs text-slate-900 dark:text-white truncate">
                        {tx.title}
                      </h4>
                      {tx.isSuddenIncome && (
                        <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400">
                          ⚡ دخل مفاجئ
                        </span>
                      )}
                      {fundName && (
                        <span className="text-[10px] text-emerald-700 dark:text-emerald-400 font-medium flex items-center gap-0.5">
                          <Wallet className="w-2.5 h-2.5" />
                          <span>{fundName}</span>
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 truncate">
                      <span>{cat.name}</span>
                      <span aria-hidden="true">·</span>
                      {payer && <span>{payer.avatar} {payer.name.split(' ')[0]}</span>}
                      {payer && <span aria-hidden="true">·</span>}
                      <span>{tx.date}</span>
                    </div>

                    {tx.notes && (
                      <p className="text-[10px] text-slate-400 dark:text-slate-500 truncate mt-0.5 italic">
                        "{tx.notes}"
                      </p>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <div className="text-left">
                    <span
                      className={`text-sm font-extrabold tabular-nums block ${
                        isExpense
                          ? 'text-rose-600 dark:text-rose-400'
                          : 'text-emerald-600 dark:text-emerald-400'
                      }`}
                    >
                      {isExpense ? '-' : '+'}
                      {tx.amount.toLocaleString('ar-EG')} {currency.symbol}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {tx.paymentMethod === 'cash'
                        ? 'نقداً'
                        : tx.paymentMethod === 'card'
                        ? 'بطاقة'
                        : 'تحويل'}
                    </span>
                  </div>

                  {/* Delete button */}
                  <button
                    onClick={() => {
                      if (confirm(`هل أنت متأكد من حذف عملية "${tx.title}"؟`)) {
                        onDeleteTransaction(tx.id);
                      }
                    }}
                    className="p-2 text-slate-300 hover:text-rose-600 dark:text-slate-600 dark:hover:text-rose-400 rounded-lg transition-colors cursor-pointer"
                    title="حذف هذه العملية"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
