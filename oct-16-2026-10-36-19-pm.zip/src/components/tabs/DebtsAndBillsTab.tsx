import React, { useState } from 'react';
import {
  Zap,
  HandCoins,
  Plus,
  CheckCircle2,
  Calendar,
  AlertCircle,
  Clock,
  Trash2,
  X,
  Check,
} from 'lucide-react';
import { BillItem, DebtItem, CurrencyConfig } from '../../types';
import { formatCurrency } from '../../constants/currencies';

interface DebtsAndBillsTabProps {
  bills: BillItem[];
  debts: DebtItem[];
  currency: CurrencyConfig;
  onToggleBillPaid: (billId: string) => void;
  onAddBill: (bill: Omit<BillItem, 'id'>) => void;
  onDeleteBill: (billId: string) => void;
  onToggleDebtPaid: (debtId: string) => void;
  onAddDebt: (debt: Omit<DebtItem, 'id' | 'createdAt'>) => void;
  onDeleteDebt: (debtId: string) => void;
}

export const DebtsAndBillsTab: React.FC<DebtsAndBillsTabProps> = ({
  bills,
  debts,
  currency,
  onToggleBillPaid,
  onAddBill,
  onDeleteBill,
  onToggleDebtPaid,
  onAddDebt,
  onDeleteDebt,
}) => {
  const [subTab, setSubTab] = useState<'bills' | 'debts'>('bills');
  const [showAddBillModal, setShowAddBillModal] = useState(false);
  const [showAddDebtModal, setShowAddDebtModal] = useState(false);

  // New Bill form states
  const [newBillTitle, setNewBillTitle] = useState('');
  const [newBillAmount, setNewBillAmount] = useState('');
  const [newBillDueDay, setNewBillDueDay] = useState('25');
  const [newBillCategory, setNewBillCategory] = useState('utilities');
  const [newBillNotes, setNewBillNotes] = useState('');

  // New Debt form states
  const [newDebtType, setNewDebtType] = useState<'owed_by_us' | 'owed_to_us'>('owed_by_us');
  const [newDebtPerson, setNewDebtPerson] = useState('');
  const [newDebtAmount, setNewDebtAmount] = useState('');
  const [newDebtDueDate, setNewDebtDueDate] = useState('');
  const [newDebtNotes, setNewDebtNotes] = useState('');

  // Totals for Bills
  const totalBills = bills.reduce((sum, b) => sum + b.amount, 0);
  const paidBillsSum = bills.filter((b) => b.isPaid).reduce((sum, b) => sum + b.amount, 0);
  const unpaidBillsSum = totalBills - paidBillsSum;

  // Totals for Debts
  const debtsOwedByUs = debts.filter((d) => d.type === 'owed_by_us' && !d.isPaid);
  const debtsOwedToUs = debts.filter((d) => d.type === 'owed_to_us' && !d.isPaid);

  const totalOwedByUs = debtsOwedByUs.reduce((sum, d) => sum + d.amount, 0);
  const totalOwedToUs = debtsOwedToUs.reduce((sum, d) => sum + d.amount, 0);

  const handleCreateBill = (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(newBillAmount);
    if (!newBillTitle.trim() || isNaN(amountNum) || amountNum <= 0) return;

    onAddBill({
      title: newBillTitle.trim(),
      amount: amountNum,
      dueDay: parseInt(newBillDueDay) || 1,
      category: newBillCategory,
      isPaid: false,
      notes: newBillNotes.trim() || undefined,
    });

    setNewBillTitle('');
    setNewBillAmount('');
    setNewBillNotes('');
    setShowAddBillModal(false);
  };

  const handleCreateDebt = (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(newDebtAmount);
    if (!newDebtPerson.trim() || isNaN(amountNum) || amountNum <= 0) return;

    onAddDebt({
      type: newDebtType,
      personName: newDebtPerson.trim(),
      amount: amountNum,
      dueDate: newDebtDueDate || undefined,
      isPaid: false,
      notes: newDebtNotes.trim() || undefined,
    });

    setNewDebtPerson('');
    setNewDebtAmount('');
    setNewDebtDueDate('');
    setNewDebtNotes('');
    setShowAddDebtModal(false);
  };

  return (
    <div className="space-y-4 pb-24 text-slate-800 dark:text-slate-100">
      
      {/* Top Segmented Subtab Switcher */}
      <div className="flex items-center gap-1 p-1 bg-slate-200/70 dark:bg-slate-800 rounded-2xl text-xs font-semibold">
        <button
          onClick={() => setSubTab('bills')}
          className={`flex-1 py-2 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
            subTab === 'bills'
              ? 'bg-white dark:bg-slate-750 text-slate-900 dark:text-white shadow-xs font-bold'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Zap className="w-4 h-4 text-amber-500" />
          <span>الفواتير والخدمات ({bills.length})</span>
        </button>

        <button
          onClick={() => setSubTab('debts')}
          className={`flex-1 py-2 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
            subTab === 'debts'
              ? 'bg-white dark:bg-slate-750 text-slate-900 dark:text-white shadow-xs font-bold'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <HandCoins className="w-4 h-4 text-emerald-500" />
          <span>الديون والالتزامات ({debts.length})</span>
        </button>
      </div>

      {/* SUBTAB 1: BILLS */}
      {subTab === 'bills' && (
        <div className="space-y-4">
          {/* Bills Summary Card */}
          <div className="p-4 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-500">إجمالي فواتير الشهر</span>
                <h3 className="text-xl font-bold text-slate-900 dark:text-white tabular-nums">
                  {formatCurrency(totalBills, currency.symbol)}
                </h3>
              </div>
              <button
                onClick={() => setShowAddBillModal(true)}
                className="px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center gap-1 shadow-sm cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>إضافة فاتورة</span>
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100 dark:border-slate-700 text-xs">
              <div className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300">
                <span className="text-[11px] block">تم سدادها ({bills.filter((b) => b.isPaid).length})</span>
                <span className="font-bold tabular-nums">
                  {formatCurrency(paidBillsSum, currency.symbol)}
                </span>
              </div>
              <div className="p-2 rounded-xl bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300">
                <span className="text-[11px] block">بانتظار السداد ({bills.filter((b) => !b.isPaid).length})</span>
                <span className="font-bold tabular-nums">
                  {formatCurrency(unpaidBillsSum, currency.symbol)}
                </span>
              </div>
            </div>
          </div>

          {/* Bills List */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 px-1">
              قائمة الفواتير الشهرية الدورية
            </h4>

            {bills.length === 0 ? (
              <div className="p-6 text-center bg-white dark:bg-slate-800 rounded-3xl border border-dashed border-slate-200 dark:border-slate-700 text-xs text-slate-500">
                لا توجد فواتير مضافة بعد
              </div>
            ) : (
              <div className="space-y-2">
                {bills.map((bill) => (
                  <div
                    key={bill.id}
                    className={`p-3.5 rounded-2xl bg-white dark:bg-slate-800 border transition-all shadow-xs flex items-center justify-between ${
                      bill.isPaid
                        ? 'border-emerald-200 dark:border-emerald-900/60 bg-emerald-50/20'
                        : 'border-slate-200/80 dark:border-slate-700/80'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 ${
                          bill.isPaid
                            ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-600'
                            : 'bg-amber-100 dark:bg-amber-950 text-amber-600'
                        }`}
                      >
                        <Zap className="w-5 h-5" />
                      </div>
                      <div>
                        <h5 className="font-bold text-xs text-slate-900 dark:text-white flex items-center gap-2">
                          <span>{bill.title}</span>
                          {bill.isPaid && (
                            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 font-bold">
                              تم السداد
                            </span>
                          )}
                        </h5>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          تستحق يوم {bill.dueDay} من كل شهر ·{' '}
                          <strong className="text-slate-800 dark:text-slate-200 tabular-nums">
                            {bill.amount.toLocaleString('ar-EG')} {currency.symbol}
                          </strong>
                        </p>
                        {bill.notes && (
                          <p className="text-[10px] text-slate-400 italic mt-0.5">
                            "{bill.notes}"
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => onToggleBillPaid(bill.id)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                          bill.isPaid
                            ? 'bg-slate-100 dark:bg-slate-750 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                            : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm'
                        }`}
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        <span>{bill.isPaid ? 'إلغاء السداد' : 'تم السداد'}</span>
                      </button>

                      <button
                        onClick={() => {
                          if (confirm(`حذف فاتورة "${bill.title}"؟`)) {
                            onDeleteBill(bill.id);
                          }
                        }}
                        className="p-1.5 text-slate-300 hover:text-rose-500 rounded-lg"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* SUBTAB 2: DEBTS */}
      {subTab === 'debts' && (
        <div className="space-y-4">
          {/* Debts Summary Card */}
          <div className="p-4 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-500">ميزان الديون والالتزامات</span>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  صافي الالتزام:{' '}
                  <span
                    className={`tabular-nums ${
                      totalOwedToUs >= totalOwedByUs ? 'text-emerald-600' : 'text-rose-600'
                    }`}
                  >
                    {formatCurrency(totalOwedToUs - totalOwedByUs, currency.symbol)}
                  </span>
                </h3>
              </div>
              <button
                onClick={() => setShowAddDebtModal(true)}
                className="px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center gap-1 shadow-sm cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>إضافة دين/التزام</span>
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100 dark:border-slate-700 text-xs">
              <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-300">
                <span className="text-[11px] block">ديون علينا للغير (نلتزم بسدادها)</span>
                <span className="font-extrabold text-sm tabular-nums">
                  {formatCurrency(totalOwedByUs, currency.symbol)}
                </span>
              </div>
              <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300">
                <span className="text-[11px] block">ديون لنا على الآخرين (ننتظر استردادها)</span>
                <span className="font-extrabold text-sm tabular-nums">
                  {formatCurrency(totalOwedToUs, currency.symbol)}
                </span>
              </div>
            </div>
          </div>

          {/* Debts List */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 px-1">
              سجل الديون والالتزامات ({debts.length})
            </h4>

            {debts.length === 0 ? (
              <div className="p-6 text-center bg-white dark:bg-slate-800 rounded-3xl border border-dashed border-slate-200 dark:border-slate-700 text-xs text-slate-500">
                لا توجد ديون مسجلة، الحمد لله!
              </div>
            ) : (
              <div className="space-y-2">
                {debts.map((debt) => {
                  const isOwedByUs = debt.type === 'owed_by_us';

                  return (
                    <div
                      key={debt.id}
                      className={`p-3.5 rounded-2xl bg-white dark:bg-slate-800 border transition-all shadow-xs flex items-center justify-between ${
                        debt.isPaid
                          ? 'opacity-60 bg-slate-50 dark:bg-slate-850 border-slate-200'
                          : isOwedByUs
                          ? 'border-rose-200 dark:border-rose-900/60'
                          : 'border-emerald-200 dark:border-emerald-900/60'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 ${
                            debt.isPaid
                              ? 'bg-slate-200 text-slate-600'
                              : isOwedByUs
                              ? 'bg-rose-100 dark:bg-rose-950 text-rose-600'
                              : 'bg-emerald-100 dark:bg-emerald-950 text-emerald-600'
                          }`}
                        >
                          <HandCoins className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span
                              className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                                isOwedByUs
                                  ? 'bg-rose-100 text-rose-800 dark:bg-rose-900 dark:text-rose-200'
                                  : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200'
                              }`}
                            >
                              {isOwedByUs ? 'علينا للغير' : 'لنا على الغير'}
                            </span>
                            <h5 className="font-bold text-xs text-slate-900 dark:text-white">
                              {debt.personName}
                            </h5>
                          </div>

                          <p className="text-[11px] text-slate-500 mt-0.5">
                            المبلغ:{' '}
                            <strong className="text-slate-800 dark:text-slate-200 tabular-nums">
                              {debt.amount.toLocaleString('ar-EG')} {currency.symbol}
                            </strong>
                            {debt.dueDate && ` · موعد السداد: ${debt.dueDate}`}
                          </p>
                          {debt.notes && (
                            <p className="text-[10px] text-slate-400 italic mt-0.5">
                              "{debt.notes}"
                            </p>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          onClick={() => onToggleDebtPaid(debt.id)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                            debt.isPaid
                              ? 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                              : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm'
                          }`}
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>{debt.isPaid ? 'تمت التسوية' : 'تسوية الدين'}</span>
                        </button>

                        <button
                          onClick={() => {
                            if (confirm(`حذف هذا الالتزام؟`)) {
                              onDeleteDebt(debt.id);
                            }
                          }}
                          className="p-1.5 text-slate-300 hover:text-rose-500 rounded-lg"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Add Bill Modal */}
      {showAddBillModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-5 shadow-2xl space-y-4 text-xs">
            <div className="flex justify-between items-center border-b pb-2">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                <Zap className="w-4 h-4 text-amber-500" />
                <span>إضافة فاتورة دورية جديدة</span>
              </h3>
              <button onClick={() => setShowAddBillModal(false)} className="text-slate-400">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateBill} className="space-y-3">
              <div>
                <label className="block text-slate-600 mb-1">اسم الفاتورة أو الخدمة</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: فاتورة الغاز، صيانة المصعد..."
                  value={newBillTitle}
                  onChange={(e) => setNewBillTitle(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
                />
              </div>

              <div>
                <label className="block text-slate-600 mb-1">المبلغ التقريبي ({currency.symbol})</label>
                <input
                  type="number"
                  required
                  step="any"
                  placeholder="0.00"
                  value={newBillAmount}
                  onChange={(e) => setNewBillAmount(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs tabular-nums font-bold"
                />
              </div>

              <div>
                <label className="block text-slate-600 mb-1">يوم الاستحقاق الشهري (1 - 31)</label>
                <input
                  type="number"
                  min="1"
                  max="31"
                  value={newBillDueDay}
                  onChange={(e) => setNewBillDueDay(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs tabular-nums"
                />
              </div>

              <div>
                <label className="block text-slate-600 mb-1">ملاحظات (اختياري)</label>
                <input
                  type="text"
                  placeholder="رقم العداد، الحساب..."
                  value={newBillNotes}
                  onChange={(e) => setNewBillNotes(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-md mt-2"
              >
                حفظ الفاتورة
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Add Debt Modal */}
      {showAddDebtModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-5 shadow-2xl space-y-4 text-xs">
            <div className="flex justify-between items-center border-b pb-2">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                <HandCoins className="w-4 h-4 text-emerald-500" />
                <span>إضافة دين أو التزام مالي</span>
              </h3>
              <button onClick={() => setShowAddDebtModal(false)} className="text-slate-400">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateDebt} className="space-y-3">
              <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
                <button
                  type="button"
                  onClick={() => setNewDebtType('owed_by_us')}
                  className={`py-1.5 rounded-lg font-bold text-center ${
                    newDebtType === 'owed_by_us'
                      ? 'bg-rose-600 text-white'
                      : 'text-slate-600'
                  }`}
                >
                  علينا للغير
                </button>
                <button
                  type="button"
                  onClick={() => setNewDebtType('owed_to_us')}
                  className={`py-1.5 rounded-lg font-bold text-center ${
                    newDebtType === 'owed_to_us'
                      ? 'bg-emerald-600 text-white'
                      : 'text-slate-600'
                  }`}
                >
                  لنا على الغير
                </button>
              </div>

              <div>
                <label className="block text-slate-600 mb-1">اسم الشخص أو الجهة</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: الأخ محمد، معرض الأثاث..."
                  value={newDebtPerson}
                  onChange={(e) => setNewDebtPerson(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
                />
              </div>

              <div>
                <label className="block text-slate-600 mb-1">المبلغ ({currency.symbol})</label>
                <input
                  type="number"
                  required
                  step="any"
                  placeholder="0.00"
                  value={newDebtAmount}
                  onChange={(e) => setNewDebtAmount(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs tabular-nums font-bold"
                />
              </div>

              <div>
                <label className="block text-slate-600 mb-1">موعد السداد المتوقع (اختياري)</label>
                <input
                  type="date"
                  value={newDebtDueDate}
                  onChange={(e) => setNewDebtDueDate(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
                />
              </div>

              <div>
                <label className="block text-slate-600 mb-1">ملاحظات (اختياري)</label>
                <input
                  type="text"
                  placeholder="سبب السلفة أو تفاصيل الالتزام..."
                  value={newDebtNotes}
                  onChange={(e) => setNewDebtNotes(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-md mt-2"
              >
                حفظ الدين / الالتزام
              </button>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
