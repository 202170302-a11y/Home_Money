import React from 'react';
import { Settings, Wallet, Calendar, Sun, Moon, Bell } from 'lucide-react';
import { CurrencyConfig, ThemeAccent } from '../types';

interface TopHeaderProps {
  currentMonthName: string;
  currency: CurrencyConfig;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  notificationCount: number;
  onOpenNotifications: () => void;
  onOpenSettings: () => void;
  themeAccent?: ThemeAccent;
}

export const TopHeader: React.FC<TopHeaderProps> = ({
  currentMonthName,
  currency,
  isDarkMode,
  onToggleDarkMode,
  notificationCount,
  onOpenNotifications,
  onOpenSettings,
  themeAccent = 'emerald',
}) => {
  const getBadgeGradient = () => {
    switch (themeAccent) {
      case 'sapphire':
        return 'from-blue-600 to-cyan-500 shadow-blue-500/20';
      case 'amber':
        return 'from-amber-600 to-orange-500 shadow-amber-500/20';
      case 'amethyst':
        return 'from-purple-600 to-pink-500 shadow-purple-500/20';
      case 'emerald':
      default:
        return 'from-emerald-600 to-teal-500 shadow-emerald-500/20';
    }
  };

  const getAccentText = () => {
    switch (themeAccent) {
      case 'sapphire':
        return 'text-blue-600 dark:text-blue-400';
      case 'amber':
        return 'text-amber-600 dark:text-amber-400';
      case 'amethyst':
        return 'text-purple-600 dark:text-purple-400';
      case 'emerald':
      default:
        return 'text-emerald-600 dark:text-emerald-400';
    }
  };

  return (
    <header className="sticky top-0 z-20 bg-white/85 dark:bg-slate-900/85 backdrop-blur-xl border-b border-slate-200/70 dark:border-slate-800/80 px-4 py-3 flex items-center justify-between transition-colors duration-200">
      {/* Brand Zone */}
      <div className="flex items-center gap-2.5">
        <div
          className={`w-9 h-9 rounded-2xl bg-gradient-to-tr ${getBadgeGradient()} text-white flex items-center justify-center shadow-md`}
        >
          <Wallet className="w-4 h-4 stroke-[2.4]" />
        </div>
        <div>
          <h1 className="text-sm font-bold text-slate-900 dark:text-white leading-tight tracking-tight">
            مصاريف البيت
          </h1>
          <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
            <Calendar className={`w-3 h-3 ${getAccentText()}`} />
            <span>{currentMonthName}</span>
          </div>
        </div>
      </div>

      {/* Right Action Zone */}
      <div className="flex items-center gap-1.5">
        {/* Currency display */}
        <span className="px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-slate-800/90 text-slate-800 dark:text-slate-200 font-bold text-xs border border-slate-200/80 dark:border-slate-700/80 tabular-nums shadow-2xs">
          {currency.symbol}
        </span>

        {/* 24-Hour Bill Reminders Notification Bell */}
        <button
          onClick={onOpenNotifications}
          className="relative min-w-[38px] min-h-[38px] rounded-xl bg-slate-100 hover:bg-slate-200/80 dark:bg-slate-800 dark:hover:bg-slate-750 text-slate-700 dark:text-slate-300 flex items-center justify-center transition-all cursor-pointer active:scale-95 shadow-2xs"
          title="تنبيهات استحقاق الفواتير"
          aria-label="التنبيهات"
        >
          <Bell className="w-4 h-4" />
          {notificationCount > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-amber-500 text-white text-[10px] font-black rounded-full flex items-center justify-center ring-2 ring-white dark:ring-slate-900 tabular-nums animate-pulse">
              {notificationCount}
            </span>
          )}
        </button>

        {/* 1-Tap Fast Dark Mode Toggle Button */}
        <button
          onClick={onToggleDarkMode}
          className="min-w-[38px] min-h-[38px] rounded-xl bg-slate-100 hover:bg-slate-200/80 dark:bg-slate-800 dark:hover:bg-slate-750 text-slate-700 dark:text-slate-300 flex items-center justify-center transition-all cursor-pointer active:scale-95 shadow-2xs"
          title={isDarkMode ? 'التبديل إلى الوضع النهاري' : 'التبديل إلى الوضع الليلي'}
          aria-label="الوضع الليلي"
        >
          {isDarkMode ? (
            <Sun className="w-4 h-4 text-amber-400 rotate-0 transition-transform duration-300" />
          ) : (
            <Moon className="w-4 h-4 text-slate-700 rotate-0 transition-transform duration-300" />
          )}
        </button>

        {/* Settings button */}
        <button
          onClick={onOpenSettings}
          className="min-w-[38px] min-h-[38px] rounded-xl bg-slate-100 hover:bg-slate-200/80 dark:bg-slate-800 dark:hover:bg-slate-750 text-slate-700 dark:text-slate-300 flex items-center justify-center transition-all cursor-pointer active:scale-95 shadow-2xs"
          title="الإعدادات، الألوان، وخلفيات التطبيق"
          aria-label="الإعدادات والمظهر"
        >
          <Settings className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
