import React, { useState } from 'react';
import {
  X,
  Settings,
  Coins,
  Users,
  Database,
  Smartphone,
  Trash2,
  RefreshCw,
  Plus,
  Download,
  Info,
  Moon,
  Sun,
  Laptop,
  Palette,
  Sparkles,
  Layers,
  Check,
} from 'lucide-react';
import {
  AppSettings,
  CurrencyConfig,
  FamilyMember,
  ThemeAccent,
  BackgroundStyle,
} from '../types';
import { SUPPORTED_CURRENCIES } from '../constants/currencies';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  familyMembers: FamilyMember[];
  onUpdateSettings: (settings: AppSettings) => void;
  onUpdateFamilyMembers: (members: FamilyMember[]) => void;
  onResetSampleData: () => void;
  onClearAllData: () => void;
  onExportCSV: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  familyMembers,
  onUpdateSettings,
  onUpdateFamilyMembers,
  onResetSampleData,
  onClearAllData,
  onExportCSV,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'theme' | 'currency' | 'family' | 'data'>('theme');
  const [newMemberName, setNewMemberName] = useState('');
  const [newMemberAvatar, setNewMemberAvatar] = useState('🧑');
  const [newMemberRelation, setNewMemberRelation] = useState('فرد');
  const [newMemberAllowance, setNewMemberAllowance] = useState('500');

  if (!isOpen) return null;

  const handleCurrencySelect = (curr: CurrencyConfig) => {
    onUpdateSettings({
      ...settings,
      currency: curr,
    });
  };

  const handleThemeModeChange = (mode: 'dark' | 'light' | 'system') => {
    onUpdateSettings({
      ...settings,
      themeMode: mode,
    });
  };

  const handleThemeAccentChange = (accent: ThemeAccent) => {
    onUpdateSettings({
      ...settings,
      themeAccent: accent,
    });
  };

  const handleBackgroundStyleChange = (style: BackgroundStyle) => {
    onUpdateSettings({
      ...settings,
      backgroundStyle: style,
    });
  };

  const handleAddMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMemberName.trim()) return;

    const newMember: FamilyMember = {
      id: `member_${Date.now()}`,
      name: newMemberName.trim(),
      relation: newMemberRelation,
      avatar: newMemberAvatar,
      color: '#059669',
      walletBalance: 0,
      monthlyAllowance: parseFloat(newMemberAllowance) || 0,
    };

    onUpdateFamilyMembers([...familyMembers, newMember]);
    setNewMemberName('');
    setNewMemberAllowance('500');
  };

  const handleDeleteMember = (memberId: string) => {
    if (familyMembers.length <= 1) {
      alert('يجب الإبقاء على فرد واحد على الأقل في الأسرة');
      return;
    }
    onUpdateFamilyMembers(familyMembers.filter((m) => m.id !== memberId));
  };

  const THEME_ACCENTS: {
    id: ThemeAccent;
    name: string;
    sub: string;
    colorHex: string;
    gradientClass: string;
  }[] = [
    {
      id: 'emerald',
      name: 'الواحة الزمردية',
      sub: 'أخضر زمردي فاخر',
      colorHex: '#059669',
      gradientClass: 'from-emerald-500 to-teal-600',
    },
    {
      id: 'sapphire',
      name: 'الياقوت الأزرق',
      sub: 'أزرق ملكي عصري',
      colorHex: '#2563eb',
      gradientClass: 'from-blue-600 to-cyan-500',
    },
    {
      id: 'amber',
      name: 'الكهرمان الذهبي',
      sub: 'ذهبي صحراوي دافئ',
      colorHex: '#d97706',
      gradientClass: 'from-amber-500 to-orange-600',
    },
    {
      id: 'amethyst',
      name: 'الأرجوان الأندلسي',
      sub: 'بنفسجي ملكي أنيق',
      colorHex: '#9333ea',
      gradientClass: 'from-purple-600 to-fuchsia-600',
    },
  ];

  const BACKGROUND_STYLES: {
    id: BackgroundStyle;
    name: string;
    desc: string;
  }[] = [
    {
      id: 'oasis_mesh',
      name: 'شبكة إضاءة أثيرية',
      desc: 'تدرجات ضوئية محيطية ناعمة تتفاعل مع السمة',
    },
    {
      id: 'arabesque',
      name: 'زخرفة هندسية عربية',
      desc: 'نقوش وزخارف هندسية إسلامية هادئة وفائقة الرقة',
    },
    {
      id: 'slate_minimal',
      name: 'مصفوفة نقاط استوديو',
      desc: 'شبكة نقاط هندسية عصرية ونظيفة للمصممين',
    },
    {
      id: 'warm_sand',
      name: 'رمال الصحراء الدافئة',
      desc: 'تدرج دافئ يعكس طبيعة الرخام والرمال الذهبية',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 p-0 sm:p-4 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl shadow-2xl max-h-[90vh] flex flex-col overflow-hidden text-xs text-slate-800 dark:text-slate-100 border border-slate-200/80 dark:border-slate-800">
        
        {/* Header */}
        <div className="px-5 py-3.5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Palette className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>تخصيص المظهر والإعدادات</span>
          </h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 flex items-center justify-center text-slate-500 transition-colors cursor-pointer"
            aria-label="إغلاق"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="grid grid-cols-4 p-1.5 bg-slate-100 dark:bg-slate-850 border-b border-slate-200/50 dark:border-slate-800 gap-1 text-[11px] font-semibold">
          <button
            onClick={() => setActiveSubTab('theme')}
            className={`py-1.5 rounded-lg transition-all cursor-pointer ${
              activeSubTab === 'theme'
                ? 'bg-white dark:bg-slate-750 text-slate-900 dark:text-white shadow-xs font-bold'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            المظهر والألوان
          </button>
          <button
            onClick={() => setActiveSubTab('currency')}
            className={`py-1.5 rounded-lg transition-all cursor-pointer ${
              activeSubTab === 'currency'
                ? 'bg-white dark:bg-slate-750 text-slate-900 dark:text-white shadow-xs font-bold'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            العملة والعرض
          </button>
          <button
            onClick={() => setActiveSubTab('family')}
            className={`py-1.5 rounded-lg transition-all cursor-pointer ${
              activeSubTab === 'family'
                ? 'bg-white dark:bg-slate-750 text-slate-900 dark:text-white shadow-xs font-bold'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            الصناديق والأسرة
          </button>
          <button
            onClick={() => setActiveSubTab('data')}
            className={`py-1.5 rounded-lg transition-all cursor-pointer ${
              activeSubTab === 'data'
                ? 'bg-white dark:bg-slate-750 text-slate-900 dark:text-white shadow-xs font-bold'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            البيانات والنسخ
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 flex-1 overflow-y-auto space-y-5">
          
          {/* TAB 1: THEME, COLORS & BACKGROUNDS */}
          {activeSubTab === 'theme' && (
            <div className="space-y-4">
              
              {/* DARK / LIGHT MODE */}
              <div>
                <label className="block text-slate-800 dark:text-slate-200 font-bold mb-1 flex items-center gap-1.5">
                  <Moon className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  <span>نمط الإضاءة (Light & Dark Mode)</span>
                </label>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mb-2.5">
                  الوضع الليلي يقلل إجهاد العين ويوفر استهلاك بطارية شاشات AMOLED.
                </p>

                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => handleThemeModeChange('dark')}
                    className={`p-3 rounded-2xl border flex flex-col items-center gap-1.5 transition-all cursor-pointer ${
                      settings.themeMode === 'dark'
                        ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-900 dark:text-emerald-200 font-bold shadow-xs'
                        : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                    }`}
                  >
                    <Moon className="w-5 h-5 text-indigo-400" />
                    <span className="text-xs">وضع ليلي 🌙</span>
                  </button>

                  <button
                    onClick={() => handleThemeModeChange('light')}
                    className={`p-3 rounded-2xl border flex flex-col items-center gap-1.5 transition-all cursor-pointer ${
                      settings.themeMode === 'light'
                        ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-900 dark:text-emerald-200 font-bold shadow-xs'
                        : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                    }`}
                  >
                    <Sun className="w-5 h-5 text-amber-500" />
                    <span className="text-xs">وضع نهاري ☀️</span>
                  </button>

                  <button
                    onClick={() => handleThemeModeChange('system')}
                    className={`p-3 rounded-2xl border flex flex-col items-center gap-1.5 transition-all cursor-pointer ${
                      settings.themeMode === 'system'
                        ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-900 dark:text-emerald-200 font-bold shadow-xs'
                        : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                    }`}
                  >
                    <Laptop className="w-5 h-5 text-slate-400" />
                    <span className="text-xs">تلقائي النظام</span>
                  </button>
                </div>
              </div>

              {/* PALETTE ACCENTS */}
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800">
                <label className="block text-slate-800 dark:text-slate-200 font-bold mb-1 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  <span>السمة اللونية الأساسية للتطبيق</span>
                </label>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mb-2.5">
                  تغيير هوية الأزرار، مؤشرات الأداء، والبطاقات المالية.
                </p>

                <div className="grid grid-cols-2 gap-2">
                  {THEME_ACCENTS.map((item) => {
                    const isSelected = (settings.themeAccent || 'emerald') === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => handleThemeAccentChange(item.id)}
                        className={`p-2.5 rounded-2xl border text-right transition-all flex items-center justify-between cursor-pointer ${
                          isSelected
                            ? 'border-emerald-600 dark:border-emerald-500 bg-slate-50 dark:bg-slate-800 shadow-xs ring-1 ring-emerald-500/30'
                            : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50/70 dark:hover:bg-slate-800/50'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <div
                            className={`w-6 h-6 rounded-full bg-gradient-to-tr ${item.gradientClass} shadow-xs flex items-center justify-center shrink-0`}
                          >
                            {isSelected && <Check className="w-3.5 h-3.5 text-white stroke-[3]" />}
                          </div>
                          <div>
                            <p className="text-xs font-bold">{item.name}</p>
                            <span className="text-[10px] text-slate-400">{item.sub}</span>
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* BACKGROUND STYLE & TEXTURE */}
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800">
                <label className="block text-slate-800 dark:text-slate-200 font-bold mb-1 flex items-center gap-1.5">
                  <Layers className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  <span>نمط خلفية التطبيق والعمق البصري</span>
                </label>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mb-2.5">
                  اختر النمط الجمالي المناسب للشاشة (أثيري، زخرفة عربية، أو استوديو).
                </p>

                <div className="space-y-1.5">
                  {BACKGROUND_STYLES.map((bg) => {
                    const isSelected = (settings.backgroundStyle || 'oasis_mesh') === bg.id;
                    return (
                      <button
                        key={bg.id}
                        onClick={() => handleBackgroundStyleChange(bg.id)}
                        className={`w-full p-2.5 rounded-2xl border text-right transition-all flex items-center justify-between cursor-pointer ${
                          isSelected
                            ? 'border-emerald-600 dark:border-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/30 shadow-xs'
                            : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50'
                        }`}
                      >
                        <div>
                          <p className="text-xs font-bold text-slate-900 dark:text-white">
                            {bg.name}
                          </p>
                          <p className="text-[10px] text-slate-500 dark:text-slate-400">
                            {bg.desc}
                          </p>
                        </div>
                        {isSelected && (
                          <div className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0">
                            <Check className="w-3 h-3 stroke-[3]" />
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

            </div>
          )}

          {/* TAB 2: CURRENCY & VIEW MODE */}
          {activeSubTab === 'currency' && (
            <div className="space-y-4">
              {/* CURRENCY SELECTOR */}
              <div>
                <label className="block text-slate-800 dark:text-slate-200 font-bold mb-1.5 flex items-center gap-1.5">
                  <Coins className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  <span>عملة الحسابات المعتمدة</span>
                </label>

                <div className="grid grid-cols-2 gap-1.5 max-h-56 overflow-y-auto p-1 border border-slate-200 dark:border-slate-800 rounded-2xl">
                  {SUPPORTED_CURRENCIES.map((curr) => {
                    const isSelected = settings.currency.code === curr.code;
                    return (
                      <button
                        key={curr.code}
                        onClick={() => handleCurrencySelect(curr)}
                        className={`p-2.5 rounded-xl border text-right transition-all flex items-center justify-between cursor-pointer ${
                          isSelected
                            ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/60 font-bold text-emerald-900 dark:text-emerald-200'
                            : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'
                        }`}
                      >
                        <div>
                          <p className="text-xs font-semibold">{curr.name}</p>
                          <span className="text-[10px] text-slate-500 font-mono">
                            {curr.code}
                          </span>
                        </div>
                        <span className="text-sm font-bold tabular-nums">
                          {curr.symbol}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* VIEW MODE */}
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800">
                <label className="block text-slate-800 dark:text-slate-200 font-bold mb-1 flex items-center gap-1.5">
                  <Smartphone className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  <span>طريقة عرض الواجهة</span>
                </label>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  <button
                    onClick={() =>
                      onUpdateSettings({ ...settings, viewMode: 'android_frame' })
                    }
                    className={`p-3 rounded-2xl border flex flex-col items-center gap-1 cursor-pointer transition-all ${
                      settings.viewMode === 'android_frame'
                        ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-200 font-bold shadow-xs'
                        : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    <span className="text-xs">📱 إطار هاتف أندرويد</span>
                    <span className="text-[10px] text-slate-400">محاكاة شاشة الموبايل</span>
                  </button>

                  <button
                    onClick={() =>
                      onUpdateSettings({ ...settings, viewMode: 'responsive' })
                    }
                    className={`p-3 rounded-2xl border flex flex-col items-center gap-1 cursor-pointer transition-all ${
                      settings.viewMode === 'responsive'
                        ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-200 font-bold shadow-xs'
                        : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    <span className="text-xs">💻 شاشة متجاوبة واسعة</span>
                    <span className="text-[10px] text-slate-400">للكمبيوتر والتابلت</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: FAMILY MEMBERS & FUNDS */}
          {activeSubTab === 'family' && (
            <div className="space-y-4">
              <div>
                <label className="block text-slate-800 dark:text-slate-200 font-bold mb-1 flex items-center gap-1.5">
                  <Users className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  <span>أفراد وصناديق الأسرة</span>
                </label>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mb-2.5">
                  لكل فرد صندوق مالي مستقل مع رصيد متاح ومصروف شهري مخصص.
                </p>

                <div className="space-y-1.5">
                  {familyMembers.map((member) => (
                    <div
                      key={member.id}
                      className="p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="text-xl">{member.avatar}</span>
                        <div>
                          <p className="text-xs font-bold text-slate-900 dark:text-white">
                            {member.name}
                          </p>
                          <span className="text-[10px] text-slate-500 dark:text-slate-400">
                            الصفة: {member.relation} · الرصيد: {member.walletBalance.toLocaleString('ar-EG')} {settings.currency.symbol}
                          </span>
                        </div>
                      </div>

                      <button
                        onClick={() => handleDeleteMember(member.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg transition-colors cursor-pointer"
                        title="حذف الفرد"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Add Member Form */}
              <form
                onSubmit={handleAddMember}
                className="p-3 bg-emerald-50/60 dark:bg-emerald-950/40 rounded-2xl border border-emerald-200/80 dark:border-emerald-800/50 space-y-2.5"
              >
                <h4 className="font-bold text-xs text-emerald-950 dark:text-emerald-200 flex items-center gap-1">
                  <Plus className="w-3.5 h-3.5" />
                  <span>إضافة فرد وصندوق جديد</span>
                </h4>

                <div className="flex gap-2">
                  <select
                    value={newMemberAvatar}
                    onChange={(e) => setNewMemberAvatar(e.target.value)}
                    className="p-2 rounded-xl border border-emerald-300 dark:border-emerald-700 bg-white dark:bg-slate-800 text-sm"
                  >
                    <option value="👨‍💼">👨‍💼 أب</option>
                    <option value="👩‍💼">👩‍💼 أم</option>
                    <option value="👦">👦 ابن</option>
                    <option value="👧">👧 ابنة</option>
                    <option value="👴">👴 جد</option>
                    <option value="👵">👵 جدة</option>
                    <option value="👶">👶 طفل</option>
                    <option value="🧑">🧑 آخر</option>
                  </select>

                  <input
                    type="text"
                    required
                    placeholder="الاسم (مثال: فيصل)"
                    value={newMemberName}
                    onChange={(e) => setNewMemberName(e.target.value)}
                    className="flex-1 p-2 rounded-xl border border-emerald-300 dark:border-emerald-700 bg-white dark:bg-slate-800 text-xs focus:outline-hidden"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] text-slate-500 block mb-0.5">الصفة</label>
                    <input
                      type="text"
                      value={newMemberRelation}
                      onChange={(e) => setNewMemberRelation(e.target.value)}
                      placeholder="ابن / ابنة"
                      className="w-full p-1.5 rounded-xl border border-emerald-300 dark:border-emerald-700 bg-white dark:bg-slate-800 text-xs focus:outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] text-slate-500 block mb-0.5">المصروف الشهري</label>
                    <input
                      type="number"
                      value={newMemberAllowance}
                      onChange={(e) => setNewMemberAllowance(e.target.value)}
                      placeholder="500"
                      className="w-full p-1.5 rounded-xl border border-emerald-300 dark:border-emerald-700 bg-white dark:bg-slate-800 text-xs focus:outline-hidden"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>حفظ وإضافة صندوق الفرد</span>
                </button>
              </form>
            </div>
          )}

          {/* TAB 4: DATA & BACKUP */}
          {activeSubTab === 'data' && (
            <div className="space-y-4">
              <div className="p-3 bg-slate-50 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="flex items-center gap-2 text-slate-800 dark:text-slate-200 font-bold">
                  <Database className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  <span>تصدير البيانات والمحاسبة</span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  يمكنك تصدير كافة العمليات المالية وفواتير المنزل إلى ملف إكسل CSV للمراجعة والطباعة.
                </p>
                <button
                  onClick={onExportCSV}
                  className="w-full py-2.5 px-3 bg-white dark:bg-slate-700 hover:bg-slate-100 border border-slate-300 dark:border-slate-600 rounded-xl text-xs font-bold text-slate-700 dark:text-slate-200 flex items-center justify-center gap-2 transition-all cursor-pointer shadow-2xs"
                >
                  <Download className="w-4 h-4 text-emerald-600" />
                  <span>تصدير تقرير العمليات كملف Excel (CSV)</span>
                </button>
              </div>

              {/* Sample Data & Reset */}
              <div className="space-y-2">
                <button
                  onClick={() => {
                    if (confirm('هل تريد استعادة البيانات النموذجية للمنزل للتجربة؟')) {
                      onResetSampleData();
                      onClose();
                    }
                  }}
                  className="w-full py-2.5 px-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <RefreshCw className="w-4 h-4 text-blue-500" />
                  <span>استعادة البيانات النموذجية للمنزل</span>
                </button>

                <button
                  onClick={() => {
                    if (confirm('تحذير: هل أنت متأكد من رغبتك في مسح كافة العمليات والفواتير والبدء من الصفر؟')) {
                      onClearAllData();
                      onClose();
                    }
                  }}
                  className="w-full py-2.5 px-3 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 text-rose-700 dark:text-rose-400 border border-rose-200 dark:border-rose-900/60 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>مسح كافة السجلات والبدء بسجل فارغ</span>
                </button>
              </div>

              {/* Info Note */}
              <div className="flex items-start gap-2 text-[10px] text-slate-400 p-2.5 bg-slate-50 dark:bg-slate-800/50 rounded-xl">
                <Info className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                <span>جميع البيانات تخزن محلياً على جهازك بصيغة مشفرة وآمنة دون الحاجة لإنترنت.</span>
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
