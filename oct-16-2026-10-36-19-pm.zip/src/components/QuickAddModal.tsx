import React, { useState } from 'react';
import {
  X,
  Plus,
  Check,
  Calendar,
  CreditCard,
  Banknote,
  Smartphone,
  User,
  Zap,
  Sparkles,
  Wallet,
} from 'lucide-react';
import {
  Transaction,
  TransactionType,
  PaymentMethod,
  FamilyMember,
  IncomeKind,
} from '../types';
import {
  EXPENSE_CATEGORIES,
  INCOME_CATEGORIES,
} from '../constants/categories';
import { CategoryIcon } from './CategoryIcon';

interface QuickAddModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddTransaction: (
    tx: Omit<Transaction, 'id' | 'createdAt'>,
    options?: { deductFromFund?: boolean; depositToFund?: boolean }
  ) => void;
  familyMembers: FamilyMember[];
  currencySymbol: string;
}

export const QuickAddModal: React.FC<QuickAddModalProps> = ({
  isOpen,
  onClose,
  onAddTransaction,
  familyMembers,
  currencySymbol,
}) => {
  const [type, setType] = useState<TransactionType>('expense');
  const [amount, setAmount] = useState<string>('');
  const [title, setTitle] = useState<string>('');
  const [category, setCategory] = useState<string>('groceries');
  const [incomeKind, setIncomeKind] = useState<IncomeKind>('salary');
  const [date, setDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('card');
  const [familyMemberId, setFamilyMemberId] = useState<string>(
    familyMembers[0]?.id || ''
  );
  const [selectedFundId, setSelectedFundId] = useState<string>(
    familyMembers[0]?.id || 'general'
  );
  const [affectFundBalance, setAffectFundBalance] = useState<boolean>(true);
  const [notes, setNotes] = useState<string>('');
  const [error, setError] = useState<string>('');

  if (!isOpen) return null;

  const currentCategories =
    type === 'expense' ? EXPENSE_CATEGORIES : INCOME_CATEGORIES;

  // Preset titles for ultra-fast tap
  const quickExpensePresets = [
    'تموينات وبقالة',
    'خضار وفواكه',
    'لحوم ودواجن',
    'فاتورة كهرباء',
    'وقود وبنزين',
    'صيدلية وعلاج',
    'مصروف مدرسي',
    'عشاء مطعم',
  ];

  const quickIncomePresets = [
    'الراتب الشهري الأساسي',
    '⚡ دخل مفاجئ - بيع غرض قديم',
    '⚡ دخل مفاجئ - مكافأة غير متوقعة',
    'عمل إضافي / استشارة',
    'أرباح استثمار وتجارة',
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      setError('يرجى إدخال مبلغ صحيح أكبر من الصفر');
      return;
    }

    if (!title.trim()) {
      setError('يرجى كتابة اسم البند أو العملية');
      return;
    }

    const isSudden = type === 'income' && incomeKind === 'sudden_income';

    onAddTransaction(
      {
        type,
        title: title.trim(),
        amount: numAmount,
        category,
        incomeKind: type === 'income' ? incomeKind : undefined,
        isSuddenIncome: isSudden,
        date,
        paymentMethod,
        familyMemberId: familyMemberId || undefined,
        fundId: selectedFundId || undefined,
        notes: notes.trim() || undefined,
      },
      {
        deductFromFund: type === 'expense' && affectFundBalance,
        depositToFund: type === 'income' && affectFundBalance,
      }
    );

    // Reset fields
    setAmount('');
    setTitle('');
    setNotes('');
    setError('');
    onClose();
  };

  const handleQuickPresetClick = (presetTitle: string) => {
    setTitle(presetTitle);
    if (presetTitle.includes('مفاجئ')) {
      setIncomeKind('sudden_income');
      setCategory('sudden_income');
    } else if (presetTitle.includes('بقالة')) setCategory('groceries');
    else if (presetTitle.includes('خضار') || presetTitle.includes('لحوم')) setCategory('meat_produce');
    else if (presetTitle.includes('فاتورة')) setCategory('utilities');
    else if (presetTitle.includes('وقود')) setCategory('transport');
    else if (presetTitle.includes('صيدلية')) setCategory('health');
    else if (presetTitle.includes('راتب')) {
      setIncomeKind('salary');
      setCategory('salary');
    }
  };

  const addAmount = (increment: number) => {
    const current = parseFloat(amount) || 0;
    setAmount(String(current + increment));
  };

  const selectedMemberFund = familyMembers.find((m) => m.id === selectedFundId);

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4">
      {/* Drawer Container */}
      <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl shadow-2xl max-h-[92vh] flex flex-col overflow-hidden animate-in slide-in-from-bottom-6 duration-200">
        
        {/* Drag handle affordance */}
        <div className="w-12 h-1.5 bg-slate-300 dark:bg-slate-700 rounded-full mx-auto my-2.5 sm:hidden" />

        {/* Modal Header */}
        <div className="px-5 py-3 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Plus className="w-5 h-5 text-emerald-600" />
            <span>تسجيل عملية جديدة</span>
          </h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 flex items-center justify-center text-slate-500"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-5 space-y-4 text-xs">
          {error && (
            <div className="p-2.5 rounded-xl bg-red-50 text-red-700 dark:bg-red-950/50 dark:text-red-300 text-xs font-semibold flex items-center gap-2">
              <span>⚠️</span>
              <span>{error}</span>
            </div>
          )}

          {/* Type Switcher: Segmented Control */}
          <div className="grid grid-cols-2 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl gap-1">
            <button
              type="button"
              onClick={() => {
                setType('expense');
                setCategory('groceries');
              }}
              className={`py-2 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                type === 'expense'
                  ? 'bg-rose-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              <span>🔻</span>
              <span>تسجيل مصروف للمنزل</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setType('income');
                setCategory('salary');
                setIncomeKind('salary');
              }}
              className={`py-2 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                type === 'income'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              <span>🔺</span>
              <span>تسجيل دخل / راتب</span>
            </button>
          </div>

          {/* SPECIFIC INCOME TYPE SELECTOR (Salary vs Sudden Income vs Others) */}
          {type === 'income' && (
            <div className="p-3 bg-amber-50/70 dark:bg-amber-950/40 rounded-2xl border border-amber-200/80 dark:border-amber-800/50 space-y-2">
              <label className="block text-amber-950 dark:text-amber-200 font-bold flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span>تصنيف نوع الدخل:</span>
              </label>

              <div className="grid grid-cols-2 gap-1.5">
                <button
                  type="button"
                  onClick={() => {
                    setIncomeKind('salary');
                    setCategory('salary');
                  }}
                  className={`p-2 rounded-xl border text-right transition-all flex items-center gap-2 cursor-pointer ${
                    incomeKind === 'salary'
                      ? 'border-emerald-600 bg-white dark:bg-slate-800 text-emerald-800 dark:text-emerald-300 font-bold shadow-xs'
                      : 'border-slate-200 dark:border-slate-700 bg-white/60 dark:bg-slate-800/60 text-slate-600'
                  }`}
                >
                  <span className="text-base">💼</span>
                  <div>
                    <p className="text-xs font-bold">الراتب الأساسي</p>
                    <span className="text-[10px] text-slate-500">الدخل الشهري الثابت</span>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setIncomeKind('sudden_income');
                    setCategory('sudden_income');
                  }}
                  className={`p-2 rounded-xl border text-right transition-all flex items-center gap-2 cursor-pointer ${
                    incomeKind === 'sudden_income'
                      ? 'border-amber-500 bg-amber-100 dark:bg-amber-950 text-amber-950 dark:text-amber-200 font-bold shadow-xs ring-2 ring-amber-400/50'
                      : 'border-slate-200 dark:border-slate-700 bg-white/60 dark:bg-slate-800/60 text-slate-600'
                  }`}
                >
                  <span className="text-base">⚡</span>
                  <div>
                    <p className="text-xs font-bold text-amber-800 dark:text-amber-300">دخل مفاجئ / طارئ</p>
                    <span className="text-[10px] text-slate-500">غير متوقع / بيع غرض / هدية</span>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setIncomeKind('freelance');
                    setCategory('freelance');
                  }}
                  className={`p-2 rounded-xl border text-right transition-all flex items-center gap-2 cursor-pointer ${
                    incomeKind === 'freelance'
                      ? 'border-emerald-600 bg-white dark:bg-slate-800 text-emerald-800 font-bold shadow-xs'
                      : 'border-slate-200 dark:border-slate-700 bg-white/60 dark:bg-slate-800/60 text-slate-600'
                  }`}
                >
                  <span className="text-base">📈</span>
                  <span className="text-xs font-bold">عمل إضافي / حر</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setIncomeKind('bonus');
                    setCategory('bonus');
                  }}
                  className={`p-2 rounded-xl border text-right transition-all flex items-center gap-2 cursor-pointer ${
                    incomeKind === 'bonus'
                      ? 'border-emerald-600 bg-white dark:bg-slate-800 text-emerald-800 font-bold shadow-xs'
                      : 'border-slate-200 dark:border-slate-700 bg-white/60 dark:bg-slate-800/60 text-slate-600'
                  }`}
                >
                  <span className="text-base">🎁</span>
                  <span className="text-xs font-bold">مكافأة أو إكرامية</span>
                </button>
              </div>
            </div>
          )}

          {/* Amount Input with big numeric font */}
          <div>
            <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">
              المبلغ ({currencySymbol})
            </label>
            <div className="relative flex items-center">
              <input
                type="number"
                step="any"
                inputMode="decimal"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                className="w-full text-2xl font-bold text-center py-2.5 px-3 rounded-2xl border-2 border-slate-200 dark:border-slate-700 focus:border-emerald-500 dark:focus:border-emerald-500 focus:outline-hidden bg-slate-50 dark:bg-slate-800/60 tabular-nums text-slate-900 dark:text-white"
                autoFocus
              />
              <span className="absolute left-4 font-bold text-sm text-slate-400">
                {currencySymbol}
              </span>
            </div>
            {/* Quick increment buttons */}
            <div className="flex items-center gap-1.5 mt-2 overflow-x-auto pb-1">
              {[20, 50, 100, 200, 500, 1000].map((inc) => (
                <button
                  key={inc}
                  type="button"
                  onClick={() => addAmount(inc)}
                  className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-semibold text-[11px] shrink-0 tabular-nums cursor-pointer"
                >
                  +{inc}
                </button>
              ))}
            </div>
          </div>

          {/* Description & Quick Presets */}
          <div>
            <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">
              اسم البند / التفاصيل
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={type === 'expense' ? 'مثال: أغراض السوبرماركت، لحوم، صيانة...' : 'مثال: راتب الشهر، مكافأة تميز...'}
              className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 focus:border-emerald-500 focus:outline-hidden bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs"
            />
            {/* Presets */}
            <div className="flex flex-wrap gap-1.5 mt-2">
              {(type === 'expense' ? quickExpensePresets : quickIncomePresets).map(
                (preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => handleQuickPresetClick(preset)}
                    className="px-2.5 py-1 rounded-full bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-[11px] cursor-pointer"
                  >
                    {preset}
                  </button>
                )
              )}
            </div>
          </div>

          {/* FAMILY MEMBER WALLET / FUND ALLOCATION */}
          <div className="p-3 bg-slate-50 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2">
            <label className="block text-slate-800 dark:text-slate-200 font-bold flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Wallet className="w-4 h-4 text-emerald-600" />
                <span>
                  {type === 'expense'
                    ? 'خصم المصروف من صندوق/محفظة:'
                    : 'إيداع هذا الدخل في صندوق:'}
                </span>
              </span>
              {selectedMemberFund && (
                <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-normal">
                  رصيد الصندوق: <strong>{selectedMemberFund.walletBalance} {currencySymbol}</strong>
                </span>
              )}
            </label>

            <select
              value={selectedFundId}
              onChange={(e) => {
                setSelectedFundId(e.target.value);
                setFamilyMemberId(e.target.value);
              }}
              className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 text-xs font-semibold focus:outline-hidden"
            >
              {familyMembers.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.avatar} صندوق {m.name} (المتاح: {m.walletBalance} {currencySymbol})
                </option>
              ))}
            </select>

            <label className="flex items-center gap-2 pt-1 text-[11px] text-slate-600 dark:text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={affectFundBalance}
                onChange={(e) => setAffectFundBalance(e.target.checked)}
                className="w-4 h-4 rounded text-emerald-600 accent-emerald-600"
              />
              <span>
                {type === 'expense'
                  ? 'تحديث وخصم المبلغ تلقائياً من رصيد محفظة هذا الصندوق'
                  : 'إضافة المبلغ وتحديث رصيد صندوق هذا الفرد تلقائياً'}
              </span>
            </label>
          </div>

          {/* Category Selector Grid */}
          <div>
            <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1.5">
              الفئة والتصنيف
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 max-h-36 overflow-y-auto p-1 border border-slate-100 dark:border-slate-800 rounded-xl">
              {currentCategories.map((cat) => {
                const isSelected = category === cat.id;
                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setCategory(cat.id)}
                    className={`p-2 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
                      isSelected
                        ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-900 dark:text-emerald-200 shadow-xs font-bold'
                        : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50'
                    }`}
                  >
                    <div
                      className="w-7 h-7 rounded-lg flex items-center justify-center text-white"
                      style={{ backgroundColor: cat.color }}
                    >
                      <CategoryIcon name={cat.icon} className="w-4 h-4" />
                    </div>
                    <span className="text-[10px] text-center leading-tight line-clamp-1">
                      {cat.name}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Payment Method & Date */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">
                طريقة الدفع
              </label>
              <div className="grid grid-cols-3 gap-1">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('cash')}
                  className={`py-2 px-1 rounded-xl border flex flex-col items-center justify-center gap-0.5 text-[10px] cursor-pointer ${
                    paymentMethod === 'cash'
                      ? 'border-emerald-600 bg-emerald-50 text-emerald-800 font-bold'
                      : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  <Banknote className="w-3.5 h-3.5" />
                  <span>نقداً</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('card')}
                  className={`py-2 px-1 rounded-xl border flex flex-col items-center justify-center gap-0.5 text-[10px] cursor-pointer ${
                    paymentMethod === 'card'
                      ? 'border-emerald-600 bg-emerald-50 text-emerald-800 font-bold'
                      : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  <CreditCard className="w-3.5 h-3.5" />
                  <span>بطاقة</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('transfer')}
                  className={`py-2 px-1 rounded-xl border flex flex-col items-center justify-center gap-0.5 text-[10px] cursor-pointer ${
                    paymentMethod === 'transfer'
                      ? 'border-emerald-600 bg-emerald-50 text-emerald-800 font-bold'
                      : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  <span>تحويل</span>
                </button>
              </div>
            </div>

            <div>
              <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-emerald-600" />
                <span>تاريخ العملية</span>
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs focus:outline-hidden"
              />
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">
              ملاحظات إضافية (اختياري)
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="مثال: فاتورة بقالة مع مستلزمات الضيوف..."
              className="w-full p-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs focus:outline-hidden"
            />
          </div>

          {/* Submit Action Button */}
          <div className="pt-2">
            <button
              type="submit"
              className={`w-full py-3 rounded-2xl text-white font-bold text-sm shadow-lg flex items-center justify-center gap-2 active:scale-[0.98] transition-all cursor-pointer ${
                type === 'expense'
                  ? 'bg-rose-600 hover:bg-rose-700 shadow-rose-600/30'
                  : 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-600/30'
              }`}
            >
              <Check className="w-5 h-5 stroke-[2.5]" />
              <span>
                {type === 'expense'
                  ? 'حفظ المصروف وخصمه من الصندوق'
                  : incomeKind === 'sudden_income'
                  ? 'حفظ الدخل المفاجئ ⚡'
                  : 'حفظ الإيراد / الراتب'}
              </span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
