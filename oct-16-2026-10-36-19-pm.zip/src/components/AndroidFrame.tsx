import React, { useState, useEffect } from 'react';
import { Wifi, BatteryMedium, Signal, Smartphone, Monitor, Sparkles } from 'lucide-react';
import { ThemeAccent, BackgroundStyle } from '../types';

interface AndroidFrameProps {
  children: React.ReactNode;
  viewMode: 'android_frame' | 'responsive';
  onToggleViewMode: () => void;
  themeAccent?: ThemeAccent;
  backgroundStyle?: BackgroundStyle;
}

export const AndroidFrame: React.FC<AndroidFrameProps> = ({
  children,
  viewMode,
  onToggleViewMode,
  themeAccent = 'emerald',
  backgroundStyle = 'oasis_mesh',
}) => {
  const [currentTime, setCurrentTime] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = now.getHours();
      const minutes = String(now.getMinutes()).padStart(2, '0');
      setCurrentTime(`${hours}:${minutes}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 10000);
    return () => clearInterval(interval);
  }, []);

  const getPatternClass = (style: BackgroundStyle) => {
    switch (style) {
      case 'arabesque':
        return 'bg-pattern-arabesque';
      case 'slate_minimal':
        return 'bg-pattern-slate-minimal';
      case 'warm_sand':
        return 'bg-pattern-warm-sand';
      case 'oasis_mesh':
      default:
        return 'bg-pattern-oasis-mesh';
    }
  };

  const patternClass = getPatternClass(backgroundStyle);

  if (viewMode === 'responsive') {
    return (
      <div
        data-theme-accent={themeAccent}
        className={`min-h-screen bg-slate-100/90 dark:bg-slate-950 text-slate-800 dark:text-slate-100 flex flex-col ${patternClass} transition-colors duration-300`}
      >
        {/* Responsive Desktop Mode Switcher Bar */}
        <header className="sticky top-0 z-40 bg-slate-900/95 text-slate-200 px-4 sm:px-6 py-2.5 flex items-center justify-between text-xs border-b border-slate-800/80 backdrop-blur-md">
          <div className="flex items-center gap-2.5">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></div>
            <span className="font-bold text-white text-sm">مصاريف البيت</span>
            <span className="text-slate-400 text-xs hidden sm:inline">
              · وضع الشاشة الواسعة للكمبيوتر واللوحي
            </span>
          </div>
          <button
            onClick={onToggleViewMode}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white transition-all cursor-pointer text-xs font-semibold border border-slate-700/60 shadow-xs"
          >
            <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
            <span>عرض في شكل هاتف أندرويد</span>
          </button>
        </header>

        {/* Content Area */}
        <div className="flex-1 max-w-4xl w-full mx-auto p-2 sm:p-5 md:p-6">
          <div className="rounded-3xl bg-white/80 dark:bg-slate-900/85 backdrop-blur-xl border border-slate-200/80 dark:border-slate-800 shadow-xl overflow-hidden min-h-[85vh] flex flex-col relative">
            {children}
          </div>
        </div>
      </div>
    );
  }

  // Android Phone Frame Mode
  return (
    <div
      data-theme-accent={themeAccent}
      className={`min-h-screen bg-radial from-slate-900 via-slate-950 to-black text-slate-100 flex flex-col items-center justify-start py-3 px-2 sm:py-6 sm:px-4 relative overflow-x-hidden ${patternClass} transition-colors duration-300`}
    >
      {/* Ambient Atmospheric Lighting Behind Phone */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[520px] h-[520px] bg-emerald-500/10 dark:bg-emerald-500/15 rounded-full blur-[110px] pointer-events-none" />
      <div className="absolute bottom-1/4 left-1/3 w-[400px] h-[400px] bg-teal-500/10 dark:bg-teal-600/10 rounded-full blur-[100px] pointer-events-none" />

      {/* Top Device Bar & Mode Switcher */}
      <div className="w-full max-w-[420px] mb-2.5 flex items-center justify-between px-3 text-xs text-slate-300 z-10">
        <div className="flex items-center gap-2 font-medium">
          <span className="w-2 h-2 rounded-full bg-emerald-400 shadow-xs shadow-emerald-400"></span>
          <span className="text-[12px] text-slate-200 font-semibold tracking-tight">
            نظام أندرويد 15 · تجربة أصلية
          </span>
        </div>
        <button
          onClick={onToggleViewMode}
          className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800/80 hover:bg-slate-700/90 border border-slate-700/80 text-slate-300 hover:text-white transition-all cursor-pointer text-[11px] font-medium shadow-sm"
          title="تبديل إلى وضع ملء الشاشة للكمبيوتر"
        >
          <Monitor className="w-3.5 h-3.5 text-emerald-400" />
          <span>ملء الشاشة</span>
        </button>
      </div>

      {/* Android Phone Body Mockup (Realistic Titanium Bezel & Rounded Geometry) */}
      <div className="w-full max-w-[412px] h-[870px] max-h-[92vh] bg-gradient-to-b from-slate-900 to-black rounded-[48px] p-2.5 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] ring-1 ring-white/15 ring-offset-2 ring-offset-slate-950 relative flex flex-col overflow-hidden z-10">
        
        {/* Subtle Titanium Inner Edge Highlight */}
        <div className="w-full h-full bg-slate-50 dark:bg-slate-900/95 rounded-[40px] overflow-hidden flex flex-col relative border border-slate-700/50 shadow-inner">
          
          {/* Android Status Bar (Direction LTR: time on left, camera punch-hole center, signal/battery right) */}
          <div
            dir="ltr"
            className="w-full h-8 bg-slate-900/95 dark:bg-slate-950/95 text-white/90 px-5 flex items-center justify-between text-[12px] font-semibold tracking-tight select-none z-30 shrink-0 border-b border-white/5"
          >
            <span className="font-sans tabular-nums text-white text-[12px] font-medium">
              {currentTime || '12:45'}
            </span>
            
            {/* Front Camera Punch Hole */}
            <div className="w-3.5 h-3.5 rounded-full bg-black ring-1 ring-white/20 mx-auto shadow-inner flex items-center justify-center">
              <div className="w-1.5 h-1.5 rounded-full bg-slate-900 ring-1 ring-blue-500/20"></div>
            </div>

            <div className="flex items-center gap-1.5 text-white/80">
              <Signal className="w-3.5 h-3.5" />
              <Wifi className="w-3.5 h-3.5" />
              <div className="flex items-center gap-1">
                <span className="text-[10px] font-mono tabular-nums">98%</span>
                <BatteryMedium className="w-4 h-4 text-emerald-400" />
              </div>
            </div>
          </div>

          {/* Main App Content inside Android Screen */}
          <div className={`flex-1 overflow-y-auto flex flex-col bg-slate-50/90 dark:bg-slate-900/90 ${patternClass} relative transition-colors duration-300`}>
            {children}
          </div>

          {/* Android Gesture Navigation Bar Pill */}
          <div className="w-full h-4 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md flex items-center justify-center shrink-0 z-40 border-t border-slate-200/50 dark:border-slate-800/50">
            <div className="w-28 h-1 bg-slate-400 dark:bg-slate-600 rounded-full"></div>
          </div>
        </div>
      </div>
    </div>
  );
};
