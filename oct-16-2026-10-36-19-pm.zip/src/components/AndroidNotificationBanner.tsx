import React, { useState } from 'react';
import { Zap, Bell, CheckCircle2, X } from 'lucide-react';
import { BillNotification } from '../utils/notifications';
import { formatCurrency } from '../constants/currencies';
import { CurrencyConfig } from '../types';

interface AndroidNotificationBannerProps {
  urgentAlert: BillNotification | null;
  currency: CurrencyConfig;
  onPayBill: (billId: string) => void;
  onDismiss: () => void;
}

export const AndroidNotificationBanner: React.FC<AndroidNotificationBannerProps> = ({
  urgentAlert,
  currency,
  onPayBill,
  onDismiss,
}) => {
  if (!urgentAlert) return null;

  return (
    <aside
      aria-label="تنبيه استحقاق الفواتير"
      className="mx-3 my-2 p-3 bg-gradient-to-l from-amber-600 via-amber-700 to-orange-700 text-white rounded-2xl shadow-lg shadow-amber-950/20 flex items-center justify-between gap-2.5 animate-in slide-in-from-top-4 duration-300"
    >
      <div className="flex items-center gap-2.5 overflow-hidden">
        <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
          <Zap className="w-4 h-4 text-amber-200 fill-amber-200" />
        </div>
        <div className="overflow-hidden">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="font-bold text-xs">تذكير استحقاق فاتورة</span>
            <span className="text-[10px] bg-white/20 px-1.5 py-0.2 rounded font-semibold">
              {urgentAlert.dueText}
            </span>
          </div>
          <p className="text-[11px] text-amber-100 truncate mt-0.5">
            <strong>{urgentAlert.billTitle}</strong> بمبلغ{' '}
            <strong className="tabular-nums">
              {formatCurrency(urgentAlert.amount, currency.symbol)}
            </strong>
          </p>
        </div>
      </div>

      <div className="flex items-center gap-1.5 shrink-0">
        <button
          onClick={() => onPayBill(urgentAlert.billId)}
          className="px-2.5 py-1.5 bg-white text-amber-900 hover:bg-amber-50 font-bold rounded-xl text-[11px] shadow-sm active:scale-95 transition-all flex items-center gap-1 cursor-pointer"
        >
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span>سداد</span>
        </button>
        <button
          onClick={onDismiss}
          className="p-1 text-white/70 hover:text-white rounded-lg cursor-pointer"
          title="تذكيري لاحقاً"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </aside>
  );
};
