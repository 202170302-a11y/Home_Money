import React, { useState } from 'react';
import {
  Bell,
  X,
  Zap,
  CheckCircle2,
  Calendar,
  AlertTriangle,
  Clock,
  Sparkles,
  Volume2,
} from 'lucide-react';
import { BillNotification, requestNotificationPermission, triggerNativeBillNotification } from '../utils/notifications';
import { formatCurrency } from '../constants/currencies';
import { CurrencyConfig } from '../types';

interface NotificationsCenterModalProps {
  isOpen: boolean;
  onClose: () => void;
  alerts: BillNotification[];
  currency: CurrencyConfig;
  onPayBill: (billId: string) => void;
}

export const NotificationsCenterModal: React.FC<NotificationsCenterModalProps> = ({
  isOpen,
  onClose,
  alerts,
  currency,
  onPayBill,
}) => {
  const [nativePermission, setNativePermission] = useState<string>(
    typeof window !== 'undefined' && 'Notification' in window
      ? Notification.permission
      : 'unsupported'
  );
  const [testSent, setTestSent] = useState(false);

  if (!isOpen) return null;

  const handleEnableNotifications = async () => {
    const granted = await requestNotificationPermission();
    setNativePermission(granted ? 'granted' : 'denied');
    if (granted) {
      triggerNativeBillNotification(
        '🔔 تم تفعيل تنبيهات الفواتير بنجاح',
        'سيقوم تطبيق مصاريف البيت بتذكيرك آلياً قبل موعد استحقاق أي فاتورة بـ 24 ساعة!'
      );
    }
  };

  const handleSendTestNotification = () => {
    triggerNativeBillNotification(
      '⚡ تنبيه استحقاق فاتورة (تجريبي)',
      `تذكير: فاتورة الكهرباء تستحق غداً بمبلغ 320 ${currency.symbol}، يرجى سدادها في الوقت المحدد.`
    );
    setTestSent(true);
    setTimeout(() => setTestSent(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 p-0 sm:p-4 backdrop-blur-xs">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl shadow-2xl max-h-[88vh] flex flex-col overflow-hidden text-xs text-slate-800 dark:text-slate-100">
        
        {/* Header */}
        <div className="px-5 py-3.5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-amber-50 dark:bg-amber-950 text-amber-600 flex items-center justify-center">
              <Bell className="w-4 h-4" />
            </div>
            <span>مركز التنبيهات وإشعارات الفواتير</span>
          </h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 flex items-center justify-center text-slate-500"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 flex-1 overflow-y-auto space-y-4">
          
          {/* Permission & System Alert Banner */}
          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs flex items-center gap-1.5 text-slate-900 dark:text-white">
                <Volume2 className="w-4 h-4 text-emerald-600" />
                <span>إشعارات الهاتف وتنبيهات الـ 24 ساعة</span>
              </span>
              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  nativePermission === 'granted'
                    ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                    : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                }`}
              >
                {nativePermission === 'granted' ? 'مفعلة ✅' : 'غير مفعلة'}
              </span>
            </div>

            <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
              يقوم النظام بفحص فواتيرك الدورية وتنبيهك تلقائياً قبل موعد الاستحقاق بـ <strong>24 ساعة</strong> حتى لا يفوتك السداد أو تُقطع الخدمة.
            </p>

            <div className="flex items-center gap-2 pt-1">
              {nativePermission !== 'granted' ? (
                <button
                  onClick={handleEnableNotifications}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center gap-1 transition-all cursor-pointer shadow-sm"
                >
                  <Bell className="w-3.5 h-3.5" />
                  <span>تفعيل إشعارات الهاتف الآن</span>
                </button>
              ) : (
                <button
                  onClick={handleSendTestNotification}
                  className="px-3 py-1.5 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 text-slate-700 dark:text-slate-200 font-semibold rounded-xl text-xs flex items-center gap-1 transition-all cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                  <span>إرسال إشعار تجريبي 📲</span>
                </button>
              )}
            </div>

            {testSent && (
              <p className="text-[10px] text-emerald-600 font-bold animate-in fade-in">
                ✅ تم إرسال الإشعار التجريبي لهاتفك بنجاح!
              </p>
            )}
          </div>

          {/* Active 24-Hour Due Alerts */}
          <div className="space-y-2">
            <h4 className="font-bold text-xs text-slate-900 dark:text-white flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-amber-500" />
                <span>الفواتير المستحقة حالياً وقريباً</span>
              </span>
              <span className="text-[10px] text-slate-400">
                ({alerts.length} تنبيه نشط)
              </span>
            </h4>

            {alerts.length === 0 ? (
              <div className="p-6 text-center bg-slate-50 dark:bg-slate-800 rounded-2xl border border-dashed border-slate-200 dark:border-slate-700 text-slate-500 space-y-1">
                <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto" />
                <p className="font-bold text-xs text-slate-800 dark:text-slate-200">
                  لا توجد فواتير تستحق خلال الـ 24 ساعة القادمة
                </p>
                <p className="text-[11px] text-slate-400">
                  جميع فواتيرك إما تم سدادها أو موعدها بعد أكثر من يومين.
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                {alerts.map((alert) => (
                  <div
                    key={alert.id}
                    className="p-3.5 rounded-2xl bg-amber-50/80 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 shadow-xs flex items-center justify-between"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0">
                        <Zap className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <h5 className="font-bold text-xs text-slate-900 dark:text-white">
                            {alert.billTitle}
                          </h5>
                          <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-amber-200 dark:bg-amber-900 text-amber-900 dark:text-amber-200">
                            {alert.dueText}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                          المبلغ المطلوب:{' '}
                          <strong className="text-amber-800 dark:text-amber-300 tabular-nums">
                            {formatCurrency(alert.amount, currency.symbol)}
                          </strong>
                          {' '}· يوم {alert.dueDay} من الشهر
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        onPayBill(alert.billId);
                      }}
                      className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center gap-1 shadow-sm cursor-pointer shrink-0"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>سداد الآن</span>
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>
      </div>
    </div>
  );
};
