import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Download, X, Smartphone, CheckCircle } from 'lucide-react';

export const PWAInstallBanner: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  // If running in standalone or user dismissed, don't show
  if (isInstalled || dismissed) {
    return null;
  }

  // If installable on Android / Chrome / Chromium
  if (isInstallable) {
    return (
      <div className="mx-4 my-2 p-3 bg-gradient-to-l from-emerald-600 to-emerald-700 text-white rounded-2xl shadow-md flex items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
            <Smartphone className="w-5 h-5 text-white" />
          </div>
          <div>
            <p className="font-bold text-sm">تثبيت تطبيق الأندرويد</p>
            <p className="text-emerald-100 text-[11px]">ثبّت التطبيق على شاشتك الرئيسية للوصول السريع بدون إنترنت</p>
          </div>
        </div>
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={install}
            className="px-3 py-1.5 bg-white text-emerald-800 font-bold rounded-xl text-xs hover:bg-emerald-50 active:scale-95 transition-all flex items-center gap-1 shadow-sm"
          >
            <Download className="w-3.5 h-3.5" />
            <span>تثبيت</span>
          </button>
          <button
            onClick={() => setDismissed(true)}
            className="p-1 text-white/70 hover:text-white rounded-lg"
            title="إغلاق"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  // iOS Safari flow
  if (isIOS) {
    return (
      <>
        <div className="mx-4 my-2 p-3 bg-slate-800 text-white rounded-2xl shadow flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-emerald-400" />
            <span>إضافة التطبيق للشاشة الرئيسية على آيفون</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowIOSGuide(true)}
              className="px-2.5 py-1 bg-emerald-600 rounded-lg text-[11px] font-semibold"
            >
              طريقة التثبيت
            </button>
            <button onClick={() => setDismissed(true)} className="text-slate-400">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
            <div className="w-full max-w-sm rounded-2xl bg-white p-5 shadow-2xl text-slate-800">
              <h3 className="text-base font-bold text-slate-900 mb-2 flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-emerald-600" />
                تثبيت على الشاشة الرئيسية
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed mb-4">
                1. اضغط على زر <strong>مشاركة (Share)</strong> في شريط متصفح Safari بالأسفل.<br />
                2. مرر للأسفل واختر <strong>إضافة إلى الصفحة الرئيسية (Add to Home Screen)</strong>.<br />
                3. اضغط على <strong>إضافة (Add)</strong> بالأعلى لتجد أيقونة التطبيق على هاتفك.
              </p>
              <button
                onClick={() => setShowIOSGuide(false)}
                className="w-full py-2 bg-emerald-600 text-white rounded-xl text-xs font-bold"
              >
                فهمت ذلك
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
