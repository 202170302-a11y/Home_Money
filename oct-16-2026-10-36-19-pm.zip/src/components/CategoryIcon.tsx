import React from 'react';
import {
  ShoppingCart,
  Zap,
  Apple,
  Home,
  HeartPulse,
  GraduationCap,
  Car,
  Utensils,
  Shirt,
  Gift,
  CreditCard,
  Package,
  Briefcase,
  TrendingUp,
  Users,
  Building,
  Award,
  Coins,
  Tag,
  Receipt,
  AlertCircle,
  Shield,
  Palmtree,
  Sparkles,
  Wallet,
  Sun,
  Moon,
  LucideProps,
} from 'lucide-react';

interface CategoryIconProps extends LucideProps {
  name: string;
}

export const CategoryIcon: React.FC<CategoryIconProps> = ({ name, ...props }) => {
  switch (name) {
    case 'ShoppingCart':
      return <ShoppingCart {...props} />;
    case 'Zap':
      return <Zap {...props} />;
    case 'Apple':
      return <Apple {...props} />;
    case 'Home':
      return <Home {...props} />;
    case 'HeartPulse':
      return <HeartPulse {...props} />;
    case 'GraduationCap':
      return <GraduationCap {...props} />;
    case 'Car':
      return <Car {...props} />;
    case 'Utensils':
      return <Utensils {...props} />;
    case 'Shirt':
      return <Shirt {...props} />;
    case 'Gift':
      return <Gift {...props} />;
    case 'CreditCard':
      return <CreditCard {...props} />;
    case 'Package':
      return <Package {...props} />;
    case 'Briefcase':
      return <Briefcase {...props} />;
    case 'TrendingUp':
      return <TrendingUp {...props} />;
    case 'Users':
      return <Users {...props} />;
    case 'Building':
      return <Building {...props} />;
    case 'Award':
      return <Award {...props} />;
    case 'Coins':
      return <Coins {...props} />;
    case 'Receipt':
      return <Receipt {...props} />;
    case 'AlertCircle':
      return <AlertCircle {...props} />;
    case 'Shield':
      return <Shield {...props} />;
    case 'Palmtree':
      return <Palmtree {...props} />;
    case 'Sparkles':
      return <Sparkles {...props} />;
    case 'Wallet':
      return <Wallet {...props} />;
    case 'Sun':
      return <Sun {...props} />;
    case 'Moon':
      return <Moon {...props} />;
    default:
      return <Tag {...props} />;
  }
};
