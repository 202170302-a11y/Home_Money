export type TransactionType = 'expense' | 'income';

export type PaymentMethod = 'cash' | 'card' | 'transfer';

export type IncomeKind =
  | 'salary' // الراتب الشهري المنتظم
  | 'sudden_income' // دخل مفاجئ / طارئ
  | 'freelance' // عمل إضافي / حر
  | 'bonus' // مكافأة أو إكرامية
  | 'investment' // أرباح وتجارة
  | 'family_contrib' // مساهمة أسرية
  | 'other';

export interface Transaction {
  id: string;
  type: TransactionType;
  title: string;
  amount: number;
  category: string;
  date: string; // YYYY-MM-DD
  paymentMethod: PaymentMethod;
  familyMemberId?: string; // الشخص المرتبط بالعملية
  fundId?: string; // الصندوق/المحفظة التي تم الخصم منها أو الإيداع فيها
  incomeKind?: IncomeKind; // تفصيل نوع الدخل (راتب، دخل مفاجئ، عمل إضافي...)
  isSuddenIncome?: boolean; // هل هذا دخل مفاجئ؟
  notes?: string;
  createdAt: number;
}

export interface CategoryItem {
  id: string;
  name: string;
  icon: string;
  color: string;
  bgColor: string;
  type: 'expense' | 'income' | 'both';
  defaultLimit?: number;
}

export interface CategoryBudget {
  categoryId: string;
  monthlyLimit: number;
}

export interface FamilyMember {
  id: string;
  name: string;
  relation: string; // أب، أم، ابن، ابنة، إلخ
  avatar: string;
  color: string;
  walletBalance: number; // الرصيد المالي الحالي لصندوق الفرد
  monthlyAllowance?: number; // المصروف الشهري المخصص
}

export interface SavingsGoal {
  id: string;
  title: string;
  targetAmount: number;
  currentAmount: number;
  targetDate?: string;
  category: 'emergency' | 'car' | 'eid' | 'travel' | 'house' | 'gold' | 'education' | 'general';
  color: string;
  icon: string;
  isCompleted: boolean;
  notes?: string;
  createdAt: number;
}

export interface FundLog {
  id: string;
  date: string;
  amount: number;
  type: 'deposit' | 'withdraw' | 'expense' | 'income';
  fundId: string; // member id or 'general'
  fundName: string;
  notes?: string;
  createdAt: number;
}

export interface BillItem {
  id: string;
  title: string;
  category: string;
  amount: number;
  dueDay: number; // Day of month (1 - 31)
  isPaid: boolean;
  notes?: string;
}

export interface DebtItem {
  id: string;
  type: 'owed_to_us' | 'owed_by_us'; // لنا على الغير | علينا للغير
  personName: string;
  amount: number;
  dueDate?: string;
  isPaid: boolean;
  notes?: string;
  createdAt: string;
}

export interface CurrencyConfig {
  code: string;
  symbol: string;
  name: string;
}

export type ThemeAccent = 'emerald' | 'sapphire' | 'amber' | 'amethyst';
export type BackgroundStyle = 'oasis_mesh' | 'arabesque' | 'slate_minimal' | 'warm_sand';

export interface AppSettings {
  currency: CurrencyConfig;
  monthlyTotalBudget: number;
  viewMode: 'android_frame' | 'responsive';
  themeMode: 'dark' | 'light' | 'system';
  themeAccent: ThemeAccent;
  backgroundStyle: BackgroundStyle;
}

export interface AdvisorResult {
  healthScore: number;
  summaryText: string;
  keyInsights: string[];
  actionPlan: string[];
}
