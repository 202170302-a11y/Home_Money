import {
  Transaction,
  CategoryBudget,
  FamilyMember,
  BillItem,
  DebtItem,
  AppSettings,
  SavingsGoal,
  FundLog,
} from '../types';
import { EXPENSE_CATEGORIES } from '../constants/categories';
import { DEFAULT_CURRENCY } from '../constants/currencies';

const STORAGE_KEYS = {
  TRANSACTIONS: 'home_money_transactions_v2',
  BUDGETS: 'home_money_budgets_v2',
  FAMILY: 'home_money_family_v2',
  BILLS: 'home_money_bills_v2',
  DEBTS: 'home_money_debts_v2',
  SETTINGS: 'home_money_settings_v2',
  SAVINGS_GOALS: 'home_money_savings_goals_v2',
  FUND_LOGS: 'home_money_fund_logs_v2',
};

export const INITIAL_FAMILY_MEMBERS: FamilyMember[] = [
  {
    id: 'father',
    name: 'أبو محمد (رب الأسرة)',
    relation: 'أب',
    avatar: '👨‍💼',
    color: '#0284c7',
    walletBalance: 1450,
    monthlyAllowance: 3000,
  },
  {
    id: 'mother',
    name: 'أم محمد (ربة المنزل)',
    relation: 'أم',
    avatar: '👩‍💼',
    color: '#db2777',
    walletBalance: 980,
    monthlyAllowance: 2000,
  },
  {
    id: 'son1',
    name: 'محمد',
    relation: 'ابن',
    avatar: '👦',
    color: '#059669',
    walletBalance: 320,
    monthlyAllowance: 450,
  },
  {
    id: 'daughter1',
    name: 'سارة',
    relation: 'ابنة',
    avatar: '👧',
    color: '#7c3aed',
    walletBalance: 240,
    monthlyAllowance: 350,
  },
];

export const INITIAL_SAVINGS_GOALS: SavingsGoal[] = [
  {
    id: 'goal_emergency',
    title: 'صندوق طوارئ المنزل',
    targetAmount: 10000,
    currentAmount: 4800,
    targetDate: '2026-12-31',
    category: 'emergency',
    color: '#059669',
    icon: 'Shield',
    isCompleted: false,
    notes: 'لحالات الطوارئ الطبية أو الأعطال المنزلية المفاجئة',
    createdAt: Date.now() - 86400000 * 45,
  },
  {
    id: 'goal_eid',
    title: 'مصاريف وكسوة العيد',
    targetAmount: 3500,
    currentAmount: 2200,
    targetDate: '2026-11-20',
    category: 'eid',
    color: '#db2777',
    icon: 'Gift',
    isCompleted: false,
    notes: 'ملابس العيد للأطفال وهدايا الأقارب والأضحية',
    createdAt: Date.now() - 86400000 * 30,
  },
  {
    id: 'goal_appliances',
    title: 'تجديد مكيفات وأجهزة الصالة',
    targetAmount: 4200,
    currentAmount: 1650,
    targetDate: '2027-02-15',
    category: 'house',
    color: '#7c3aed',
    icon: 'Home',
    isCompleted: false,
    notes: 'مكيف سبليت جديد وشاشة موفرة للطاقة',
    createdAt: Date.now() - 86400000 * 20,
  },
  {
    id: 'goal_car',
    title: 'شراء سيارة عائلية جديدة',
    targetAmount: 30000,
    currentAmount: 11500,
    targetDate: '2027-08-30',
    category: 'car',
    color: '#2563eb',
    icon: 'Car',
    isCompleted: false,
    notes: 'دفعة أولى أو شراء سيارة دفع رباعي للأسرة',
    createdAt: Date.now() - 86400000 * 60,
  },
];

export const INITIAL_BILLS: BillItem[] = [
  { id: 'bill_1', title: 'فاتورة الكهرباء الشهرية', category: 'utilities', amount: 320, dueDay: 25, isPaid: false, notes: 'عداد المنزل الرئيسي' },
  { id: 'bill_2', title: 'باقة إنترنت الألياف المنزلية (Wi-Fi)', category: 'utilities', amount: 285, dueDay: 1, isPaid: true, notes: 'سرعة 300 ميجا' },
  { id: 'bill_3', title: 'فاتورة المياه والصرف', category: 'utilities', amount: 95, dueDay: 18, isPaid: false },
  { id: 'bill_4', title: 'قسط تمويل السيارة العائلي', category: 'installments', amount: 1100, dueDay: 27, isPaid: false },
];

export const INITIAL_DEBTS: DebtItem[] = [
  {
    id: 'debt_1',
    type: 'owed_by_us',
    personName: 'ورشة الوفاء (صيانة التكييف)',
    amount: 350,
    dueDate: new Date(Date.now() + 86400000 * 5).toISOString().split('T')[0],
    isPaid: false,
    notes: 'باقي صيانة المكيف المركزي للصالة',
    createdAt: new Date().toISOString().split('T')[0],
  },
  {
    id: 'debt_2',
    type: 'owed_to_us',
    personName: 'أبو فهد (أخي)',
    amount: 500,
    dueDate: new Date(Date.now() + 86400000 * 14).toISOString().split('T')[0],
    isPaid: false,
    notes: 'سلفة مؤقتة لشراء قطع غيار',
    createdAt: new Date().toISOString().split('T')[0],
  },
];

export function getInitialBudgets(): CategoryBudget[] {
  return EXPENSE_CATEGORIES.map((cat) => ({
    categoryId: cat.id,
    monthlyLimit: cat.defaultLimit || 500,
  }));
}

export function generateSampleTransactions(): Transaction[] {
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, '0');
  const d = (day: number) => `${year}-${month}-${String(day).padStart(2, '0')}`;

  return [
    {
      id: 'tx_salary',
      type: 'income',
      title: 'الراتب الشهري الأساسي',
      amount: 8500,
      category: 'salary',
      incomeKind: 'salary',
      date: d(1),
      paymentMethod: 'transfer',
      familyMemberId: 'father',
      fundId: 'father',
      notes: 'إيداع الراتب في الحساب البنكي الرئيسي',
      createdAt: Date.now() - 86400000 * 15,
    },
    {
      id: 'tx_sudden1',
      type: 'income',
      title: 'دخل مفاجئ - بيع أثاث قديم مستعمل',
      amount: 750,
      category: 'sudden_income',
      incomeKind: 'sudden_income',
      isSuddenIncome: true,
      date: d(5),
      paymentMethod: 'cash',
      familyMemberId: 'father',
      fundId: 'mother',
      notes: 'بيع طاولة ومقاعد قديمة عبر حراج/السوق المفتوح',
      createdAt: Date.now() - 86400000 * 11,
    },
    {
      id: 'tx_sudden2',
      type: 'income',
      title: 'دخل مفاجئ - إكرامية ومكافأة تميز بالعمل',
      amount: 900,
      category: 'sudden_income',
      incomeKind: 'sudden_income',
      isSuddenIncome: true,
      date: d(10),
      paymentMethod: 'transfer',
      familyMemberId: 'father',
      fundId: 'father',
      notes: 'مكافأة غير متوقعة لإنجاز مشروع مبكراً',
      createdAt: Date.now() - 86400000 * 6,
    },
    {
      id: 'tx_freelance',
      type: 'income',
      title: 'دخل إضافي - استشارة تصميم عمل حر',
      amount: 1200,
      category: 'freelance',
      incomeKind: 'freelance',
      date: d(6),
      paymentMethod: 'transfer',
      familyMemberId: 'father',
      fundId: 'father',
      createdAt: Date.now() - 86400000 * 10,
    },
    {
      id: 'tx_rent',
      type: 'expense',
      title: 'إيجار شقة العائلة (الدفعة الشهرية)',
      amount: 2000,
      category: 'housing',
      date: d(2),
      paymentMethod: 'transfer',
      familyMemberId: 'father',
      fundId: 'father',
      createdAt: Date.now() - 86400000 * 14,
    },
    {
      id: 'tx_groc1',
      type: 'expense',
      title: 'تموينات الأسبوع ومواد غذائية (سوبرماركت العثيم)',
      amount: 485,
      category: 'groceries',
      date: d(3),
      paymentMethod: 'card',
      familyMemberId: 'mother',
      fundId: 'mother',
      notes: 'خصم من صندوق مصروف أم محمد',
      createdAt: Date.now() - 86400000 * 13,
    },
    {
      id: 'tx_meat',
      type: 'expense',
      title: 'لحم طازج ودواجن وخضار سوق الجمعة',
      amount: 240,
      category: 'meat_produce',
      date: d(5),
      paymentMethod: 'cash',
      familyMemberId: 'father',
      fundId: 'father',
      createdAt: Date.now() - 86400000 * 11,
    },
    {
      id: 'tx_son_pocket',
      type: 'expense',
      title: 'مصروف وكتب مدرسية لمحمد',
      amount: 120,
      category: 'education',
      date: d(7),
      paymentMethod: 'cash',
      familyMemberId: 'son1',
      fundId: 'son1',
      notes: 'خصم من صندوق مصروف محمد الخاص',
      createdAt: Date.now() - 86400000 * 9,
    },
    {
      id: 'tx_daughter_toy',
      type: 'expense',
      title: 'أدوات رسم وألوان لسارة',
      amount: 65,
      category: 'education',
      date: d(8),
      paymentMethod: 'cash',
      familyMemberId: 'daughter1',
      fundId: 'daughter1',
      notes: 'خصم من محفظة سارة الخاصة',
      createdAt: Date.now() - 86400000 * 8,
    },
    {
      id: 'tx_net',
      type: 'expense',
      title: 'سداد فاتورة إنترنت الألياف (فايبر)',
      amount: 285,
      category: 'utilities',
      date: d(1),
      paymentMethod: 'card',
      familyMemberId: 'father',
      fundId: 'father',
      createdAt: Date.now() - 86400000 * 15,
    },
    {
      id: 'tx_gas',
      type: 'expense',
      title: 'تعبئة بنزين سيارة العائلة',
      amount: 145,
      category: 'transport',
      date: d(9),
      paymentMethod: 'card',
      familyMemberId: 'father',
      fundId: 'father',
      createdAt: Date.now() - 86400000 * 7,
    },
    {
      id: 'tx_pharmacy',
      type: 'expense',
      title: 'أدوية وفيتامينات من الصيدلية',
      amount: 160,
      category: 'health',
      date: d(11),
      paymentMethod: 'card',
      familyMemberId: 'mother',
      fundId: 'mother',
      createdAt: Date.now() - 86400000 * 5,
    },
    {
      id: 'tx_dining',
      type: 'expense',
      title: 'عشاء عائلي نهاية الأسبوع',
      amount: 190,
      category: 'dining',
      date: d(12),
      paymentMethod: 'card',
      familyMemberId: 'father',
      fundId: 'father',
      notes: 'مطعم مشويات',
      createdAt: Date.now() - 86400000 * 4,
    },
  ];
}

// Storage helpers
export function loadTransactions(): Transaction[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.TRANSACTIONS);
    if (!data) {
      const initial = generateSampleTransactions();
      saveTransactions(initial);
      return initial;
    }
    return JSON.parse(data);
  } catch {
    return generateSampleTransactions();
  }
}

export function saveTransactions(transactions: Transaction[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(transactions));
  } catch (err) {
    console.error('Error saving transactions', err);
  }
}

export function loadBudgets(): CategoryBudget[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.BUDGETS);
    if (!data) {
      const initial = getInitialBudgets();
      saveBudgets(initial);
      return initial;
    }
    return JSON.parse(data);
  } catch {
    return getInitialBudgets();
  }
}

export function saveBudgets(budgets: CategoryBudget[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.BUDGETS, JSON.stringify(budgets));
  } catch (err) {
    console.error('Error saving budgets', err);
  }
}

export function loadFamilyMembers(): FamilyMember[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.FAMILY);
    if (!data) {
      saveFamilyMembers(INITIAL_FAMILY_MEMBERS);
      return INITIAL_FAMILY_MEMBERS;
    }
    return JSON.parse(data);
  } catch {
    return INITIAL_FAMILY_MEMBERS;
  }
}

export function saveFamilyMembers(members: FamilyMember[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.FAMILY, JSON.stringify(members));
  } catch (err) {
    console.error('Error saving family members', err);
  }
}

export function loadSavingsGoals(): SavingsGoal[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.SAVINGS_GOALS);
    if (!data) {
      saveSavingsGoals(INITIAL_SAVINGS_GOALS);
      return INITIAL_SAVINGS_GOALS;
    }
    return JSON.parse(data);
  } catch {
    return INITIAL_SAVINGS_GOALS;
  }
}

export function saveSavingsGoals(goals: SavingsGoal[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.SAVINGS_GOALS, JSON.stringify(goals));
  } catch (err) {
    console.error('Error saving savings goals', err);
  }
}

export function loadBills(): BillItem[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.BILLS);
    if (!data) {
      saveBills(INITIAL_BILLS);
      return INITIAL_BILLS;
    }
    return JSON.parse(data);
  } catch {
    return INITIAL_BILLS;
  }
}

export function saveBills(bills: BillItem[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.BILLS, JSON.stringify(bills));
  } catch (err) {
    console.error('Error saving bills', err);
  }
}

export function loadDebts(): DebtItem[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.DEBTS);
    if (!data) {
      saveDebts(INITIAL_DEBTS);
      return INITIAL_DEBTS;
    }
    return JSON.parse(data);
  } catch {
    return INITIAL_DEBTS;
  }
}

export function saveDebts(debts: DebtItem[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.DEBTS, JSON.stringify(debts));
  } catch (err) {
    console.error('Error saving debts', err);
  }
}

export function loadSettings(): AppSettings {
  const defaultSettings: AppSettings = {
    currency: DEFAULT_CURRENCY,
    monthlyTotalBudget: 7500,
    viewMode: 'android_frame',
    themeMode: 'light',
    themeAccent: 'emerald',
    backgroundStyle: 'oasis_mesh',
  };

  try {
    const data = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (!data) {
      saveSettings(defaultSettings);
      return defaultSettings;
    }
    const parsed = JSON.parse(data);
    return {
      ...defaultSettings,
      ...parsed,
      themeAccent: parsed.themeAccent || 'emerald',
      backgroundStyle: parsed.backgroundStyle || 'oasis_mesh',
    };
  } catch {
    return defaultSettings;
  }
}

export function saveSettings(settings: AppSettings) {
  try {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  } catch (err) {
    console.error('Error saving settings', err);
  }
}

export function resetToSampleData() {
  saveTransactions(generateSampleTransactions());
  saveBudgets(getInitialBudgets());
  saveFamilyMembers(INITIAL_FAMILY_MEMBERS);
  saveSavingsGoals(INITIAL_SAVINGS_GOALS);
  saveBills(INITIAL_BILLS);
  saveDebts(INITIAL_DEBTS);
}

export function clearAllData() {
  saveTransactions([]);
  saveBills([]);
  saveDebts([]);
  saveSavingsGoals([]);
}

// Export CSV for Excel
export function exportToCSV(transactions: Transaction[], currencySymbol: string) {
  const headers = ['المعرف', 'النوع', 'البند', 'المبلغ', 'العملة', 'الفئة', 'نوع الدخل/المصروف', 'الصندوق', 'التاريخ', 'طريقة الدفع', 'الملاحظات'];
  const rows = transactions.map((t) => [
    t.id,
    t.type === 'expense' ? 'مصروف' : 'دخل',
    `"${t.title.replace(/"/g, '""')}"`,
    t.amount,
    currencySymbol,
    t.category,
    t.isSuddenIncome ? 'دخل مفاجئ ⚡' : t.incomeKind || 'عادي',
    t.fundId || 'عام',
    t.date,
    t.paymentMethod === 'cash' ? 'نقداً' : t.paymentMethod === 'card' ? 'بطاقة' : 'تحويل',
    `"${(t.notes || '').replace(/"/g, '""')}"`,
  ]);

  const csvContent = '\uFEFF' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `تقرير_مصاريف_المنزل_${new Date().toISOString().split('T')[0]}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
