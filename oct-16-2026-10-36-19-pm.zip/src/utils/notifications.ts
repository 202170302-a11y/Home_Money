import { BillItem, CurrencyConfig } from '../types';

export interface BillNotification {
  id: string;
  billId: string;
  billTitle: string;
  amount: number;
  dueDay: number;
  dueText: string; // "تستحق غداً (خلال 24 ساعة)" أو "تستحق اليوم"
  isUrgent: boolean;
  createdAt: number;
}

// Check which unpaid bills are due within 24 hours (tomorrow) or today
export function getUpcomingBillAlerts(bills: BillItem[]): BillNotification[] {
  const today = new Date();
  const currentDay = today.getDate();

  // Find number of days in current month
  const daysInMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate();

  const alerts: BillNotification[] = [];

  bills.forEach((bill) => {
    if (bill.isPaid) return;

    let diffDays = bill.dueDay - currentDay;
    // Handle wrap around month end (e.g. currentDay is 31 and dueDay is 1)
    if (diffDays < 0 && currentDay >= daysInMonth - 1 && bill.dueDay <= 2) {
      diffDays += daysInMonth;
    }

    if (diffDays === 1) {
      // Due tomorrow (within 24 hours!)
      alerts.push({
        id: `alert_tomorrow_${bill.id}_${today.toISOString().split('T')[0]}`,
        billId: bill.id,
        billTitle: bill.title,
        amount: bill.amount,
        dueDay: bill.dueDay,
        dueText: 'تستحق غداً (خلال 24 ساعة)',
        isUrgent: true,
        createdAt: Date.now(),
      });
    } else if (diffDays === 0) {
      // Due today!
      alerts.push({
        id: `alert_today_${bill.id}_${today.toISOString().split('T')[0]}`,
        billId: bill.id,
        billTitle: bill.title,
        amount: bill.amount,
        dueDay: bill.dueDay,
        dueText: 'موعد استحقاقها اليوم!',
        isUrgent: true,
        createdAt: Date.now(),
      });
    } else if (diffDays === 2) {
      // Due in 2 days
      alerts.push({
        id: `alert_2days_${bill.id}_${today.toISOString().split('T')[0]}`,
        billId: bill.id,
        billTitle: bill.title,
        amount: bill.amount,
        dueDay: bill.dueDay,
        dueText: 'تستحق بعد يومين',
        isUrgent: false,
        createdAt: Date.now(),
      });
    }
  });

  return alerts;
}

// Request permission for Web Notifications API (Android / Chrome)
export async function requestNotificationPermission(): Promise<boolean> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return false;
  }

  if (Notification.permission === 'granted') {
    return true;
  }

  if (Notification.permission !== 'denied') {
    try {
      const permission = await Notification.requestPermission();
      return permission === 'granted';
    } catch {
      return false;
    }
  }

  return false;
}

// Trigger native device local notification if allowed
export function triggerNativeBillNotification(
  title: string,
  body: string
) {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return;
  }

  if (Notification.permission === 'granted') {
    try {
      new Notification(title, {
        body,
        icon: '/icon.svg',
        dir: 'rtl',
        lang: 'ar',
      });
    } catch {
      // Ignore if web notification unsupported in some sandboxes
    }
  }
}
