/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  Transaction,
  CategoryBudget,
  FamilyMember,
  SavingsGoal,
  BillItem,
  DebtItem,
  AppSettings,
} from './types';
import {
  loadTransactions,
  saveTransactions,
  loadBudgets,
  saveBudgets,
  loadFamilyMembers,
  saveFamilyMembers,
  loadSavingsGoals,
  saveSavingsGoals,
  loadBills,
  saveBills,
  loadDebts,
  saveDebts,
  loadSettings,
  saveSettings,
  resetToSampleData,
  clearAllData,
  exportToCSV,
} from './utils/storage';
import {
  getUpcomingBillAlerts,
  triggerNativeBillNotification,
} from './utils/notifications';
import { AndroidFrame } from './components/AndroidFrame';
import { TopHeader } from './components/TopHeader';
import { BottomNavBar, TabType } from './components/BottomNavBar';
import { PWAInstallBanner } from './components/PWAInstallBanner';
import { AndroidNotificationBanner } from './components/AndroidNotificationBanner';
import { NotificationsCenterModal } from './components/NotificationsCenterModal';
import { QuickAddModal } from './components/QuickAddModal';
import { SettingsModal } from './components/SettingsModal';

import { HomeTab } from './components/tabs/HomeTab';
import { TransactionsTab } from './components/tabs/TransactionsTab';
import { SavingsAndFundsTab } from './components/tabs/SavingsAndFundsTab';
import { BudgetsTab } from './components/tabs/BudgetsTab';
import { AdvisorTab } from './components/tabs/AdvisorTab';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('home');
  const [transactions, setTransactions] = useState<Transaction[]>(loadTransactions);
  const [budgets, setBudgets] = useState<CategoryBudget[]>(loadBudgets);
  const [familyMembers, setFamilyMembers] = useState<FamilyMember[]>(loadFamilyMembers);
  const [savingsGoals, setSavingsGoals] = useState<SavingsGoal[]>(loadSavingsGoals);
  const [bills, setBills] = useState<BillItem[]>(loadBills);
  const [debts, setDebts] = useState<DebtItem[]>(loadDebts);
  const [settings, setSettings] = useState<AppSettings>(loadSettings);

  const [isQuickAddOpen, setIsQuickAddOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isNotificationsCenterOpen, setIsNotificationsCenterOpen] = useState(false);
  const [dismissedAlertId, setDismissedAlertId] = useState<string | null>(null);

  // Sync dark mode class and theme attributes on HTML root element
  useEffect(() => {
    const root = document.documentElement;
    const isDark =
      settings.themeMode === 'dark' ||
      (settings.themeMode === 'system' &&
        window.matchMedia('(prefers-color-scheme: dark)').matches);

    if (isDark) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }

    root.setAttribute('data-theme-accent', settings.themeAccent || 'emerald');
    root.setAttribute('data-bg-style', settings.backgroundStyle || 'oasis_mesh');
  }, [settings.themeMode, settings.themeAccent, settings.backgroundStyle]);

  // Sync state to localStorage
  useEffect(() => {
    saveTransactions(transactions);
  }, [transactions]);

  useEffect(() => {
    saveBudgets(budgets);
  }, [budgets]);

  useEffect(() => {
    saveFamilyMembers(familyMembers);
  }, [familyMembers]);

  useEffect(() => {
    saveSavingsGoals(savingsGoals);
  }, [savingsGoals]);

  useEffect(() => {
    saveBills(bills);
  }, [bills]);

  useEffect(() => {
    saveDebts(debts);
  }, [debts]);

  useEffect(() => {
    saveSettings(settings);
  }, [settings]);

  // Current upcoming 24h bill alerts
  const billAlerts = useMemo(() => {
    return getUpcomingBillAlerts(bills);
  }, [bills]);

  const activeUrgentBannerAlert = useMemo(() => {
    return billAlerts.find((a) => a.isUrgent && a.id !== dismissedAlertId) || null;
  }, [billAlerts, dismissedAlertId]);

  // Check and trigger native notification on mount if there are 24h urgent bills
  useEffect(() => {
    if (billAlerts.length > 0) {
      const urgent = billAlerts[0];
      const sentKey = `sent_notif_${urgent.id}`;
      if (!sessionStorage.getItem(sentKey)) {
        triggerNativeBillNotification(
          `⚡ تذكير استحقاق: ${urgent.billTitle}`,
          `${urgent.dueText} بمبلغ ${urgent.amount} ${settings.currency.symbol}. يرجى سدادها لتجنب التأخير.`
        );
        sessionStorage.setItem(sentKey, 'true');
      }
    }
  }, [billAlerts, settings.currency.symbol]);

  // Current Arabic Month Name (e.g. أكتوبر 2026)
  const currentMonthName = new Intl.DateTimeFormat('ar-EG', {
    month: 'long',
    year: 'numeric',
  }).format(new Date());

  // Dark mode toggle handler
  const handleToggleDarkMode = () => {
    setSettings((prev) => {
      const nextMode = prev.themeMode === 'dark' ? 'light' : 'dark';
      return { ...prev, themeMode: nextMode };
    });
  };

  // Add Transaction with optional automatic Fund balance deduction/credit
  const handleAddTransaction = (
    txData: Omit<Transaction, 'id' | 'createdAt'>,
    options?: { deductFromFund?: boolean; depositToFund?: boolean }
  ) => {
    const newTx: Transaction = {
      ...txData,
      id: `tx_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
      createdAt: Date.now(),
    };

    setTransactions((prev) => [newTx, ...prev]);

    // Update family member wallet balance if requested
    if (txData.fundId) {
      if (options?.deductFromFund && txData.type === 'expense') {
        setFamilyMembers((prev) =>
          prev.map((m) =>
            m.id === txData.fundId
              ? { ...m, walletBalance: Math.max(0, m.walletBalance - txData.amount) }
              : m
          )
        );
      } else if (options?.depositToFund && txData.type === 'income') {
        setFamilyMembers((prev) =>
          prev.map((m) =>
            m.id === txData.fundId
              ? { ...m, walletBalance: m.walletBalance + txData.amount }
              : m
          )
        );
      }
    }
  };

  const handleDeleteTransaction = (id: string) => {
    setTransactions((prev) => prev.filter((t) => t.id !== id));
  };

  // Savings Goals Handlers
  const handleDepositToGoal = (goalId: string, amount: number, note?: string) => {
    setSavingsGoals((prev) =>
      prev.map((g) => {
        if (g.id === goalId) {
          const newCurrent = g.currentAmount + amount;
          return {
            ...g,
            currentAmount: newCurrent,
            isCompleted: newCurrent >= g.targetAmount,
          };
        }
        return g;
      })
    );

    const goal = savingsGoals.find((g) => g.id === goalId);
    handleAddTransaction({
      type: 'expense',
      title: `إيداع في ادخار: ${goal?.title || 'هدف ادخار'}`,
      amount,
      category: 'misc',
      date: new Date().toISOString().split('T')[0],
      paymentMethod: 'transfer',
      notes: note || 'إيداع مدخرات',
    });
  };

  const handleWithdrawFromGoal = (goalId: string, amount: number, note?: string) => {
    setSavingsGoals((prev) =>
      prev.map((g) => {
        if (g.id === goalId) {
          const newCurrent = Math.max(0, g.currentAmount - amount);
          return {
            ...g,
            currentAmount: newCurrent,
            isCompleted: newCurrent >= g.targetAmount,
          };
        }
        return g;
      })
    );

    const goal = savingsGoals.find((g) => g.id === goalId);
    handleAddTransaction({
      type: 'income',
      title: `سحب من ادخار: ${goal?.title || 'هدف ادخار'}`,
      amount,
      category: 'other_income',
      date: new Date().toISOString().split('T')[0],
      paymentMethod: 'cash',
      notes: note || 'سحب من مدخرات الهدف',
    });
  };

  const handleAddSavingsGoal = (goalData: Omit<SavingsGoal, 'id' | 'createdAt'>) => {
    const newGoal: SavingsGoal = {
      ...goalData,
      id: `goal_${Date.now()}`,
      createdAt: Date.now(),
    };
    setSavingsGoals((prev) => [newGoal, ...prev]);
  };

  const handleDeleteSavingsGoal = (goalId: string) => {
    setSavingsGoals((prev) => prev.filter((g) => g.id !== goalId));
  };

  // Family Funds Handlers
  const handleDepositToFund = (memberId: string, amount: number, note?: string) => {
    setFamilyMembers((prev) =>
      prev.map((m) =>
        m.id === memberId
          ? { ...m, walletBalance: m.walletBalance + amount }
          : m
      )
    );

    const member = familyMembers.find((m) => m.id === memberId);
    handleAddTransaction({
      type: 'expense',
      title: `إيداع في صندوق: ${member?.name || 'فرد الأسرة'}`,
      amount,
      category: 'misc',
      fundId: memberId,
      familyMemberId: memberId,
      date: new Date().toISOString().split('T')[0],
      paymentMethod: 'transfer',
      notes: note || 'تخصيص مصروف وميزانية للصندوق',
    });
  };

  const handleWithdrawFromFund = (memberId: string, amount: number, note?: string) => {
    setFamilyMembers((prev) =>
      prev.map((m) =>
        m.id === memberId
          ? { ...m, walletBalance: Math.max(0, m.walletBalance - amount) }
          : m
      )
    );

    const member = familyMembers.find((m) => m.id === memberId);
    handleAddTransaction({
      type: 'expense',
      title: `سحب نقدي من صندوق: ${member?.name || 'فرد الأسرة'}`,
      amount,
      category: 'misc',
      fundId: memberId,
      familyMemberId: memberId,
      date: new Date().toISOString().split('T')[0],
      paymentMethod: 'cash',
      notes: note || 'سحب نقدي من رصيد الصندوق',
    });
  };

  const handleUpdateMemberAllowance = (memberId: string, allowance: number) => {
    setFamilyMembers((prev) =>
      prev.map((m) =>
        m.id === memberId ? { ...m, monthlyAllowance: allowance } : m
      )
    );
  };

  // Bills & Debts Handlers
  const handleToggleBillPaid = (billId: string) => {
    setBills((prev) =>
      prev.map((b) => {
        if (b.id === billId) {
          const nextPaid = !b.isPaid;
          if (nextPaid) {
            handleAddTransaction({
              type: 'expense',
              title: `سداد ${b.title}`,
              amount: b.amount,
              category: b.category || 'utilities',
              date: new Date().toISOString().split('T')[0],
              paymentMethod: 'card',
              notes: 'تم التسجيل تلقائياً من قائمة الفواتير',
            });
          }
          return { ...b, isPaid: nextPaid };
        }
        return b;
      })
    );
  };

  const handlePayBillQuick = (billId: string) => {
    handleToggleBillPaid(billId);
  };

  const handleAddBill = (billData: Omit<BillItem, 'id'>) => {
    const newBill: BillItem = {
      ...billData,
      id: `bill_${Date.now()}`,
    };
    setBills((prev) => [...prev, newBill]);
  };

  const handleDeleteBill = (billId: string) => {
    setBills((prev) => prev.filter((b) => b.id !== billId));
  };

  const handleToggleDebtPaid = (debtId: string) => {
    setDebts((prev) =>
      prev.map((d) => (d.id === debtId ? { ...d, isPaid: !d.isPaid } : d))
    );
  };

  const handleAddDebt = (debtData: Omit<DebtItem, 'id' | 'createdAt'>) => {
    const newDebt: DebtItem = {
      ...debtData,
      id: `debt_${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0],
    };
    setDebts((prev) => [...prev, newDebt]);
  };

  const handleDeleteDebt = (debtId: string) => {
    setDebts((prev) => prev.filter((d) => d.id !== debtId));
  };

  const handleUpdateTotalBudget = (amount: number) => {
    setSettings((prev) => ({ ...prev, monthlyTotalBudget: amount }));
  };

  const handleUpdateCategoryBudget = (categoryId: string, limit: number) => {
    setBudgets((prev) => {
      const exists = prev.some((b) => b.categoryId === categoryId);
      if (exists) {
        return prev.map((b) =>
          b.categoryId === categoryId ? { ...b, monthlyLimit: limit } : b
        );
      }
      return [...prev, { categoryId, monthlyLimit: limit }];
    });
  };

  const handleResetSampleData = () => {
    resetToSampleData();
    setTransactions(loadTransactions());
    setBudgets(loadBudgets());
    setFamilyMembers(loadFamilyMembers());
    setSavingsGoals(loadSavingsGoals());
    setBills(loadBills());
    setDebts(loadDebts());
  };

  const handleClearAllData = () => {
    clearAllData();
    setTransactions([]);
    setBills([]);
    setDebts([]);
    setSavingsGoals([]);
  };

  const handleExportCSV = () => {
    exportToCSV(transactions, settings.currency.symbol);
  };

  const handleToggleViewMode = () => {
    setSettings((prev) => ({
      ...prev,
      viewMode: prev.viewMode === 'android_frame' ? 'responsive' : 'android_frame',
    }));
  };

  return (
    <AndroidFrame
      viewMode={settings.viewMode}
      onToggleViewMode={handleToggleViewMode}
      themeAccent={settings.themeAccent}
      backgroundStyle={settings.backgroundStyle}
    >
      {/* Top Header with Dark Mode Toggle & 24h Bill Notifications Bell */}
      <TopHeader
        currentMonthName={currentMonthName}
        currency={settings.currency}
        isDarkMode={settings.themeMode === 'dark'}
        onToggleDarkMode={handleToggleDarkMode}
        notificationCount={billAlerts.length}
        onOpenNotifications={() => setIsNotificationsCenterOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        themeAccent={settings.themeAccent}
      />

      {/* 24-Hour Urgent Bill Notification Heads-up Toast */}
      <AndroidNotificationBanner
        urgentAlert={activeUrgentBannerAlert}
        currency={settings.currency}
        onPayBill={handlePayBillQuick}
        onDismiss={() => {
          if (activeUrgentBannerAlert) {
            setDismissedAlertId(activeUrgentBannerAlert.id);
          }
        }}
      />

      {/* PWA Install Banner */}
      <PWAInstallBanner />

      {/* Main Tab Screen Content */}
      <main className="p-3 sm:p-4 flex-1">
        {activeTab === 'home' && (
          <HomeTab
            transactions={transactions}
            bills={bills}
            familyMembers={familyMembers}
            savingsGoals={savingsGoals}
            currency={settings.currency}
            monthlyTotalBudget={settings.monthlyTotalBudget}
            themeAccent={settings.themeAccent}
            onOpenQuickAdd={() => setIsQuickAddOpen(true)}
            onNavigateTab={(tab) => setActiveTab(tab)}
            onPayBillQuick={handlePayBillQuick}
            onExportReport={handleExportCSV}
          />
        )}

        {activeTab === 'transactions' && (
          <TransactionsTab
            transactions={transactions}
            familyMembers={familyMembers}
            currency={settings.currency}
            onDeleteTransaction={handleDeleteTransaction}
            onOpenQuickAdd={() => setIsQuickAddOpen(true)}
            onExportCSV={handleExportCSV}
          />
        )}

        {activeTab === 'savings' && (
          <SavingsAndFundsTab
            savingsGoals={savingsGoals}
            familyMembers={familyMembers}
            transactions={transactions}
            currency={settings.currency}
            onDepositToGoal={handleDepositToGoal}
            onWithdrawFromGoal={handleWithdrawFromGoal}
            onAddSavingsGoal={handleAddSavingsGoal}
            onDeleteSavingsGoal={handleDeleteSavingsGoal}
            onDepositToFund={handleDepositToFund}
            onWithdrawFromFund={handleWithdrawFromFund}
            onUpdateMemberAllowance={handleUpdateMemberAllowance}
          />
        )}

        {activeTab === 'budgets' && (
          <BudgetsTab
            transactions={transactions}
            budgets={budgets}
            bills={bills}
            debts={debts}
            currency={settings.currency}
            monthlyTotalBudget={settings.monthlyTotalBudget}
            onUpdateTotalBudget={handleUpdateTotalBudget}
            onUpdateCategoryBudget={handleUpdateCategoryBudget}
            onToggleBillPaid={handleToggleBillPaid}
            onAddBill={handleAddBill}
            onDeleteBill={handleDeleteBill}
            onToggleDebtPaid={handleToggleDebtPaid}
            onAddDebt={handleAddDebt}
            onDeleteDebt={handleDeleteDebt}
          />
        )}

        {activeTab === 'advisor' && (
          <AdvisorTab
            transactions={transactions}
            budgets={budgets}
            familyMembers={familyMembers}
            bills={bills}
            debts={debts}
            currency={settings.currency}
          />
        )}
      </main>

      {/* Fixed Bottom Navigation Bar */}
      <BottomNavBar
        activeTab={activeTab}
        onTabChange={(tab) => setActiveTab(tab)}
        onOpenQuickAdd={() => setIsQuickAddOpen(true)}
        themeAccent={settings.themeAccent}
      />

      {/* Quick Add Bottom Sheet Modal */}
      <QuickAddModal
        isOpen={isQuickAddOpen}
        onClose={() => setIsQuickAddOpen(false)}
        onAddTransaction={handleAddTransaction}
        familyMembers={familyMembers}
        currencySymbol={settings.currency.symbol}
      />

      {/* Notifications Center Modal (24h Bill Reminders) */}
      <NotificationsCenterModal
        isOpen={isNotificationsCenterOpen}
        onClose={() => setIsNotificationsCenterOpen(false)}
        alerts={billAlerts}
        currency={settings.currency}
        onPayBill={(billId) => {
          handlePayBillQuick(billId);
          setIsNotificationsCenterOpen(false);
        }}
      />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        familyMembers={familyMembers}
        onUpdateSettings={setSettings}
        onUpdateFamilyMembers={setFamilyMembers}
        onResetSampleData={handleResetSampleData}
        onClearAllData={handleClearAllData}
        onExportCSV={handleExportCSV}
      />
    </AndroidFrame>
  );
}
